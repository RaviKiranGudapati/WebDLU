USE [Charts-Master];
DECLARE @user_name1 varchar(50);
SET @user_name1 = 'autouser101';
INSERT INTO [demographics].[mpi_patient]
           ([patient_id]
           ,[first_name]
           ,[last_name]
           ,[middle_initial]
           ,[title]
           ,[ssn]
           ,[date_of_birth]
           ,[gender]
           ,[account_number]
           ,[no_known_drug_allergy_tf]
           ,[no_known_non_drug_allergy_tf]
           ,[no_known_latex_allergy_tf]

           ,[alias]

           ,[no_home_medication_tf]
           ,[email])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_mpi_patient])
           ,'Pfname_nd-aci-sc192','Plname_nd-aci-sc192','','Mr','238982919','1990-06-08'
           ,'Male','925949624',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO [demographics].[mpi_patient_organization_map]
           ([patient_id]
           ,[organization_id])
     VALUES
           ((select patient_id from demographics.mpi_patient where first_name='Pfname_nd-aci-sc192' and last_name='Plname_nd-aci-sc192')
           ,(select organization_id from [Charts-Master].organization.org_organization where name='Auto Org101'));
INSERT INTO [demographics].[case_summary]
           ([case_summary_id]
           ,[patient_id]

           ,[organization_id]
           ,[procedure_dt]
           ,[primary_physician_id]
           ,[referring_physician_id]

           ,[signature_id]
           ,[signature_dt]
           ,[external_id]
           ,[active_tf])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_case_summary])
           ,(select patient_id from demographics.mpi_patient where first_name='Pfname_nd-aci-sc192' and last_name='Plname_nd-aci-sc192')
		   ,(select organization_id from demographics.mpi_patient_organization_map where patient_id in (select patient_id from demographics.mpi_patient where first_name='Pfname_nd-aci-sc192' and last_name='Plname_nd-aci-sc192'))
           ,SYSDATETIMEOFFSET()
           ,(select usr_id from Security.user_account where user_name=@user_name1)
           ,NULL,NULL,NULL,0,1);
		   INSERT INTO [demographics].[case_summary_info]
           ([case_summary_id]
           ,[acute_chronic_tf]
           ,[note]
           ,[created]
           ,[status]
           ,[cancel_case_reason]
           ,[cancel_date]
           ,[previous_status]
           ,[created_by_user]
           ,[modified_by_user]
           ,[created_dt]
           ,[last_update_dt]
           ,[status_at_discharge]
           ,[cancel_case_reason_id]
           ,[is_depleted_tf]
           ,[is_documented_tf]
           ,[unable_to_code]
           ,[unable_to_code_reason]
           ,[case_type])
     VALUES
           ((select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where last_name = 'Plname_nd-aci-sc192'))
           ,0
           ,'Notesc192'
           ,SYSDATETIMEOFFSET()
           ,'Scheduled'
           ,NULL
           ,NULL
           ,NULL
           ,(select usr_id from Security.user_account where user_name='autouser101')
           ,NULL
           ,SYSDATETIMEOFFSET()
           ,NULL
           ,NULL
           ,NULL
           ,0
           ,0
           ,0
           ,NULL
           ,1)
INSERT INTO [organization].[room_type]
           ([room_type_id]
           ,[business_group_id]
           ,[room_type_desc]
           ,[quick_code]
           ,[active_tf]
           ,[classification])
     VALUES
           ((select max(room_type_id)+1 from organization.room_type)
           ,(select organization_id from [Charts-Master].organization.org_organization where name='Auto Org101')
           ,'RoomType192'
           ,'QuickCode192'
           ,1
           ,'Procedure');
INSERT INTO [organization].[room]
           ([room_id]
           ,[quick_code]
           ,[active_tf]
           ,[organization_id]
           ,[name]
           ,[room_type_id]
           ,[facility_id]
           )
     VALUES
           ((select max(room_id)+1 from organization.room)
           ,'QuickCode192'
           ,1
           ,(select organization_id from organization.org_organization where name = 'Auto Org101')
           ,'AutoRoom192'
           ,(select room_type_id from organization.room_type where room_type_desc='RoomType192')
           ,NULL
           );
INSERT INTO [dictionaries].[anesthesia_type_definition]
           ([anes_type_id]
           ,[organization_id]
           ,[anes_type_name]
           ,[quick_code])
     VALUES
           ((select max(anes_type_id)+1 from dictionaries.anesthesia_type_definition)
           ,(select organization_id from [Charts-Master].organization.org_organization where name='Auto Org101')
           ,'JJPlname_nd-aci-sc192 General'
           ,'Quick General');
INSERT INTO [demographics].[appointment_information]
           ([appointment_id]
           ,[case_summary_id]
           ,[appointment_type_id]
           ,[anes_type_id]
           ,[start_time]
           ,[end_time]
           ,[arrival_time]
           ,[organization_id]
           ,[room_id]
           ,[appointment_note]
           ,[last_update_dt]
           ,[department_id]
           ,[case_status])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_appointment_information])
           ,(select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name='Pfname_nd-aci-sc192' and last_name='Plname_nd-aci-sc192'))
           ,(select appointment_type_id from demographics.appointment_type where appointment_type_desc = 'General Org101')
           ,NULL
            ,(SELECT ToDateTimeOffset((SELECT CAST(DATEPART(YYYY,SYSDATETIMEOFFSET()) AS VARCHAR)+'-'
                     +CAST(DATEPART(MM,SYSDATETIMEOFFSET()) AS VARCHAR)
                     +'-'+CAST(DATEPART(DD,SYSDATETIMEOFFSET()) AS VARCHAR)
                     +' 11'
                     +':00'),'-04:00'))
           ,(SELECT ToDateTimeOffset((SELECT CAST(DATEPART(YYYY,SYSDATETIMEOFFSET()) AS VARCHAR)+'-'
                     +CAST(DATEPART(MM,SYSDATETIMEOFFSET()) AS VARCHAR)
                     +'-'+CAST(DATEPART(DD,SYSDATETIMEOFFSET()) AS VARCHAR)
                     +' 12'
                     +':00'),'-04:00'))
           ,NULL
           ,(select organization_id from [Charts-Master].organization.org_organization where name='Auto Org101')
           ,(select room_id from organization.room where name = 'AutoRoom192')
           ,'Auto Care'
           ,SYSDATETIMEOFFSET()
           ,NULL
           ,NULL);
INSERT INTO [demographics].[case_procedure]
           ([procedure_id]
           ,[procedure_description]
           ,[primary_procedure_tf]
           ,[appointment_id]
           ,[physician_id])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_case_procedure])
           ,'Auto Procedure'
           ,1
           ,(select appointment_id from demographics.appointment_information where room_id in (select room_id from organization.room where name = 'AutoRoom192'))
           ,(select usr_id from Security.user_account where user_name=@user_name1));