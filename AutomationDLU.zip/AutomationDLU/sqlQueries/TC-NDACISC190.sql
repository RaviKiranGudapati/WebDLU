USE [Charts-Master];

delete from organization.apptype_casepack_map where appointment_type_id in (SELECT appointment_type_id from demographics.appointment_type where appointment_type_desc='Surgeryaci190');
delete from demographics.case_procedure where appointment_id in (select appointment_id from demographics.appointment_information where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190')));
delete from demographics.appointment_information where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190'));
delete from security.record_lock where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190'));
delete from [Charts-Master].demographics.documentation_state where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190'));

delete from [demographics].[case_summary_info] where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from [Charts-Master].demographics.mpi_patient where last_name='Plname_nd_aci_sc190'));
delete from demographics.recent_patients where case_summary_id in (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from [Charts-Master].demographics.mpi_patient where last_name='Plname_nd_aci_sc190'));

delete from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190');
delete from organization.config_default_patient_handoff where transfer_via_id in (select dictionary_id FROM [Charts-Master].[dictionaries].[patient_related_dictionary] where patient_category = 'Transferred/Discharged_Via' and category_value='Admit190');
delete FROM [Charts-Master].[dictionaries].[patient_related_dictionary] where patient_category = 'Transferred/Discharged_Via' and category_value='Admit190';
delete FROM [Charts-Master].[dictionaries].[patient_related_dictionary] where patient_category = 'Attended_By' and category_value='Attend190';
delete from demographics.case_procedure where appointment_id in (select appointment_id from demographics.appointment_information where appointment_type_id in (select appointment_type_id from demographics.appointment_type where quick_code = 'Quickaci190'));
delete from demographics.appointment_information where appointment_type_id in (select appointment_type_id from demographics.appointment_type where quick_code = 'Quickaci190');
delete from demographics.appointment_type where quick_code = 'Quickaci190';
delete from organization.room where name='AutoRoom190';
delete from organization.room_type where room_type_desc = 'RoomType190';
delete from demographics.mpi_patient_organization_map where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190');
delete from demographics.patient_allergy_history where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190');
delete from demographics.recent_patients where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190');
delete from demographics.mpi_patient where patient_id in (select patient_id from demographics.mpi_patient where first_name like 'Pfname_nd_aci_sc190' and last_name like 'Plname_nd_aci_sc190');

INSERT INTO [demographics].[mpi_patient]
           ([patient_id]
           ,[first_name]
           ,[last_name]
           ,[middle_initial]
           ,[title]
           ,[ssn]
           ,[date_of_birth]
           ,[gender]
           ,[account_number]
           ,[no_known_drug_allergy_tf]
           ,[no_known_non_drug_allergy_tf]
           ,[no_known_latex_allergy_tf]
           ,[alias]
           ,[no_home_medication_tf]
           ,[email])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_mpi_patient])
           ,'Pfname_nd_aci_sc190','Plname_nd_aci_sc190','','Mr','238982920','1990-06-08'
           ,'Male','238982920',NULL,NULL,NULL,NULL
           ,NULL,NULL);

INSERT INTO [demographics].[mpi_patient_organization_map]
           ([patient_id]
           ,[organization_id])
     VALUES
           ((select patient_id from demographics.mpi_patient where first_name='Pfname_nd_aci_sc190' and last_name='Plname_nd_aci_sc190')
           ,(select organization_id from organization.org_organization where name = 'Auto Org108'));

INSERT INTO [organization].[room_type]
           ([room_type_id]
           ,[business_group_id]
           ,[room_type_desc]
           ,[quick_code]
           ,[active_tf]
           ,[classification])
     VALUES
           ((select max(room_type_id)+1 from organization.room_type)
           ,271
           ,'RoomType190'
           ,'Quickaci190'
           ,1
           ,'Procedure');

INSERT INTO [organization].[room]
           ([room_id]
           ,[quick_code]
           ,[active_tf]
           ,[organization_id]
           ,[name]
           ,[room_type_id]
           ,[facility_id]
           )
     VALUES
           ((select max(room_id)+1 from organization.room)
           ,'Quickaci190'
           ,1
           ,(select organization_id from [Charts-Master].organization.org_organization where name = 'Auto Org108')
           ,'AutoRoom190'
           ,(select room_type_id from organization.room_type where room_type_desc='RoomType190')
           ,NULL
           );

INSERT INTO [demographics].[appointment_type]
           ([appointment_type_id]
           ,[appointment_type_desc]
           ,[quick_code]
           ,[active_tf]
           ,[business_entity_id]
           ,[duration]
           ,[color_rgb]
           ,[allow_overbook_tf]
           ,[appointment_type_kind_id]
           ,[type_of_bill]
           ,[need_case_tf]
           ,[service_grid_id]
           ,[bill_on_sep_claim_form_tf]
           ,[inpatient_tf]
           ,[bill_time_material_tf]
           ,[default_chart_pack_id])
     VALUES
           ((select max(appointment_type_id)+1 from demographics.appointment_type)
           ,'Surgeryaci190'
           ,'Quickaci190'
           ,1
           ,(select organization_id from organization.org_organization where name = 'Auto Org108')
           ,60
           ,-1
           ,1
           ,3
           ,NULL
           ,1
           ,NULL
           ,NULL
           ,0
           ,0
           ,NULL);

INSERT INTO [demographics].[case_summary]
           ([case_summary_id]
           ,[patient_id]
           ,[organization_id]
           ,[procedure_dt]
           ,[primary_physician_id]
           ,[referring_physician_id]
		   ,[signature_id]
           ,[signature_dt]
           ,[external_id]
           ,[active_tf])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_case_summary])
           ,(select patient_id from demographics.mpi_patient where first_name='Pfname_nd_aci_sc190' and last_name='Plname_nd_aci_sc190')
           ,(select organization_id from demographics.mpi_patient_organization_map where patient_id in (select patient_id from demographics.mpi_patient where first_name='Pfname_nd_aci_sc190' and last_name='Plname_nd_aci_sc190'))
           ,Dateadd(hour,-3,SYSDATETIMEOFFSET())
           ,(select usr_id from Security.user_account where user_name='autouser108')
           ,NULL,NULL,NULL,0,1);

		   INSERT INTO [demographics].[case_summary_info]
           ([case_summary_id]
           ,[acute_chronic_tf]
           ,[note]
           ,[created]
           ,[status]
           ,[cancel_case_reason]
           ,[cancel_date]
           ,[previous_status]
           ,[created_by_user]
           ,[modified_by_user]
           ,[created_dt]
           ,[last_update_dt]
           ,[status_at_discharge]
           ,[cancel_case_reason_id]
           ,[is_depleted_tf]
           ,[is_documented_tf]
           ,[unable_to_code]
           ,[unable_to_code_reason]
           ,[case_type])
     VALUES
           ((select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where last_name = 'Plname_nd_aci_sc190'))
           ,0
           ,'Notesc190'
           ,SYSDATETIMEOFFSET()
           ,'Scheduled'
           ,NULL
           ,NULL
           ,NULL
           ,(select usr_id from Security.user_account where user_name='autouser108')
           ,NULL
           ,SYSDATETIMEOFFSET()
           ,NULL
           ,NULL
           ,NULL
           ,0
           ,0
           ,0
           ,NULL
           ,1)


INSERT INTO [demographics].[appointment_information]
           ([appointment_id]
           ,[case_summary_id]
           ,[appointment_type_id]
           ,[anes_type_id]
           ,[start_time]
           ,[end_time]
           ,[arrival_time]
           ,[organization_id]
           ,[room_id]
           ,[appointment_note]
           ,[last_update_dt]
           ,[department_id]
           ,[case_status])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_appointment_information])
           ,(select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name='Pfname_nd_aci_sc190' and last_name='Plname_nd_aci_sc190') and procedure_dt < SYSDATETIMEOFFSET())
           ,(select appointment_type_id from demographics.appointment_type where appointment_type_desc = 'Surgeryaci190')
           ,NULL
           ,SYSDATETIMEOFFSET()
           ,DATEADD(hour,1,SYSDATETIMEOFFSET())
           ,NULL
           ,(select organization_id from organization.org_organization where name = 'Auto Org108')
           ,(select room_id from organization.room where name = 'AutoRoom190')
           ,'AppointmentNote aci190'
           ,SYSDATETIMEOFFSET()
           ,NULL
           ,NULL);

INSERT INTO [demographics].[case_procedure]
           ([procedure_id]
		   ,[procedure_description]
           ,[primary_procedure_tf]
           ,[appointment_id]
           ,[physician_id])
     VALUES
           ((NEXT VALUE FOR [demographics].[seq_case_procedure])
           ,'Auto Procedure'
           ,1
           ,(select [appointment_id] from demographics.appointment_information where  case_summary_id in  (select case_summary_id from demographics.case_summary where patient_id in (select patient_id from demographics.mpi_patient where first_name='Pfname_nd_aci_sc190' and last_name='Plname_nd_aci_sc190') and procedure_dt < SYSDATETIMEOFFSET()))
           ,(select usr_id from Security.user_account where user_name='autouser108'));


INSERT INTO [organization].[apptype_casepack_map]
           ([organization_id]
           ,[case_pack_id]
           ,[appointment_type_id])
     VALUES
           ((SELECT organization_id from organization.org_organization where name = 'Auto Org108')
           ,(SELECT case_pack_id from organization.case_pack where case_pack_name='General')
           ,(SELECT appointment_type_id from demographics.appointment_type where appointment_type_desc='Surgeryaci190'));

declare @maxValue34 int; select @maxValue34=max(dictionary_id)+1 from dictionaries.patient_related_dictionary; if @maxValue34 is not NULL EXEC ( 'ALTER SEQUENCE [dictionaries].seq_patient_related_dictionary RESTART WITH '+ @maxValue34) else set @maxValue34=1 EXEC ( 'ALTER SEQUENCE [dictionaries].seq_patient_related_dictionary RESTART WITH '+ @maxValue34);