/**
 * 17/07/2020, Debasish, Changes - Updated getValueFromJsonObject to validate text being passed as parameter. 
 */

/**
 * @author DPradhan
 */

package com.parser.json;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.utils.JsonUtils;

/**
 * The Class JSONFileParser.
 */
public class JSONFileParser {

	private String path = null;
	private JsonUtils jsonUtilsObj = null;
	private JSONObject jsonObj = null;
	private static final Logger LOG = Logger.getLogger(JSONFileParser.class);

	/**
	 * Instantiates a new JSON file parser.
	 *
	 * @param path the path
	 */
	public JSONFileParser(String path) {

		try {
			this.path = path;
			this.jsonUtilsObj = new JsonUtils();
			this.jsonObj = (JSONObject) this.jsonUtilsObj.getJsonFileAsObject(this.path);
		} catch (Exception e) {
			LOG.error(e);
			LOG.debug(String.format("Error In Parsing JSON File - %s", this.path));
			LOG.debug("Data Load Utility Program Will Be Aborted ...");
			System.exit(-1);
		}
	}

	/**
	 * Gets the json file path.
	 *
	 * @return the json file path
	 */
	public String getJsonFilePath() {
		return this.path;
	}

	/**
	 * Gets the JSON object.
	 *
	 * @return the JSON object
	 */
	public JSONObject getJSONObject() {
		return this.jsonObj;
	}

	/**
	 * Gets the value from json object.
	 *
	 * @param text the text
	 * @return the value from json object
	 */
	public String getValueFromJsonObject(String text) {
		String keyValue = null;
		int dataSet_No = -1;
		if (text.contains("[num]")) {
			text = text.replace("[num]", "[1]");
		}
		String testCaseKey = null;
		try {
			testCaseKey = text.substring("data.".length(), text.indexOf("["));
		} catch (Exception ex) {
			LOG.error(String.format("Text Parameter - %s", text));
			LOG.error(ex);
			throw new RuntimeException(String.format("Error In Text - %s", text));
		}
		try {
			dataSet_No = Integer.parseInt(text.substring(text.indexOf("[") + 1, text.indexOf("]")));
		} catch (RuntimeException ex) {
			LOG.error(ex);
			throw new RuntimeException(
					String.format("Error In Referring Data. Data Index Is Not Proper In Text - %s", text));
		}
		String parameterKey = text.substring(text.indexOf("].") + 2);
		try {
			JSONArray jsonArrayObj = this.jsonUtilsObj.getJSONArray(this.jsonObj, testCaseKey);
			keyValue = this.jsonUtilsObj.getValueFromJSONArray(jsonArrayObj, parameterKey, dataSet_No);
		} catch (Exception e) {
			LOG.error(e);
			LOG.debug(String.format(
					"Exception Encountered While Reading Value For Key - %, For Test Case - %s From File - %s",
					parameterKey, testCaseKey, this.path));
			return null;
		}
		return keyValue;
	}

}
