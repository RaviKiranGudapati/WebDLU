package com.parser.excel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.seeddata.ISeedDataProcessor;

public class SISTestDataExcelParser {
	
	private ExcelParser excelParser = null;	
	private String[] exclusiveSheets = null;
	private static final Logger LOG = Logger.getLogger(SISTestDataExcelParser.class);
	
	public SISTestDataExcelParser(String path) throws Exception
	{
		this.excelParser = new ExcelParser(path);
	}	
	
	public SISTestDataExcelParser(String path, String[] exclusiveSheets) throws Exception
	{
		this.excelParser = new ExcelParser(path);
		this.exclusiveSheets = exclusiveSheets;
	}
	
		
	public String getDataFromTestDataFile(String text)
	{
		
		int testCaseHeaderRowNum = -1;
		int dataSet_No = -1;
		if(text.contains("[num]"))
		{
			text = text.replace("[num]", "[1]");
		}
		String testCase = text.substring("data.".length(), text.indexOf("["));
		try
		{
			dataSet_No = Integer.parseInt(text.substring(text.indexOf("[") + 1, text.indexOf("]")));
		}
		catch(RuntimeException ex)
		{
			LOG.error(ex);
			throw new RuntimeException(String.format("Error In Referring Data. Data Index Is Not Proper In Text - %s", text));
		}
		String columnHeader = text.substring(text.indexOf("].") + 2);
		List<String> listSheetNames = this.excelParser.getAllSheets(this.exclusiveSheets);
		for(String sheetName : listSheetNames)
		{
			//get test case row and col Number
			Map<String, Integer> mapRowCol = this.getRowColForCellData(sheetName, testCase);
			int testCaseRowNum = mapRowCol.get("rowNum");			
			if(testCaseRowNum > 0)
			{
				testCaseHeaderRowNum = testCaseRowNum - 1;
			}
						
			if(testCaseHeaderRowNum > 0)
			{
				int colNum = this.getColForCellData(sheetName, columnHeader, testCaseHeaderRowNum);
				if(colNum > 0)
				{
					return this.excelParser.getCellData(sheetName, colNum, testCaseRowNum + dataSet_No - 1);
				}
			}
			
		}
		throw new RuntimeException(String.format("Data Not Found For Text Reference - %s", text));
		
		
		
	}
	
	
	private Map<String, Integer> getRowColForCellData(String sheetName, String cellData)
	{
		int totalRows = this.excelParser.getRowCount(sheetName);		
		Map<String, Integer> mapRowCol = new HashMap<String, Integer>();
		//initialize mapRowCol map
		mapRowCol.put("rowNum", -1);
		mapRowCol.put("colNum", -1);
		
		for(int rowNum = 1; rowNum <= totalRows ; rowNum ++)
		{	
			LOG.debug(String.format("Current Row Number = %d", rowNum));			
			int totalColumns = this.excelParser.getColumnCount(sheetName, rowNum);
			
			for(int colNum = 1; colNum <= totalColumns ; colNum ++)
			{
				LOG.debug(String.format("Current Col Number = %d", colNum));
				String text = this.excelParser.getCellData(sheetName, colNum, rowNum);
				if(text.equalsIgnoreCase(cellData))
				{
					mapRowCol.put("rowNum", rowNum);
					mapRowCol.put("colNum", colNum);
					return mapRowCol;
				}
			}
		}
		return mapRowCol;
	}
	
	private int getColForCellData(String sheetName,  String cellData, int rowNum)
	{
		int totalColumns = this.excelParser.getColumnCount(sheetName, rowNum);
		for(int colNum = 1; colNum <= totalColumns ; colNum ++)
		{
			String text = this.excelParser.getCellData(sheetName, colNum, rowNum);
			if(text.equalsIgnoreCase(cellData))
			{
				return colNum;
			}
		}
		return -1;
	}	
	
	
	private int getTestCaseRowInTestDataSheets(String sheetName, int rowNum)
	{
		while(!this.excelParser.getCellData(sheetName, 1, rowNum).trim().equalsIgnoreCase("Testcase_Name"))
		{
			rowNum --;
		}
		return rowNum;
	}
	
	private int getTestCaseRowInSeedDataSheets(String sheetName, int rowNum)
	{
		while(this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName, rowNum).trim().isEmpty())
		{
			rowNum --;
		}
		return rowNum;
	}
	
	public boolean isRowSeededOrJIT(String sheetName, String colName, String expectedColValue, int rowNum)
	{
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, expectedColValue = %s, rowNum = %d", sheetName, colName,
				expectedColValue, rowNum));
		String cellData = this.excelParser.getCellData(sheetName, colName, rowNum);
		switch(expectedColValue)
		{
		case ISeedDataProcessor.seedDataTypeLongTerm :			
			return (cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm) || cellData.isEmpty());			
			
		case ISeedDataProcessor.seedDataTypeShortTerm :
			return cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm);
			
		default:
			return cellData.equalsIgnoreCase(expectedColValue);
			
		}
		
	}
	
	public Set<Integer> getTestCaseRowNumbers(String sheetName, String colName, String expectedColValue)
	{
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, expectedColValue = %s", sheetName, colName,
				expectedColValue));
		List<Integer> listSDRows = new ArrayList<Integer>();
		for (int rowNum = 3; rowNum <= this.excelParser.getRowCount(sheetName); rowNum++) {
			String cellData = this.excelParser.getCellData(sheetName, colName, rowNum);
			switch(expectedColValue)
			{
				case ISeedDataProcessor.seedDataTypeLongTerm :
				if(cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm) || cellData.isEmpty())
				{
					listSDRows.add(rowNum);
				}
				break;
				case ISeedDataProcessor.seedDataTypeShortTerm :
				if(cellData.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm))
				{
					listSDRows.add(rowNum);
				}	
					
				break;
				default :
				if(cellData.equalsIgnoreCase(expectedColValue))
				{
					listSDRows.add(rowNum);
				}
					
			}
			
		}
		LOG.debug(String.format("Rows Found In Sheet - %s, In ColName - %s, With expectedColValue - %s = %s", sheetName,
				colName, expectedColValue, Arrays.toString(listSDRows.toArray())));
		
		Set<Integer> setTestCaseRows = new HashSet<Integer>();
		for(int SDRow : listSDRows) {
			setTestCaseRows.add(this.getTestCaseRowInSeedDataSheets(sheetName, SDRow));
		}
		LOG.debug(String.format("Test Case Rows In Sheet - %s For SeedDataType - %s = %s", sheetName, expectedColValue, setTestCaseRows));
		return setTestCaseRows;
	}
	
	private boolean isTestCaseRowInTestDataSheets(String sheetName, int rowNum)
	{
		if(this.excelParser.getCellData(sheetName, 1, rowNum).trim().equalsIgnoreCase("Testcase_Name"))
		{
			return true;
		}
		return false;
	}
	
	public JSONObject convertToJSON(String sheetName)
	{
		JSONObject jo = new JSONObject();	
		JSONArray ja = null;
		Map<String, String> map = null;
		String testCaseReference = null;
		
		//get total rows
		int totalRows = this.excelParser.getRowCount(sheetName);
		
		for(int rowNum = 1; rowNum <= totalRows; rowNum ++)
		{
			
			//check for test case row
			if((!this.excelParser.isRowEmpty(sheetName, rowNum)) && (!isTestCaseRowInTestDataSheets(sheetName, rowNum)))
			{
				//get testCase row number
				int testCaseRowNumber = this.getTestCaseRowInTestDataSheets(sheetName, rowNum);
				//get number of columns for currentRowNumber
				int totalCols = this.excelParser.getColumnCount(sheetName, rowNum);
				//get test case reference
				testCaseReference = this.excelParser.getCellData(sheetName, 1, testCaseRowNumber + 1);
				map = new LinkedHashMap<String, String>();
				for(int colNum = 2; colNum <= totalCols; colNum ++)
				{
					String colName = this.excelParser.getCellData(sheetName, colNum, testCaseRowNumber);
					String colValue = this.excelParser.getCellData(sheetName, colNum, rowNum);
					map.put(colName, colValue);
				}
				if(jo.get(testCaseReference) == null)
				{
					ja = new JSONArray();
				}
				ja.add(map);
							
			}
			else
			{
				if(testCaseReference != null)
				{
					jo.put(testCaseReference, ja);
					testCaseReference = null;
				}
			}
		}
		
		return jo;
	}	
	
	public JSONObject convertToJSONObject(String [] sheetNames)
	{
		JSONObject joSheets = new JSONObject();
		for(String sheetName : sheetNames)
		{
			JSONObject joSheet = convertToJSON(sheetName);
			for(Entry<String, JSONArray> entry : ((Map<String, JSONArray>)joSheet).entrySet())
			{
				joSheets.put(entry.getKey(), entry.getValue());
			}
		}
		return joSheets;
	}
	
	public JSONObject convertToJSONObjectWithExcludedFiles(String commaSeparatedSeedDataSheets)
	{
		String[] exclusiveSheetNames = commaSeparatedSeedDataSheets.split(",");
		List<String> listSheets = this.excelParser.getAllSheets(exclusiveSheetNames);
		String[] sheetNames = listSheets.toArray(new String [0]);		
		return this.convertToJSONObject(sheetNames);
	}
	
	public JSONObject convertToJSONObjectWithExcludedFiles()	{
		
		List<String> listSheets = this.excelParser.getAllSheets(this.exclusiveSheets);
		String[] sheetNames = listSheets.toArray(new String [0]);		
		return this.convertToJSONObject(sheetNames);
	}
	
	
	
}
