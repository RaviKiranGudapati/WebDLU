package com.parser.excel;

/***********Revision History

 * 2. 07/31/2020, Bhagya/Vandana, Included Pipe[|] as separator when adding multiple data in a cell while point to testdata.json
 * 1. 07/07/2020, Bhagya Raj, Changes - Updated getCellData to include '|', ',' and ';' in the seed data excel sheet 
 *                              so that we can seperate the test data in the worklist addition column. ex: department;worklistTemplate|department1;worklistTemplate1 
 * 
 *
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.parser.json.JSONFileParser;

/**
 * @author DPradhan The Class ExcelParser.
 */
public class ExcelParser {

	private String excelFilepath = null;
	private String jsonFilePath = null;
	protected XSSFWorkbook workbook = null;
	private JSONFileParser jsonFileParser = null;
	private static final Logger LOG = Logger.getLogger(ExcelParser.class);

	/**
	 * Instantiates a new ExcelParser.
	 *
	 * @param excelFilePath the path
	 * @throws Exception 
	 */
	public ExcelParser(String excelFilePath) throws Exception {
		LOG.debug(String.format("Excel File Being Processed - %s", excelFilePath));
		this.excelFilepath = excelFilePath;
		try {
			FileInputStream fis = new FileInputStream(excelFilePath);
			LOG.debug(String.format("File Input Stream For %s Opened", excelFilePath));
			ZipSecureFile.setMinInflateRatio(0.005);
			this.workbook = new XSSFWorkbook(fis);
			LOG.debug(String.format("Workboook For %s Opened By Reading Input Stream", excelFilePath));
			fis.close();
			LOG.debug(String.format("File Input Stream For %s Closed", excelFilePath));
		} 
		catch(FileNotFoundException e)
		{
			LOG.error(e);
			LOG.error(String.format("File - %s Not Found ", excelFilePath));
			throw e;
		}
		catch (Exception e) {			
			LOG.error(e);
			throw e;
		}

	}

	/**
	 * Instantiates a new excel parser.
	 *
	 * @param excelFilePath the excel file path
	 * @param jsonFilePath  the json file path
	 * @throws Exception 
	 */
	public ExcelParser(String excelFilePath, String jsonFilePath) throws Exception {
		LOG.debug(String.format("Excel File Being Processed - %s", excelFilePath));
		this.excelFilepath = excelFilePath;
		this.jsonFilePath = jsonFilePath;
		try {
			FileInputStream fis = new FileInputStream(excelFilePath);
			LOG.debug(String.format("File Input Stream For %s Opened", excelFilePath));
			ZipSecureFile.setMinInflateRatio(0.005);
			this.workbook = new XSSFWorkbook(fis);
			LOG.debug(String.format("Workboook For %s Opened By Reading Input Stream", excelFilePath));
			fis.close();
			LOG.debug(String.format("File Input Stream For %s Closed", excelFilePath));
			this.jsonFileParser = new JSONFileParser(this.jsonFilePath);
		} 
		catch(FileNotFoundException e)
		{
			LOG.error(e);
			LOG.error(String.format("File - %s Not Found ", excelFilePath));
			throw e;
		}
		catch (Exception e) {			
			LOG.error(e);
			throw e;
		}

	}

	/**
	 * Gets the excel file path.
	 *
	 * @return the excel file path
	 */
	public String getExcelFilePath() {
		return this.excelFilepath;
	}

	/**
	 * Gets the json file path.
	 *
	 * @return the json file path
	 */
	public String getJsonFilePath() {
		return this.jsonFilePath;
	}

	/**
	 * Gets the workbook.
	 *
	 * @return the workbook
	 */
	public XSSFWorkbook getWorkbook() {
		return this.workbook;
	}

	/**
	 * Checks if is sheet exist.
	 *
	 * @param sheetName the sheet name
	 * @return true, if is sheet exist
	 */
	public boolean isSheetExist(String sheetName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			LOG.debug(String.format("Returning false As Sheet With Name - %s , Not Found ", sheetName));
			return false;
		} else {
			LOG.debug(String.format("Returns true "));
			return true;
		}
	}

	/**
	 * Checks if is merged cell.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @return true, if is merged cell
	 */
	public boolean isMergedCell(String sheetName, String colName) {
		boolean isMerged = false;
		int colNum = this.getColNumber(sheetName, colName);
		colNum = colNum - 1;
		XSSFRow row = this.getSheet(sheetName).getRow(0);
		for (int i = colNum + 1; i < row.getLastCellNum();) {
			if (row.getCell(i).getCellType() == CellType.BLANK) {
				isMerged = true;
				return isMerged;
			} else {
				isMerged = false;
				return isMerged;
			}

		}
		return isMerged;

	}

	/**
	 * Checks if is column empty.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param rowNum    the row num
	 * @return true, if is column empty
	 */
	public boolean isColumnEmpty(String sheetName, String colName, int rowNum) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s", sheetName, colName));

		// get spanned column numbers
		List<Integer> listSpannedColNums = this.getMergedColNumbers(sheetName, colName);
		for (int colNum : listSpannedColNums) {
			if (!(this.getCellData(sheetName, colNum, rowNum).trim().isEmpty())) {
				LOG.debug(String.format("Sheet Name = %s, colNum = %d, rowNum = %d Not Empty", sheetName, colNum,
						rowNum));
				return false;
			}
		}
		return true;

	}

	public boolean isRowEmpty(String sheetName, int rowNum) {

		for (int i = 1; i <= this.getColumnCount(sheetName, rowNum); i++) {
			if (!this.getCellData(sheetName, i, rowNum).trim().isEmpty()) {
				LOG.debug(String.format("Data Found In Sheet - %s, rowNum - %d", sheetName, rowNum));
				return false;
			}
		}

		return true;
	}

	/**
	 * Gets the sheet.
	 *
	 * @param sheetName the sheet name
	 * @return the sheet
	 */
	public XSSFSheet getSheet(String sheetName) {
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			return null;
		} else {
			XSSFSheet sheet = workbook.getSheetAt(index);
			return sheet;
		}

	}

	/**
	 * Gets the cell type.
	 *
	 * @param sheetName the sheet name
	 * @param colNum    the col num, index starts from 1
	 * @param rowNum    the row num, index starts from 1
	 * @return the cell type
	 */
	public CellType getCellType(String sheetName, int colNum, int rowNum) {
		// index starts from 0
		return this.getSheet(sheetName).getRow(rowNum - 1).getCell(colNum - 1).getCellType();
	}

	/**
	 * Gets the cell type.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name, index starts from 1
	 * @param rowNum    the row num, index starts from 1
	 * @return the cell type
	 */
	public CellType getCellType(String sheetName, String colName, int rowNum) {
		// index starts from 1
		int colNum = this.getColNumber(sheetName, colName);
		return this.getSheet(sheetName).getRow(rowNum - 1).getCell(colNum - 1).getCellType();
	}

	/**
	 * Gets the col number.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @return the col number - index base - 1
	 */
	public int getColNumber(String sheetName, String colName) {
		LOG.debug(String.format("Input Parameter - Sheet Name = %s, colName = %s", sheetName, colName));
		XSSFRow row = this.getSheet(sheetName).getRow(0);
		int colNum = -1;
		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName)) {
				colNum = i;
				LOG.debug(String.format("Column - %s Found In Column Number - %d ", colName, colNum + 1));
				break;
			}
		}

		LOG.debug(String.format("Returning ColNumber = %d For Column - %s, In Sheet -%s ", colNum, colName, sheetName));
		return colNum + 1;

	}

	/**
	 * Gets the col number.
	 *
	 * @param sheetName       the sheet name
	 * @param colName         the col name
	 * @param headerRowNumber the header row number
	 * @return the col number - index base - 1
	 */
	public int getColNumber(String sheetName, String colName, int headerRowNumber) {

		int colNum = -1;
		XSSFRow row = this.getSheet(sheetName).getRow(headerRowNumber - 1);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName)) {
				colNum = i;
				LOG.debug(String.format("Column - %s Found In Column Number - %d ", colName, colNum + 1));
				break;
			}
		}

		LOG.debug(String.format("Returning ColNumber = %d For Column - %s, In Sheet -%s ", colNum, colName, sheetName));
		return colNum + 1;

	}

	/**
	 * Gets the cell row num.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param cellValue the cell value
	 * @return the cell row num - index base - 1
	 */
	public int getCellRowNum(String sheetName, String colName, String cellValue) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, cellValue = %s", sheetName, colName,
				cellValue));
		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, colName, i).equalsIgnoreCase(cellValue)) {
				LOG.debug(String.format("Row Number  = %d ", i));
				return i;
			}
		}
		LOG.debug(String.format("Row Not Found, getCellRowNum returns  = %d ", -1));
		return -1;

	}

	/**
	 * Gets the cells row numbers.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param cellValue the cell value
	 * @return the cells row numbers
	 */
	public List<Integer> getCellsRowNumbers(String sheetName, String colName, String cellValue) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, cellValue = %s", sheetName, colName,
				cellValue));
		List<Integer> listRows = new ArrayList<Integer>();
		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, colName, i).equalsIgnoreCase(cellValue)) {
				listRows.add(i);
			}
		}
		LOG.debug(String.format("Rows Found In Sheet - %s, In ColName - %s, With CellValue - %s = %s", sheetName,
				colName, cellValue, Arrays.toString(listRows.toArray())));
		return listRows;
	}

	/**
	 * Gets the merged col numbers.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @return the merged col numbers - Index base - 1
	 */
	public List<Integer> getMergedColNumbers(String sheetName, String colName) {
		List<Integer> listColumns = new ArrayList<Integer>();
		int colNum = this.getColNumber(sheetName, colName);
		listColumns.add(colNum);
		XSSFRow row = this.getSheet(sheetName).getRow(0);
		for (int i = colNum; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getCellType() == CellType.BLANK) {
				listColumns.add(i + 1);
			} else {
				return listColumns;
			}

		}
		return listColumns;
	}

	/**
	 * Gets the used range row numbers.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param cellValue the cell value
	 * @return the used range row numbers
	 */
	public List<Integer> getUsedRangeRowNumbers(String sheetName, String colName, String cellValue) {

		List<Integer> cellUsedRange = new ArrayList<Integer>();
		int startRowForCellValueInSearch = -1;
		int totalRowsInSheet = this.getRowCount(sheetName);
		for (startRowForCellValueInSearch = 2; startRowForCellValueInSearch <= totalRowsInSheet; startRowForCellValueInSearch++) {

			// Look for data starting row
			if (!this.isRowEmpty(sheetName, startRowForCellValueInSearch) && this
					.getCellData(sheetName, colName, startRowForCellValueInSearch).trim().equalsIgnoreCase(cellValue)) {
				cellUsedRange.add(startRowForCellValueInSearch);
				break;
			}
		}

		if (startRowForCellValueInSearch < totalRowsInSheet) {
			for (int nextRowForCellValueInSearch = startRowForCellValueInSearch
					+ 1; nextRowForCellValueInSearch <= totalRowsInSheet; nextRowForCellValueInSearch++) {
				if (!this.isRowEmpty(sheetName, nextRowForCellValueInSearch) && (this
						.getCellData(sheetName, colName, nextRowForCellValueInSearch).trim().equalsIgnoreCase(cellValue)
						|| this.getCellData(sheetName, colName, nextRowForCellValueInSearch).trim().isEmpty())) {
					cellUsedRange.add(nextRowForCellValueInSearch);
				} else {
					break;
				}
			}
		}

		return cellUsedRange;
	}

	/**
	 * Gets the all sheets.
	 *
	 * @return the all sheets
	 */
	public List<String> getAllSheets() {
		List<String> listSheets = new ArrayList<String>();
		for (int i = 0; i < this.workbook.getNumberOfSheets(); i++) {
			listSheets.add(this.workbook.getSheetName(i));
			LOG.debug(String.format("Sheet Found - %s", this.workbook.getSheetName(i)));
		}
		return listSheets;
	}

	/**
	 * Gets the all sheets.
	 *
	 * @param exclusiveSheets the exclusive sheets
	 * @return the all sheets
	 */
	public List<String> getAllSheets(String[] exclusiveSheets) {
		List<String> listSheets = new ArrayList<String>();
		for (int i = 0; i < this.workbook.getNumberOfSheets(); i++) {
			if ((exclusiveSheets != null)
					&& (!Arrays.asList(exclusiveSheets).contains(this.workbook.getSheetName(i)))) {
				listSheets.add(this.workbook.getSheetName(i));
				LOG.debug(String.format("Sheet Found - %s", this.workbook.getSheetName(i)));
			}
		}
		return listSheets;
	}

	/**
	 * Gets the row count.
	 *
	 * @param sheetName the sheet name
	 * @return the row count
	 */
	public int getRowCount(String sheetName) {
		return this.getSheet(sheetName).getLastRowNum() + 1;
	}

	/**
	 * Gets the column count.
	 *
	 * @param sheetName the sheet name
	 * @return the column count
	 */
	public int getColumnCount(String sheetName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		if (!isSheetExist(sheetName))
			return -1;

		XSSFSheet sheet = this.getSheet(sheetName);
		XSSFRow row = sheet.getRow(0);

		if (row == null) {
			LOG.debug(String.format("No Header Row Found, Column Count = %d ", -1));
			return -1;
		}
		LOG.debug(String.format("Column Count = %d ", row.getLastCellNum()));
		return row.getLastCellNum();

	}

	/**
	 * Gets the column count.
	 *
	 * @param sheetName the sheet name
	 * @param rowNumber the row number
	 * @return the column count
	 */
	public int getColumnCount(String sheetName, int rowNumber) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, rowNumber = %d", sheetName, rowNumber));
		if (!isSheetExist(sheetName))
			return -1;

		XSSFSheet sheet = this.getSheet(sheetName);
		XSSFRow row = sheet.getRow(rowNumber - 1);

		if (row == null) {
			LOG.debug(String.format("No Header Row Found, Column Count = %d ", -1));
			return -1;
		}
		LOG.debug(String.format("Column Count = %d ", row.getLastCellNum()));
		return row.getLastCellNum();

	}

	/**
	 * Gets the cell data.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param rowNum    the row num
	 * @return the cell data
	 */
	public String getCellData(String sheetName, String colName, int rowNum) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, rowNum = %d", sheetName, colName,
				rowNum));
		int colNum = this.getColNumber(sheetName, colName);
		return this.getCellData(sheetName, colNum, rowNum);

	}

	/**
	 * Gets the cell data.
	 *
	 * @param sheetName the sheet name
	 * @param colNum    the col num
	 * @param rowNum    the row num
	 * @return the cell data
	 */
	public String getCellData(String sheetName, int colNum, int rowNum) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colNumber = %d, rowNum = %d", sheetName, colNum,
				rowNum));
		String text = null;
		try {
			if (rowNum <= 0) {
				LOG.debug(String.format("Returning Empty As rowNum = %d (Less Than Equal To Zero) ", rowNum));
				return null;
			}
			colNum = colNum - 1;
			if (colNum < 0) {
				LOG.debug(String.format("Returning Empty As colNum = %d (Less Than Zero) ", rowNum));
				return null;
			}

			XSSFRow row = this.getSheet(sheetName).getRow(rowNum - 1);
			if (row == null) {
				LOG.debug(String.format("Returning Empty As Row Not Found for Row Number - %d ", rowNum));
				return "";
			}
			XSSFCell cell = row.getCell(colNum);
			if (cell == null) {
				LOG.debug(String.format("Returning Empty As Cell Is Found To Be NULL "));
				return "";
			}

			if (cell.getCellType() == CellType.STRING || cell.getCellType() == CellType.FORMULA) {
				LOG.debug(String.format("Cell Type = STRING OR FORMULA "));
				text = cell.getStringCellValue();

			} else if (cell.getCellType() == CellType.NUMERIC) {
				LOG.debug(String.format("Cell Type = NUMERIC"));
				String cellText = String.valueOf(cell.getNumericCellValue());
				if (DateUtil.isCellDateFormatted(cell)) {
					// format in form of M/D/YY
					double d = cell.getNumericCellValue();

					Calendar cal = Calendar.getInstance();
					cal.setTime(DateUtil.getJavaDate(d));
					cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.MONTH) + 1 + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cellText;


				}

				text = cellText;
			} else if (cell.getCellType() == CellType.BLANK) {
				LOG.debug(String.format("Returning Empty As CellType Is Found To Be BLANK "));
				return "";
			} else {
				LOG.debug(String.format("Returning BOOLEAN In String Format As CellType Is Found To Be Boolean "));
				LOG.debug(String.format("Cell Text Returned = %s ", cell.getBooleanCellValue()));
				text = String.valueOf(cell.getBooleanCellValue());
			}
			if(text.contains(";")|| text.contains(",") || text.contains("|")) {// multiple data in a cell will point to testdata.json
				if(text.contains("data.")) {
					//split with ; and update the value from Json
					/*Set<String> lookupKeys =new HashSet<>();
					for (String key: text.split(";")) {
						for (String key1: key.split(",")) {
						for(){
						
						}
							lookupKeys.add(key1);
						}
					}
					LOG.debug("1111111111111111-> "+lookupKeys.toString());
					text = text.replaceAll("\\[", "").replaceAll("\\]", "");
					for(String key: lookupKeys) {
						String data = this.jsonFileParser.getValueFromJsonObject(key);
						key = key.replaceAll("\\[", "").replaceAll("\\]", "");
						text = text.replaceAll(key, data);
						data.gemdssd();12312
					}*/
					
					String finalVal = "";
					for (String semiColumnKey: text.split(";")) {
						String val1="";
						for (String commaKey: semiColumnKey.split(",")) {
							String val="";
							for (String pipeKey: commaKey.split("[|]")) {
							String data = this.jsonFileParser.getValueFromJsonObject(pipeKey);
							if(val.equals("")) {
								val = data;
							}else {
								val = val+"|"+data;
							}
							}
							if(val1.equals("")) {
								val1 = val;
							}else {
								val1 = val1+","+val;
							}
						}
						if(finalVal.equals("")) {
							finalVal = val1;
						}else {
							finalVal = finalVal+";"+val1;
						}
					}
					return finalVal;
				}else {
					return text;
				}
//				return text;
			}else {
				if (text.toLowerCase().startsWith("data.")) {
					String testData = this.jsonFileParser.getValueFromJsonObject(text);
					return testData;

				} else {
					return text;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			LOG.error(String.format("Returns null "));
			return null;
		}
	}

	/**
	 * Gets the all columns.
	 *
	 * @param sheetName the sheet name
	 * @return the all columns
	 */
	public List<String> getAllColNames(String sheetName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		List<String> listColumn = new ArrayList<String>();
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			LOG.debug(String.format("Returning EmptyList As Sheet With Name - %s , Not Found ", sheetName));
			return listColumn;
		}
		XSSFSheet sheet = workbook.getSheetAt(index);
		XSSFRow row = sheet.getRow(0);
		for (int i = 0; i < row.getLastCellNum(); i++) {
			String colName = row.getCell(i).getStringCellValue().trim();
			LOG.debug(String.format("Column - %s Found In Column Number - %d ", colName, i + 1));
			listColumn.add(colName);
		}
		return listColumn;
	}

	/**
	 * Gets the all columns.
	 *
	 * @param sheetName    the sheet name
	 * @param afterColName the after col name
	 * @return the all columns Following After afterColName
	 */
	public List<String> getAllColNames(String sheetName, String afterColName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		int colNum = this.getColNumber(sheetName, afterColName);
		List<String> listColumn = new ArrayList<String>();
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			LOG.debug(String.format("Returning EmptyList As Sheet With Name - %s , Not Found ", sheetName));
			return listColumn;
		}
		XSSFSheet sheet = workbook.getSheetAt(index);
		XSSFRow row = sheet.getRow(0);
		for (int i = colNum; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getCellType() != CellType.BLANK) {
				String colName = row.getCell(i).getStringCellValue().trim();
				LOG.debug(String.format("Column - %s Found In Column Number - %d ", colName, i + 1));
				listColumn.add(colName);
			}
		}
		return listColumn;
	}

	/**
	 * Gets the row col for cell data.
	 *
	 * @param sheetName the sheet name
	 * @param cellData  the cell data
	 * @return the row col for cell data
	 */
	public Map<String, Integer> getRowColForCellData(String sheetName, String cellData) {
		int totalRows = this.getRowCount(sheetName);
		int totalColumns = this.getColumnCount(sheetName);
		Map<String, Integer> mapRowCol = new HashMap<String, Integer>();
		// initialize mapRowCol map
		mapRowCol.put("rowNum", -1);
		mapRowCol.put("colNum", -1);

		for (int rowNum = 1; rowNum <= totalRows; rowNum++) {
			for (int colNum = 1; colNum <= totalColumns; colNum++) {
				String text = this.getCellData(sheetName, colNum, rowNum);
				if (text.equalsIgnoreCase(cellData)) {
					mapRowCol.put("rowNum", rowNum);
					mapRowCol.put("colNum", colNum);
					return mapRowCol;
				}
			}
		}
		return mapRowCol;
	}

	/**
	 * Gets the col for cell data.
	 *
	 * @param sheetName the sheet name
	 * @param cellData  the cell data
	 * @param rowNum    the row num
	 * @return the col for cell data
	 */
	public int getColForCellData(String sheetName, String cellData, int rowNum) {
		int totalColumns = this.getColumnCount(sheetName);
		for (int colNum = 1; colNum <= totalColumns; colNum++) {
			String text = this.getCellData(sheetName, colNum, rowNum);
			if (text.equalsIgnoreCase(cellData)) {
				return colNum;
			}
		}
		return -1;
	}

	/**
	 * ********* APIS To Handle Merged Cells In Sheet **********************.
	 *
	 * @param sheetName  the sheet name
	 * @param colName    the col name
	 * @param subColName the sub col name
	 * @param rowNum     the row num
	 * @return the cell data
	 */

	public String getCellData(String sheetName, String colName, String subColName, int rowNum) {
		if (isMergedCell(sheetName, colName)) {
			LOG.debug(String.format("Column - %s Is Merged Cell", colName));
			int colNum = -1;
			XSSFRow row = this.getSheet(sheetName).getRow(1);
			List<Integer> subColsRange = this.getMergedColNumbers(sheetName, colName);
			for (int col : subColsRange) {
				if (row.getCell(col - 1).getStringCellValue().trim().equalsIgnoreCase(subColName)) {
					colNum = col;
					break;
				}
			}
			return this.getCellData(sheetName, colNum, rowNum);

		} else {
			LOG.debug(String.format("Column - %s Is Not Merged Cell", colName));
			return this.getCellData(sheetName, colName, rowNum);
		}
	}

	/**
	 * Gets the cell data.
	 *
	 * @param sheetName      the sheet name
	 * @param filterColName  the filter col name
	 * @param filterColData  the filter col data
	 * @param dataColName    the data col name
	 * @param dataSubColName the data sub col name
	 * @param rowNum         the row num
	 * @return the cell data
	 */
	public String getCellData(String sheetName, String filterColName, String filterColData, String dataColName,
			String dataSubColName, int rowNum) {
		List<Integer> dataUsedRangeRows = this.getUsedRangeRowNumbers(sheetName, filterColName, filterColData);
		if (dataUsedRangeRows.contains(rowNum)) {
			return this.getCellData(sheetName, dataColName, dataSubColName, rowNum);
		} else {
			return null;
		}

	}

	/**
	 * Gets the cells data.
	 *
	 * @param sheetName      the sheet name
	 * @param filterColName  the filter col name
	 * @param filterColData  the filter col data
	 * @param dataColName    the data col name
	 * @param dataSubColName the data sub col name
	 * @return the cells data
	 */
	public List<String> getCellsData(String sheetName, String filterColName, String filterColData, String dataColName,
			String dataSubColName) {
		List<String> listData = new ArrayList<String>();
		List<Integer> dataUsedRangeRows = this.getUsedRangeRowNumbers(sheetName, filterColName, filterColData);
		for (int rowNum : dataUsedRangeRows) {
			listData.add(this.getCellData(sheetName, dataColName, dataSubColName, rowNum));
		}
		return listData;
	}

	/*****************
	 * APIs To Handle Merge Cells Done
	 *********************************************/

	/**
	 * Sets the cell data.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param rowNum    the row num
	 * @param data      the data
	 * @return true, if successful
	 */
	public boolean setCellData(String sheetName, String colName, int rowNum, String data) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, rowNum = %d, data = %s", sheetName,
				colName, rowNum, data));
		try {
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0) {
				LOG.debug(String.format("Returning false As rowNum = %d (Less Than Equal To Zero) ", rowNum));
				return false;
			}
			XSSFSheet sheet = this.getSheet(sheetName);
			XSSFRow row = sheet.getRow(0);

			int colNum = this.getColNumber(sheetName, colName);
			colNum = colNum - 1;
			if (colNum == -1) {
				LOG.debug(String.format("Returning false As Column - %s, In Sheet -%s Not Found ", colName, sheetName));
				return false;
			}

			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null) {
				row = sheet.createRow(rowNum - 1);
				LOG.debug(String.format("New Row Was Created In RowNumber - %d ", rowNum));
			}

			XSSFCell cell = row.getCell(colNum);
			if (cell == null) {
				cell = row.createCell(colNum);
				LOG.debug(String.format("New Cell Was Created In RowNumber - %d , columnNumber - %d", rowNum,
						colNum + 1));
			}

			// cell style
			// CellStyle cs = workbook.createCellStyle();
			// cs.setWrapText(true);
			// cell.setCellStyle(cs);
			cell.setCellValue(data);
			LOG.debug(String.format("Cell Was Updated With Data - %s", data));
			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created To Write Into File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook - %s Was Updated ", excelFilepath));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed To Write Into File - %s ", excelFilepath));

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns True "));
		return true;
	}

	/**
	 * Highlight cell.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param rowNum    the row num
	 * @param colorCode the color code
	 * @return true, if successful
	 */
	public boolean highlightCell(String sheetName, String colName, int rowNum, HSSFColorPredefined colorCode) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, rowNum = %d, colorCode = %s",
				sheetName, colName, rowNum, colorCode));
		try {
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0) {
				LOG.debug(String.format("Returning false As rowNum = %d (Less Than Equal To Zero) ", rowNum));
				return false;
			}

			int colNum = this.getColNumber(sheetName, colName);
			colNum = colNum - 1;
			if (colNum == -1) {
				LOG.debug(String.format("Returning false As Column - %s, In Sheet -%s Not Found ", colName, sheetName));
				return false;
			}
			XSSFSheet sheet = this.getSheet(sheetName);
			sheet.autoSizeColumn(colNum);
			XSSFRow row = sheet.getRow(rowNum - 1);
			if (row == null) {
				row = sheet.createRow(rowNum - 1);
				LOG.debug(String.format("New Row Was Created In RowNumber - %d ", rowNum));
			}

			XSSFCell cell = row.getCell(colNum);
			if (cell == null) {
				cell = row.createCell(colNum);
				LOG.debug(String.format("New Cell Was Created In RowNumber - %d , columnNumber - %d", rowNum,
						colNum + 1));
			}

			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(colorCode.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			cell.setCellStyle(style);
			LOG.debug(String.format("Style Was Updated For Row - %d, colName - %s ", rowNum, colName));
			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created To Write Into File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook - %s Was Updated ", excelFilepath));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed To Write Into File - %s ", excelFilepath));

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns True "));
		return true;
	}

	/**
	 * Sets the cell data.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param rowNum    the row num
	 * @param data      the data
	 * @param url       the url
	 * @return true, if successful
	 */
	public boolean setCellData(String sheetName, String colName, int rowNum, String data, String url) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s, rowNum = %d, data = %s, url = %s",
				sheetName, colName, rowNum, data, url));
		try {
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);

			if (rowNum <= 0) {
				LOG.debug(String.format("Returning false As rowNum = %d (Less Than Equal To Zero) ", rowNum));
				return false;
			}
			XSSFSheet sheet = this.getSheet(sheetName);
			XSSFRow row = sheet.getRow(0);
			int colNum = this.getColNumber(sheetName, colName);
			colNum = colNum - 1;
			if (colNum == -1) {
				LOG.debug(String.format("Returning false As Column - %s, In Sheet -%s Not Found ", colName, sheetName));
				return false;
			}

			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null) {
				row = sheet.createRow(rowNum - 1);
				LOG.debug(String.format("New Row Was Created In RowNumber - %d ", rowNum));
			}

			XSSFCell cell = row.getCell(colNum);
			if (cell == null) {
				cell = row.createCell(colNum);
				LOG.debug(String.format("New Cell Was Created In RowNumber - %d , columnNumber - %d", rowNum,
						colNum + 1));
			}

			cell.setCellValue(data);
			LOG.debug(String.format("Cell Was Updated With Data - %s", data));
			XSSFCreationHelper createHelper = workbook.getCreationHelper();

			// cell style for hyperlinks
			// by default hypelrinks are blue and underlined
			CellStyle hlink_style = workbook.createCellStyle();
			XSSFFont hlink_font = workbook.createFont();
			hlink_font.setUnderline(XSSFFont.U_SINGLE);
			hlink_font.setColor(IndexedColors.BLUE.getIndex());
			hlink_style.setFont(hlink_font);
			// hlink_style.setWrapText(true);

			XSSFHyperlink link = createHelper.createHyperlink(HyperlinkType.FILE);
			link.setAddress(url);
			cell.setHyperlink(link);
			cell.setCellStyle(hlink_style);

			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created To Write Into File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook - %s Was Updated ", excelFilepath));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed To Write Into File - %s ", excelFilepath));

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns True "));
		return true;
	}

	/**
	 * Adds the sheet.
	 *
	 * @param sheetName the sheetname
	 * @return true, if successful
	 */
	public boolean addSheet(String sheetName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		FileOutputStream fileOut;
		try {
			workbook.createSheet(sheetName);
			LOG.debug(String.format("Sheet Created With Sheet Name - %s ", sheetName));
			fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created For File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook Was Updated Using File Output Stream "));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed For File - %s ", excelFilepath));
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns true "));
		return true;
	}

	/**
	 * Removes the sheet.
	 *
	 * @param sheetName the sheet name
	 * @return true, if successful
	 */
	public boolean removeSheet(String sheetName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s", sheetName));
		int index = workbook.getSheetIndex(sheetName);
		if (index == -1) {
			LOG.debug(String.format("Returning false As Sheet With Name - %s , Not Found ", sheetName));
			return false;
		}

		FileOutputStream fileOut;
		try {
			workbook.removeSheetAt(index);
			LOG.debug(String.format("Sheet Removed With Sheet Name - %s ", sheetName));
			fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created For File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook Was Updated Using File Output Stream "));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed For File - %s ", excelFilepath));
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns true "));
		return true;
	}

	/**
	 * Adds the column.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @return true, if successful
	 */
	public boolean addColumn(String sheetName, String colName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, columnName = %s", sheetName, colName));

		try {
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = this.getSheet(sheetName);

			XSSFRow row = sheet.getRow(0);
			if (row == null) {
				row = sheet.createRow(0);
				LOG.debug(String.format("Header Row Was Created"));
			}

			XSSFCell cell = null;
			if (row.getLastCellNum() == -1)
				cell = row.createCell(0);
			else
				cell = row.createCell(row.getLastCellNum());

			cell.setCellValue(colName);
			LOG.debug(String.format("Column Header Was Created"));

			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created For File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook Was Updated Using File Output Stream "));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed For File - %s ", excelFilepath));

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}

		LOG.debug(String.format("Returns true "));
		return true;

	}

	/**
	 * Adds the column.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @param colorCode the color code
	 * @return true, if successful
	 */
	public boolean addColumn(String sheetName, String colName, HSSFColorPredefined colorCode) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, columnName = %s", sheetName, colName));

		try {
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);
			int index = workbook.getSheetIndex(sheetName);
			if (index == -1) {
				LOG.debug(String.format("Returning false As Sheet With Name - %s , Not Found ", sheetName));
				return false;
			}

			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(colorCode.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

			XSSFSheet sheet = workbook.getSheetAt(index);

			XSSFRow row = sheet.getRow(0);
			if (row == null) {
				row = sheet.createRow(0);
				LOG.debug(String.format("Header Row Was Created"));
			}

			XSSFCell cell = null;
			if (row.getLastCellNum() == -1)
				cell = row.createCell(0);
			else
				cell = row.createCell(row.getLastCellNum());

			cell.setCellValue(colName);
			LOG.debug(String.format("Column Header Was Created"));
			cell.setCellStyle(style);

			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created For File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook Was Updated Using File Output Stream "));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed For File - %s ", excelFilepath));

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}

		LOG.debug(String.format("Returns true "));
		return true;

	}

	/**
	 * Removes the column.
	 *
	 * @param sheetName the sheet name
	 * @param colNum    the col num
	 * @return true, if successful
	 */
	public boolean removeColumn(String sheetName, int colNum) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colNum = %d", sheetName, colNum));
		try {
			if (!isSheetExist(sheetName)) {
				LOG.debug(String.format("Returning false As Sheet With Name - %s , Not Found ", sheetName));
				return false;
			}
			FileInputStream fis = new FileInputStream(excelFilepath);
			workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			XSSFRow row = null;
			XSSFCell cell = null;
			colNum = colNum - 1;
			for (int i = 0; i < getRowCount(sheetName); i++) {
				row = sheet.getRow(i);
				if (row != null) {
					cell = row.getCell(colNum);
					if (cell != null) {
						row.removeCell(cell);
						LOG.debug(String.format("Column Number - %d Is Removed From Row - %d", colNum, i + 1));
					}
				}
			}
			FileOutputStream fileOut = new FileOutputStream(excelFilepath);
			LOG.debug(String.format("File Output Stream Was Created For File - %s ", excelFilepath));
			workbook.write(fileOut);
			LOG.debug(String.format("Workbook Was Updated Using File Output Stream "));
			fileOut.close();
			LOG.debug(String.format("File Output Stream Was Closed For File - %s ", excelFilepath));
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getStackTrace());
			LOG.debug(String.format("Returns false "));
			return false;
		}
		LOG.debug(String.format("Returns true "));
		return true;

	}

	/**
	 * Removes the column.
	 *
	 * @param sheetName the sheet name
	 * @param colName   the col name
	 * @return true, if successful
	 */
	public boolean removeColumn(String sheetName, String colName) {
		LOG.debug(String.format("Input Parameters - Sheet Name = %s, colName = %s", sheetName, colName));
		int colNum = this.getColNumber(sheetName, colName);
		return removeColumn(sheetName, colNum);

	}

	/**
	 * Adds the hyper link.
	 *
	 * @param sheetName         the sheet name
	 * @param screenShotColName the screenshot column name
	 * @param testCaseName      the test case name
	 * @param index             the index
	 * @param url               the url
	 * @param message           the message
	 * @return true, if successful
	 */
	public boolean addHyperLink(String sheetName, String screenShotColName, String testCaseName, int index, String url,
			String message) {

		url = url.replace('\\', '/');
		if (!isSheetExist(sheetName))
			return false;

		for (int i = 2; i <= getRowCount(sheetName); i++) {
			if (getCellData(sheetName, 0, i).equalsIgnoreCase(testCaseName)) {
				setCellData(sheetName, screenShotColName, i + index, message, url);
				break;
			}
		}

		return true;
	}

}
