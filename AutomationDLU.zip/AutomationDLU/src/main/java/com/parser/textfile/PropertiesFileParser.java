/**
 * @author DPradhan
 */
package com.parser.textfile;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.utils.ReusableUtils;

/**
 * The Class PropertiesFileParser.
 */
public class PropertiesFileParser {
	private static final Logger LOG = Logger.getLogger(PropertiesFileParser.class);
	private String path = null;
	Properties prop = null;

	/**
	 * Instantiates a new properties file parser.
	 *
	 * @param path the path
	 */
	public PropertiesFileParser(String path) {

		try {
			this.path = path;
			this.prop = ReusableUtils.getConfigPropertyObject(this.path);

		} catch (Exception e) {
			LOG.error(e);
			LOG.info(String.format("Error Encountered - %s", e.getMessage()));
		}

	}

	/**
	 * Gets the config property.
	 *
	 * @param sKeyName the s key name
	 * @return the config property
	 */
	public String getConfigProperty(String sKeyName) {
		String propertyVal = this.prop.getProperty(sKeyName).trim();
		LOG.debug(String.format("keyName = %s, keyValue = %s", sKeyName, propertyVal));
		return propertyVal;
	}

}
