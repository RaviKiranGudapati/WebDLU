package com.utils;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;  

public class DbUtils{  
	Connection conn = null;

	public void connectDatabase(String server, String dbName, String userId, String password) throws SQLException {
		conn = DriverManager.getConnection("jdbc:sqlserver://"+server+":1433;databaseName="+dbName, userId, password);
		conn.setAutoCommit(false);
	}

	public boolean executeSqlFile(String filePath) throws Exception{
		String content = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);

		try{
			conn.createStatement().executeUpdate(content);
			conn.commit();  
			System.out.println("record successfully saved");  
			return true;
		}catch(Exception e){
			conn.rollback();
			return false;
		}
	}

	public void closeConnection() throws SQLException {
		conn.close();
	}
}  