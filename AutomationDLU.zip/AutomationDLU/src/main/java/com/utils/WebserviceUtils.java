package com.utils;

import java.util.Map;

import org.apache.log4j.Logger;

import com.client.webservice.IWebServiceResponseKeys;
import com.report.IReporter;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class WebserviceUtils {
	private static final Logger LOG = Logger.getLogger(WebserviceUtils.class);
	protected String token = null;
	protected String baseURL = null;
	protected IReporter reporter = null;
	protected JsonUtils jsonUtils = new JsonUtils();
	protected Map<String, Object> mapWebServiceResponses = null;

	protected WebserviceUtils(String baseURL) {
		this.baseURL = baseURL;
		RestAssured.baseURI = this.baseURL;
	}

	protected WebserviceUtils(String baseURL, Map<String, Object> mapWebServiceResponses) {
		this(baseURL);
		this.mapWebServiceResponses = mapWebServiceResponses;
	}

	protected WebserviceUtils(String baseURL, Map<String, Object> mapWebServiceResponses, IReporter reporter) {
		this(baseURL, mapWebServiceResponses);
		this.reporter = reporter;
	}

	protected Map<String, Object> getWebServiceResponses() {
		return this.mapWebServiceResponses;
	}

	protected IReporter getReporter() {
		return this.reporter;
	}

	protected Response runWebServiceRequest(String contentType, String payload, String endPoint, Method reqType) {
		RequestSpecification httpRequest = RestAssured.given().contentType(contentType).body(payload);
		if (token != null && !token.isEmpty()) {
			httpRequest = httpRequest.header("token", token);
		}
		Response response = null;
		try {
			response = httpRequest.request(reqType, endPoint);
			LOG.debug(String.format("Successfully Executed WebService Request - %s \n Response = %s", httpRequest,
					response));
			if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {

				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_SUCCESS));
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("%s - %s, URL - %s , Response - %d",
							IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
							this.baseURL + endPoint, response.getStatusCode()));
				}
			} else {
				System.out.println(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_FAILURE));
				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_FAILURE));
				if (this.reporter != null) {
					this.reporter.logFailure(String.format("%s - %s, URL - %s , Response - %d",
							IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
							this.baseURL + endPoint, response.getStatusCode()));
				}
				throw new RuntimeException(String.format("Failure response for api: %s", endPoint));
			}
			LOG.info(String.format("%s - %s, URL - %s, Response - %d", IWebServiceResponseKeys.LOGICAL_WS_NAME,
					ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode()));
			return response;
		} catch (RuntimeException e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logException(e);
			}
			throw e;
		}
	}
	
	protected Response runWebServiceRequestsupressfailure(String contentType, String payload, String endPoint, Method reqType) {
		RequestSpecification httpRequest = RestAssured.given().contentType(contentType).body(payload);
		if (token != null && !token.isEmpty()) {
			httpRequest = httpRequest.header("token", token);
		}
		Response response = null;
		try {
			response = httpRequest.request(reqType, endPoint);
			LOG.debug(String.format("Successfully Executed WebService Request - %s \n Response = %s", httpRequest,
					response));
			if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {

				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_SUCCESS));
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("%s - %s, URL - %s , Response - %d",
							IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
							this.baseURL + endPoint, response.getStatusCode()));
				}
			} else {
				System.out.println(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_FAILURE));
				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_FAILURE));
				
				throw new RuntimeException(String.format("Failure response for api: %s", endPoint));
			}
			LOG.info(String.format("%s - %s, URL - %s, Response - %d", IWebServiceResponseKeys.LOGICAL_WS_NAME,
					ReusableUtils.getCallingMethodName(), this.baseURL + endPoint, response.getStatusCode()));
			return response;
		} catch (RuntimeException e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logException(e);
			}
			throw e;
		}
	}
}