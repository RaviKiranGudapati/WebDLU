/**
 * JSON Utility
 * @Last Updated - 04/10/2020
 */

package com.utils;

/***********Revision History
 * 2. 09/07/2020, Bhagy/Narasimha - Added new method updateJSONObjwithChildOfJSONArry to update parent json by adding a anew childjson object 
 * 1. 07/07/2020, Bhavani, Changes - Updated String keyValue = null to  Object keyValue = null;
 * 
 *
 */

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;

public class JsonUtils {
	private static final Logger LOG = Logger.getLogger(JsonUtils.class);

	/**
	 * @author Bhagya Raj Gets the JSON file as an object.
	 * @param filePath the path of the Json File
	 * @return the JSON Object
	 * @throws Exception the exception
	 */
	public Object getJsonFileAsObject(String filePath) throws Exception {
		FileReader read = new FileReader(filePath);
		// Read JSON file
		JSONParser jsonParser = new JSONParser();
		return jsonParser.parse(read);
	}

	/**
	 * @author Bhagya Raj Gets the value for a key from the json
	 * @param json the json in String format
	 * @param key  the value of the Json to be returned
	 * @return the returned string value
	 * @throws Exception the exception
	 */
	public String getValueFromJsonObject(String json, String key) throws Exception {
		JSONObject obj = new JSONObject(json);
		return obj.get(key).toString();
	}

	/**
	 * @author Bhagya Raj Gets the JSONObject from a string
	 * @param json the json in String format
	 * @return the JSON Object
	 * @throws Exception the exception
	 */
	public JSONObject returnJsonObjectFromString(String json) throws Exception {
		JSONObject obj = new JSONObject(json);
		return obj;
	}

	/**
	 * @author Bhagya Raj Parse the JSONArray from a string
	 * @param jsonArray the json in JsonArray format
	 * @return the JSONArray Object
	 * @throws Exception the exception
	 */
	public org.json.JSONArray returnJsonArrayFromString(String jsonArray) throws Exception {
		org.json.JSONArray obj = new org.json.JSONArray(jsonArray);
		return obj;
	}

	/**
	 * @author Bhagya Raj Gets the Sub JsonElement for a key from the json
	 * @param json the json in String format
	 * @param key  the value of the Json to be returned
	 * @return the returned JsonObject value
	 * @throws Exception the exception
	 */
	public JSONObject getSubJsonElementFromJsonObject(String json, String key) throws Exception {
		JSONObject obj = new JSONObject(json);
		return (JSONObject) obj.get(key);
	}

	/**
	 * @author Bhagya Raj Gets the value for a key from the json
	 * @param json  the json in String format
	 * @param key   name of the object to update
	 * @param value the Object to be updated
	 * @return the returned JsonObject as String
	 * @throws Exception the exception
	 */
	public String updateOneJsonElement(String jsonObj, String key, Object value) throws Exception {
		JSONObject obj = new JSONObject(jsonObj);
		obj.put(key, value);
		return obj.toString();
	}

	/**
	 * @author Bhagya Raj Gets the value for a key from the json
	 * @param json  the json in String format
	 * @param key   name of the object to update
	 * @param value the int to be updated
	 * @return the returned JsonObject as String
	 * @throws Exception the exception
	 */
	public String updateOneJsonElement(String jsonObj, String key, int value) throws Exception {
		JSONObject obj = new JSONObject(jsonObj);
		obj.put(key, value);
		return obj.toString();
	}

	/**
	 * @author Bhagya Raj Gets the value for a key from the json
	 * @param json  the json in String format
	 * @param key   name of the object to update
	 * @param value the boolean to be updated
	 * @return the returned JsonObject as String
	 * @throws Exception the exception
	 */
	public String updateOneJsonElement(String jsonObj, String key, boolean value) throws Exception {
		JSONObject obj = new JSONObject(jsonObj);
		obj.put(key, value);
		return obj.toString();
	}

	/**
	 * @author Bhagya Raj Update the parent Json with the childJson Passed
	 * @param parentObj the Parent json in JSONObject format
	 * @param key       name of the object to update
	 * @param childObj  the child json in JSONObject format
	 * @return the returned JsonObject as String
	 * @throws Exception the exception
	 */
	public String updateOneJsonElement(JSONObject parentObj, String key, JSONObject childObj) throws Exception {
		parentObj.put(key, childObj);
		return parentObj.toString();
	}

	/**
	 * @author DPradhan Gets the JSON array.
	 *
	 * @param jsonObject the json object
	 * @param key        the key
	 * @return the JSON array
	 * @throws Exception the exception
	 */
	public JSONArray getJSONArray(org.json.simple.JSONObject jsonObject, String key) throws Exception {
		JSONArray jsonArrayObj = null;
		jsonArrayObj = (JSONArray) jsonObject.get(key);
		if (jsonArrayObj == null) {
			LOG.debug(String.format("Invalid Key - %s", key));
			throw new Exception(String.format("Invalid Key - %s", key));
		}
		return jsonArrayObj;
	}

	/**
	 * @author DPradhan Gets the value from JSON array.
	 *
	 * @param jsonArrayObject the json array object
	 * @param key             the key
	 * @param dataSequence    the data data Sequnce [num]
	 * @return the value from JSON array
	 * @throws Exception the exception
	 */
	public String getValueFromJSONArray(JSONArray jsonArrayObject, String key, int dataSequence) throws Exception {
		Object keyValue = null;
		if (jsonArrayObject == null) {
			LOG.debug(String.format("JSONArray Input (1st Parameter) Can't Be Null"));
			throw new Exception(String.format("JSONArray Input (1st Parameter) Can't Be Null"));
		}
		if (dataSequence <= 0) {
			LOG.debug(String.format(
					"Invalid DataSequence - DataSequence Provided Is %d, It Can't Be Less Than Or Equal To Zero",
					dataSequence));
			throw new Exception(String.format(
					"Invalid DataSequence - DataSequence Provided Is %d, It Can't Be Less Than Or Equal To Zero",
					dataSequence));
		}
		int arraySize = jsonArrayObject.size();
		if (dataSequence > arraySize) {
			LOG.debug(String.format(
					"Invalid DataSequence - Key Provided Is %d, Can't Be Greater Than Max. Size Of Data Sets - %d",
					dataSequence, arraySize));
			throw new Exception(String.format(
					"Invalid DataSequence - Key Provided Is %d, Can't Be Greater Than Max. Size Of Data Sets - %d",
					dataSequence, arraySize));
		}
		Object obj = jsonArrayObject.get(dataSequence - 1);

		if (obj instanceof Map) {
			LOG.debug(String.format("JSONArray Was Found To Be Map"));
			try {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>) obj;
				keyValue = map.get(key);
				if (keyValue == null) {
					LOG.debug(String.format("Invalid Key - %s, Key Does Not Exist", key));
					throw new Exception(String.format("Invalid Key - %s, Key Does Not Exist", key));
				}
			} catch (Exception ex) {
				LOG.debug(String.format("JSONArray Was Not Found To Be Map<String, String>"));
				LOG.error(ex);
				throw (ex);
			}
		} else {
			LOG.debug(String.format("Parsing Error - JSONArray Was Not Found To Be Map"));
			throw new Exception("Parsing Error - JSONArray Was Not Found To Be Map");
		}
		LOG.debug(String.format("Key = %s, Value Returned = %s", key, keyValue.toString()));
		return keyValue.toString();

	}

	/**
	 * @author Bhagya Raj Gets the value from the json using the JsonPath
	 * @param json  the json in String format
	 * @param xpath JsonPath of the value looking for
	 * @return the returned value as String
	 * @throws ParseException
	 * @throws Exception      the exception
	 */
	public Object getObjectFromJsonXpath(String jsonObject, String xpath) throws ParseException {

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(jsonObject);

		return getObjectFromJsonXpath(obj, xpath);
	}

	/**
	 * @author Bhagya Raj Updates the value from the json using the JsonPath
	 * @param json  the json in String format
	 * @param xpath JsonPath of the value looking for
	 * @param value value to be updated for the JsonPath
	 * @return the Updated Json as String
	 * @throws ParseException
	 * @throws Exception      the exception
	 */
	public Object updateObjectJsonXpath(String jsonObject, String xpath, String value) throws ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(jsonObject);
		DocumentContext doc = null;
		try {
			String oldVal = JsonPath.parse(obj).read(xpath).toString();
			LOG.debug(String.format("oldVal = %s", oldVal));
			doc = JsonPath.parse(obj).set(xpath, value);
		} catch (NullPointerException e) {
			doc = JsonPath.parse(obj).set(xpath, value);
		} catch (PathNotFoundException e1) {
			String key = "";
			for (String val : xpath.split("[.]")) {
				key = val;
			}
			doc = JsonPath.parse(obj).put(xpath, key, value);
		}
		return doc.jsonString();
	}

	/**
	 * @author Bhagya Raj Updates the value from the json using the JsonPath
	 * @param json  the json in String format
	 * @param xpath JsonPath of the value looking for
	 * @param value value to be updated for the JsonPath
	 * @return the Updated Json as String
	 * @throws ParseException
	 * @throws Exception      the exception
	 */
	public Object updateObjectJsonXpath(String jsonObject, String xpath, Object value) throws ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(jsonObject);
		DocumentContext doc = null;
		try {
			String oldVal = JsonPath.parse(obj).read(xpath).toString();
			LOG.debug(String.format("oldVal = %s", oldVal));
			doc = JsonPath.parse(obj).set(xpath, value);
		} catch (NullPointerException e) {
			doc = JsonPath.parse(obj).set(xpath, value);
		} catch (PathNotFoundException e1) {
			String key = "";
			for (String val : xpath.split("[.]")) {
				key = val;
			}
			doc = JsonPath.parse(obj).put(xpath, key, value);
		}
		return doc.jsonString();
	}

	/**
	 * @author Bhavani Prasad Returns JSONObject from a given JSONArray based upon a
	 *         key and value
	 * @param jsonArray the jsonArray
	 * @param key       the key
	 * @param value     the value inside the key
	 * @return jsonObject
	 * @throws Exception the exception
	 */
	public JSONObject getJSONObjectFromJSONArray(org.json.JSONArray jsonArray, String key, String value) {
		for (int index = 0; index < jsonArray.length(); index++) {
			org.json.JSONObject jsonobject = jsonArray.getJSONObject(index);

			if (jsonobject.getString(key).equalsIgnoreCase(value)) {
				return jsonobject;
			}
		}
		return null;
	}

	/**
	 * @author Bhagya Raj Gets the value from the json using the JsonPath
	 * @param json  the json in Object format
	 * @param xpath JsonPath of the value looking for
	 * @return the returned value as Object
	 * @throws ParseException
	 * @throws Exception      the exception
	 */
	public Object getObjectFromJsonXpath(Object jsonObject, String xpath) throws ParseException {
		Object res = JsonPath.read(jsonObject, xpath);
		return res;
	}
	
	/**
	 * @author DPradhan
	 * Writes JSON object to file.
	 *
	 * @param jo the JSONObject
	 * @param jsonFileName the json file name
	 * @return true, if successful
	 */
	public boolean writeJSONObjectToFile(org.json.simple.JSONObject jo, String jsonFileName) {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(jsonFileName);
			pw.write(jo.toJSONString());
			pw.flush();
			pw.close();
			LOG.debug(String.format("JSON Object Written To File - %s", jsonFileName));
			return true;
		} catch (Exception e) {
			LOG.error(e);
			return false;
		}
	}

	/**
	 * @author Bhavani Prasad Gets the Sub JsonElement for a key from the json
	 * @param json the json in String format
	 * @param key  the value of the Json to be returned
	 * @return the returned JsonObject value
	 * @throws Exception the exception
	 */
	public Integer getIntegerFromJsonObject(String json, String key) throws Exception {
		JSONObject obj = new JSONObject(json);
		return (Integer) obj.get(key);
	}

	public Object getJSONObjectFromJSONArray(String json, int index) throws Exception {
		org.json.JSONArray jsonArray = new org.json.JSONArray(json);
		Object object = (Object) jsonArray.getJSONObject(index);
		return object;
	}
	
	public Object updateDataWhenNotnull(Object obj, String jsonPath, String value, String delimiter, int index) {
		try {
			if(value!=null && !value.split(delimiter)[index].isEmpty()) {
				value = value.split(delimiter)[index];
				if(value.equalsIgnoreCase("blank")) {
					value = "";
				}
				obj = updateObjectJsonXpath(obj.toString(), jsonPath, value);
			}
		}catch(Exception e) {
		}
		return obj;
	}

	public Object updateEncodedDataWhenNotnull(Object obj, String jsonPath, String value, String delimiter, int index) {
		try {
			if(value!=null && !value.split(delimiter)[index].isEmpty()) {
				value = value.split(delimiter)[index];
				if(value.equalsIgnoreCase("blank")) {
					value = "";
				}
				obj = updateObjectJsonXpath(obj.toString(), jsonPath, ReusableUtils.encodeString2Base64(value));
			}
		}catch(Exception e) {
		}
		return obj;
	}
	
	/**
	 * @author Bhavani Prasad 
	 * Remove json object from json array
	 * @param jsonobject the json in String format
	 * @param key the value of the JsonArray to be returned
	 * @param index of the object to be removed
	 * @return the updated JsonObject value
	 * @throws Exception the exception
	 */
	public Object removeJsonObjectFromJsonArray(Object obj, String key, int index) {
		org.json.JSONObject jsonObject = new JSONObject(obj.toString());
		org.json.JSONArray jsonArray = jsonObject.getJSONArray(key);
		jsonArray.remove(index); 
		jsonObject.put(key, jsonArray);
		obj = (Object) jsonObject;
		return obj;
	}
	
	/**
	 * @author Bhavani Prasad Returns JSONObject from a given JSONArray based upon a
	 *         key and value
	 * @param jsonArray the jsonArray
	 * @param key       the key
	 * @param value     the value inside the key
	 * @return jsonObject
	 * @throws Exception the exception
	 */
	public JSONObject getJSONObjectFromJSONArray(org.json.JSONArray jsonArray, String key, int value) {
		for (int index = 0; index < jsonArray.length(); index++) {
			org.json.JSONObject jsonobject = jsonArray.getJSONObject(index);

			if (jsonobject.getInt(key) == value) {
				return jsonobject;
			}
		}
		return null;
	}

	/**
	 * @author Bhavani Prasad 
	 * Remove object from a json array based upon a key and value
	 * @param jsonArray the jsonArray
	 * @param key       the key
	 * @param value     the value inside the key
	 * @return jsonObject
	 * @throws Exception the exception
	 */
	public org.json.JSONArray removeJSONObjectFromJSONArray(org.json.JSONArray jsonArray, String key, int value) {
		for (int index = 0; index < jsonArray.length(); index++) {
			org.json.JSONObject jsonobject = jsonArray.getJSONObject(index);
			if (jsonobject.getInt(key) == value) {
				jsonArray.remove(index); 
			}			
		}
		return jsonArray;
	}

	public String getJsonFileAsObjectWithOrderPreserved(String filePath) throws IOException {
		Gson gson = new Gson();
		Reader reader = Files.newBufferedReader(Paths.get(filePath));
		Map<?, ?> map = gson.fromJson(reader, LinkedHashMap.class);
		reader.close();
		return new GsonBuilder().create().toJson(map);
	}
	
	public JSONObject updateJSONObjwithChildOfJSONArry(Object parentJSONObj,String ArrayKey,JSONObject childJSONObj) throws Exception {
		JSONObject parentObj = returnJsonObjectFromString(parentJSONObj.toString());
		org.json.JSONArray array = parentObj.getJSONArray(ArrayKey);
		array.put(childJSONObj);
		parentObj.put(ArrayKey,array);
		return parentObj;
		
	}
	
}
