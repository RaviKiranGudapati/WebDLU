/*Revision History
 * 02/09/2020: Bhagy/Vandana: Added mapImplantToPatient to map preference card related implants to patient cases
 * 01/09/2020: Narasimha/Bhagy: Updated new Functional fields to handle Discharge_To_Value and Admit Source value During discharge hence Updated dischargePatient,insertPatientHandOffData, Created new Method insertAreaOfCareinforamtion_Operative
 * 26/08/2020: Bhagya/Sujatha: Updated buildCaseSummaryObj method to document referring physician field and Added to performPatientChargeEntry method for secondary and tertiary Insurances mapping
 * 20/08/2020: Sujatha: Added updatePatientEmployerDetails() method for adding employer to patient and additional fields in updatePatientAdditionalDetails() method and added multiple physician for multiple cptCodes in updateCaseSumryObjWithMultipleCPTCodes() method and Added payerCode in updateStateReportInsurance() method. 
 * 11/08/2020: Bhagya Raj: Updated saveInsurancePlan method when contract value is passed and fixed the method to work for contract mapping cases to insurance
 * 11/08/2020: Bhagya Raj: Added method calls getRequestForInsuranceContractReviews(), getRequestForInsuranceContractReviewsFromFeeSchedule(); after creating contracts to work for populating charge
 * 10/08/2020 Bhavani : Updated addWorklistToPatient method to fix failures while adding worklist to failures due to new US 160759
 * 10/08/2020 Bhavani : Added addOPNotesToPatient method to handle OP Notes functionality
 * 05/08/2020 Bhagya/Vandana : Updated addConsent method to add Signee Patient/Guardian value for consents.
 * 04/08/2020 Vandana : Removed logic to handle existing consent from addConsents method and moved logic to WebserviceClient class.
 * 04/08/2020 Bhavani : Added getConsentDetails method in addConsent to handle existing consent values.
 * 31/07/2020 Bhagya/Vandana : Added flag for putting blank as no signee in addConsent method
 * 31/07/2020 Bhagya Raj: updated addConsent method to add multiple statements for consents
 * 29/07/2020 Bhagya Raj: updated saveContract method to work for dynamic and static effective and expiration dates
 * 24/07/2020 : Saikiran : Updating transactionType parameter from UnassignedPayment to Unassigned Payment as per JSON
 * 21/07/2020: Bhavani : Updated createJustAPatient to add additional details to patient such as patient address, patient emergency contact information, patient address,
 * 						 Updated addGuarantorToPatient to add guarantor additional details such as gender, relationship, phone, address1, address2, city, state, zip, extended zip
 * 						 Updated insertInsuranceToPatient to add insurance aditional details such as middle initial, title, date of birth, address1 , address2, group name, group number, city, state, zip, extended zip, country, phone number etc
 * 17/07/2020 : Debasish : Exceptions were thrown from methods.
 * 17/07/2020 : Debasish : Updated dischargePatient. Added Parameter procedureDt to dischargePatient method which is again passed to insertAreaOfCareInformation method as it is without any parse performed. procedureDt is parsed and interpreted within insertAreaOfCareInformation.
 * 15/07: BhagyaRaj/Nidhi: Updated updatedCaseSummaryPayloadWithGuarantor method to have a null check before mapping guaratnor
 * 13/07: Bhagya Raj: Updated addWorklistToPatient method to point to WorkistEquipment.json
 * 11/07: BhagyaRaj/Narasimha: updated contracts mapping to insurance and upgraded mapping of equipment to worklists(Changed the total implementation of worklist method to work for implants, supplies and equipment)
 * 09/07: Narasimha/Bhagy: Updated Preference card logic to handle Recovery Department while adding supplies added new method updateSuppliesopenholdvalues, changed logic in mapSuppliesToPreferenceCard
 * 09/07: Saikiran: Updated dischargePatient logic to handle discharge from various departments i.e., Recovery or Phase 3
 * 09/07: Bhavani: Added new method(signPatientDepartments) to sign the departments
 * 07/08/2020: Abhishek/Bhagy: Added - Added new methods to handle addition of contracts (saveContract, SelectContractOptions, selectProcedureDiscount, saveMultipleProceduresForContracts)
 * 07/08/2020: Abhishek/Bhagy: Update - Updated createSaveSourceOfRevenue method to skip if the input is BLANK
 * 06/07: Bhagya Raj: Updated SaveInsurance carrier method as it was throwing null irrespective of insurance not available. Updated the logic
 * 07/07: Bhavani: Updated getMedicationObject() to avoid JSONFormatException
 *                 Updated createMedicationTemplate to use search string while searching for medication
 *                 Updated addMedicationtopatient to add medications to Orders
 *                 Added new method isFeatureEnabled
 *                 Added new method signPatientDepartments
 *                 getCasePhysicianOrderId
 *                 createCasePhysicianOrderId
 *                 getPhysicianOrdersDocumentation
 *                 getPhysicianOrdersDocumentation
 *                 getMedicationTemplate
 *                 getMedicationOrder
 *                 addMedicationToOrders
 *                 administerMedicationsInOrders
 *                 getMedicationsAddedToDepartment
 *                 Updated addWorklistToPatient to split strings by ','
 *                 
 * 
 */
package com.utils;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

import com.client.webservice.IWebServiceResponseKeys;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.report.IReporter;

import io.restassured.http.Method;
import io.restassured.response.Response;

public abstract class ReUsableWebserviceUtils extends WebserviceUtils {
	private static final Logger LOG = Logger.getLogger(ReUsableWebserviceUtils.class);
	String oldfacility = "";
	String oldUserName = "";
	final String timeZonveValue = "-0500";// -0500 for EST, 000Z for UTC

	protected ReUsableWebserviceUtils(String baseURL) {
		super(baseURL);
	}

	protected ReUsableWebserviceUtils(String baseURL, Map<String, Object> mapWebServiceResponses) {
		super(baseURL, mapWebServiceResponses);
	}

	protected ReUsableWebserviceUtils(String baseURL, Map<String, Object> mapWebServiceResponses, IReporter reporter) {
		super(baseURL, mapWebServiceResponses, reporter);
	}

	protected void createSession(String facility) throws Exception{
		createSession(null, null, facility);
	}

	protected void createSession(String userID, String password, String facility) throws Exception{
		if (oldfacility.equals(facility) && oldUserName.equals(userID)) {
			return;
		} else {
			oldfacility = facility;
		}
		token = null;// this will enable to create session for different organization's
		String relURL = "/login/loginuser";

		// API1 to retrieve the session ID
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/UserDetails.json");
		if (userID !=null && !userID.isEmpty()) {
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "UserName", userID);	
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "Password", password);
		}
		oldUserName = jsonUtils.getValueFromJsonObject(obj.toString(), "UserName");
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.sessionUserName, userID);
		Response response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			this.token = response.asString().replaceAll("\"", "");
			// Token Being Saved In Map For Future Use
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.keyToken, this.token);
			LOG.info(String.format("URL - %s, Response - %d (%s), Token Generated - %s", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS, this.token));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s), Token Generated - %s", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE, this.token));
		}
		if (this.reporter != null) {
			this.reporter.logInfo(String.format("Token Generated - %s", this.token));
		}

		// API2 to Get UserSession
		String orgId = null;
		relURL = "/User/UserOrgMap";
		response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {
			// jsonUtils.getJSONObjectFromJSONArray(jsonArray, key, value);
			orgId = getUserSessionOrg(response.asString(), facility);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.keyOrgId, orgId);
			LOG.info(String.format("URL - %s, Response - %d (%s), orgID - %s", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS, orgId));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s), orgID - %s", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE, orgId));
		}
		if (this.reporter != null) {
			this.reporter.logInfo(String.format("orgId Received - %s", orgId));
		}

		// API3 - Map OrgID
		relURL = "/UserSession/UserSessionOrg/" + orgId;
		response = runWebServiceRequest("application/json", "", relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected String getUserSessionOrg(String response, String orgName) {

		JSONArray arr = new JSONArray(response);
		JSONObject childObj = (JSONObject) arr.get(0);
		JSONArray childarr = childObj.getJSONArray("childOrgs");
		JSONObject matchedJsonObj = jsonUtils.getJSONObjectFromJSONArray(childarr, "name", orgName);
		return String.valueOf(matchedJsonObj.get("organizationId"));
	}

	protected Response saveInsuranceCarrier(String insuranceName, String planName, String insuranceClassification)
			throws Exception {
		String relURL = "InsuranceCarrierObject/SaveInsuranceCarrier";
		// API to create Insurance(Carrier)
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/SaveInsuranceCarrier.json");
		verifyExistanceofinsurance(insuranceName, planName);
		// Update insuranceCarrierName,planName and classification

		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceCarrierName", insuranceName);
		JSONObject childJson = jsonUtils.getSubJsonElementFromJsonObject(obj.toString(), "insurancePlanSaveDetails");
		childJson = jsonUtils
				.returnJsonObjectFromString(jsonUtils.updateOneJsonElement(childJson.toString(), "planName", planName));
		childJson = jsonUtils.returnJsonObjectFromString(
				jsonUtils.updateOneJsonElement(childJson.toString(), "classification", insuranceClassification));

		obj = jsonUtils.updateOneJsonElement(jsonUtils.returnJsonObjectFromString(obj.toString()),
				"insurancePlanSaveDetails", childJson);
		LOG.info(String.format("Object-> %s", obj));
		if(verifyExistanceofinsurance(insuranceName, planName) || (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.insuranceCarrierId) 
				&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceCarrierId)!=null)) {
			return null;
		}

		Response response = null;
		try {
			response = runWebServiceRequestsupressfailure("application/json", obj.toString(), relURL, Method.PUT);
			String insuranceCarrierId = jsonUtils.getValueFromJsonObject(response.asString(),
					IWebServiceResponseKeys.insuranceCarrierId);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceCarrierId, insuranceCarrierId);
			String insurancePlanId = jsonUtils.getValueFromJsonObject(
					jsonUtils.getValueFromJsonObject(response.asString(),
							IWebServiceResponseKeys.insurancePlanSaveDetails),
					IWebServiceResponseKeys.insurancePlanId);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.insurancePlanId, insurancePlanId);
		} catch (RuntimeException e) {
			if(verifyExistanceofinsurance(insuranceName, planName)) {

				return null;
			} else {
				throw new RuntimeException("Exception occured while saving Insurance Carrier");
			}
		}
		return response;
	}

	protected Response insertInsuranceClaimOffice(String insuranceCarrierObject, String officeName, String line1,
			String city, String contactName, String phone, String zip, String extendedZip, String State)
					throws Exception {
		String relURL = "Insurance/InsertInsuranceClaimOffice";
		// API to create Insurance(Carrier)
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/InsertInsuranceClaimOffice.json");

		// Update InsuranceCarrier Details
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceCarrierObjectId", insuranceCarrierObject);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "name", officeName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "line1", line1);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "city", city);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "contactName", contactName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "phone", phone);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "zip", zip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "extendedZip", extendedZip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "state", State);

		LOG.info(String.format("Object-> %s", obj));

		Response response = null;
		response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		JSONObject responseObj = new JSONObject(response.asString());
		if (!responseObj.get("claimOfficeId").equals(null) ) {
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceClaimOfficeid, responseObj.get("claimOfficeId"));
		}else {
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceClaimOfficeid, null);
		}
		return response;
	}

	protected Response updateInsuranceClaimOffice(String insuranceCarrierObject, String officeName, String line1,
			String city, String contactName, String phone, String zip, String extendedZip, String State)
					throws Exception {
		String relURL = "Insurance/UpdateInsuranceClaimOffice";
		// API to create Insurance(Carrier)
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/InsertInsuranceClaimOffice.json");

		// Update InsuranceCarrier Details
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "claimOfficeId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceClaimOfficeid).toString()));
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceCarrierObjectId", insuranceCarrierObject);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "name", officeName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "line1", line1);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "city", city);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "contactName", contactName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "phone", phone);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "zip", zip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "extendedZip", extendedZip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "state", State);

		LOG.info(String.format("Object-> %s", obj));
		if (this.reporter != null) {
			this.reporter.logSuccess("UpdateInsuranceClaimOffice-> "+obj);
		}
		Response response = null;
		response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		return response;
	}

	protected Response saveInsurancePlan(String insuranceCarrierId, String insurancePlanId, String planName,
			String insuranceClassification, String officeName, String line1, String city, String contactName,
			String phone, String zip, String extendedZip, String State, boolean generateTrue, String contractName) throws Exception {
		String relURL = "InsurancePlan/SaveInsurancePlan";
		// API to create Insurance(Carrier)
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/SaveInsurancePlan.json");

		// Update insuranceCarrierName,planName and classification
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceCarrierId", insuranceCarrierId);
		if(insurancePlanId != null) {
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "insurancePlanId", Integer.parseInt(insurancePlanId));
		}else {
			JSONObject jsonObj = new JSONObject(obj.toString());
			jsonObj.remove("insurancePlanId");
			obj = jsonObj;
			//			jsonUtils.returnJsonObjectFromString(obj.toString()).remove("insurancePlanId");
		}
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "planName", planName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "classification", insuranceClassification);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "claimOfficeName", officeName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "generateClaimTf", generateTrue);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "address1", line1);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "city", city);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "contactName", contactName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "phoneNumber", phone);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "zip", zip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "extendedZipCode", extendedZip);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "state", State);
		if(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceClaimOfficeid) != null) {
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "claimOfficeId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceClaimOfficeid).toString()));
		}

		// update the contract details
		if(contractName!=null && !contractName.isEmpty() && !contractName.equalsIgnoreCase("blank")) {
			JSONArray insurancePlanContractList = new JSONArray();
			JSONArray selectedContracts = new JSONArray();
			int i=0;
			for (String contrName: contractName.split("[,]")) {
				JSONObject contractDetailsObj = retrieveContracts(contrName);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "contract", contrName);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceContractId", Integer.parseInt(contractDetailsObj.get("insuranceContractId").toString()));

				if(contractDetailsObj!=null) {
					JSONObject insurancePlanContractListObj = new JSONObject();
					insurancePlanContractListObj.put("insurancePlanContractId", 0);
					insurancePlanContractListObj.put("insurancePlanId", Integer.parseInt(insurancePlanId));
					insurancePlanContractListObj.put("insuranceContractId", Integer.parseInt(contractDetailsObj.get("insuranceContractId").toString()));
					insurancePlanContractListObj.put("insuranceContractName", contrName);
					insurancePlanContractListObj.put("sortOrder", i);
					insurancePlanContractListObj.put("isSelected", true);
					insurancePlanContractList.put(insurancePlanContractListObj);

					//update selectedContracts
					contractDetailsObj.put("insuranceContractSelectedOrder", i+1);
					contractDetailsObj.put("insurancePlanContractId", 0);
					if(insurancePlanId != null) {
						contractDetailsObj.put("insurancePlanId", Integer.parseInt(insurancePlanId));
					}
					selectedContracts.put(contractDetailsObj);
				}
				i++;
			}
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "insurancePlanContractList", insurancePlanContractList);
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "selectedContracts", selectedContracts);
		}
		LOG.info(String.format("Object-> %s", obj));
		Response response = null;
		response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
		insurancePlanId = jsonUtils.getValueFromJsonObject(response.asString(),"insurancePlanId");
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.insurancePlanId, insurancePlanId);
		return response;
	}

	protected Response getFeeScheduleByCptCode(String cptCode) throws Exception {
		String relURL = "/FeeSchedule/Search";
		LOG.info(String.format("Getting fee schedule for %s cpt code", cptCode));
		Response response = null;
		response = runWebServiceRequest("application/json",
				"\"" + ReusableUtils.encodeString2Base64(cptCode) + "\"", relURL, Method.POST);
		return response;
	}

	protected Response getICDCode(String icdCode) throws Exception {
		String relURL = "/ICDCodeClassification/GetICDCodeClassifications";
		LOG.info(String.format("Getting diagnosis code for %s ", icdCode));
		Response response = null;
		response = runWebServiceRequest("application/json", "\"" + icdCode.substring(0, 3) + "\"", relURL,
				Method.POST);
		return response;
	}

	protected void createjustApatient(String firstName, String lastName, String procedureDt, String patientAddressDetails, String patientAdditionalDetails, String patientPhoneDetails, String patientEmergencyContactDetails, String patientEmployerDetails) throws Exception {

		String relURL = "/PatientData/Gemini/CreatePatient/2030";
		// perform webservice impl

		LOG.info(String.format("I am At WebService - %s", "createjustApatient"));
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/CreatePatient.json");
		long accountNumber = Long.parseLong(ReusableUtils.generateRandomNumeric(13));
		LOG.info(String.format("accountNumber->  " + accountNumber));
		procedureDt = ReusableUtils.addDate(procedureDt, "yyyy-MM-dd");
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "firstName", firstName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "lastName", lastName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "accountNumber", accountNumber);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "procedureDt", procedureDt + "T00:00:00"+timeZonveValue);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullName", firstName + " " + lastName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullNameWithTitle", firstName + " " + lastName);
		obj = updatePatientEmergencyContactDetails(obj, patientEmergencyContactDetails);
		obj = updatePatientPhoneDetails(obj, patientPhoneDetails);
		obj = updatePatientAdditionalDetails(obj, patientAdditionalDetails, firstName, lastName);
		obj = updatePatientAddressDetails(obj, patientAddressDetails);

		LOG.info(String.format("**************Object-> " + obj + "**************"));
		Response response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.createjustaPatientResp, response.asString());
			//			System.out.println("Createpatient response>>>>>>>>>>>>>>>>>>>"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.createjustaPatientResp));
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_SUCCESS));

		if (patientEmployerDetails != null && !patientEmployerDetails.isEmpty() && !patientEmployerDetails.equalsIgnoreCase("blank")) {
			 updatePatientEmployerDetails(obj, patientEmployerDetails);
			}

		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected String createCaseSummary(String physicianUser, String roomName, String startTime, String endTime,
			String appointmentType, String preferenceCardName, String cptCode, String lterality, String preOpDiagnosisCode, String dos, String guarantorFirstName,
			String guarantorLastName, String guarantorDateOfBirth, String guarantorAdditionalDetails, String guarantorCountry, String guarantorIsActive,
			String primaryGuarantor, String secondaryGuarantor, String Carriername, String RelationshiptoSubscriber,
			String InsurancefirstName, String InsurancelastName, String gender, String Subscriberid, String insuranceAdditionalDetails) throws Exception{

		Object caseSummaryRequestobj = null;

		String relURL = "/CaseSummaryComplex/Gemini/UpsertCaseSummary";
		// perform webservice impl
		caseSummaryRequestobj = jsonUtils.getJsonFileAsObject("reqTemplates/UpsertCaseSummary.json");

		caseSummaryRequestobj = buildCaseSummaryObj(caseSummaryRequestobj, physicianUser, roomName, startTime,
				endTime, appointmentType, preferenceCardName, cptCode, lterality, dos);

		// Multiple InsurnaceMapping
		caseSummaryRequestobj = updatedCaseSummaryPayloadWithinsurance(caseSummaryRequestobj, Carriername,
				RelationshiptoSubscriber, InsurancefirstName, InsurancelastName, gender, Subscriberid, insuranceAdditionalDetails);

		// Multiple GuarantorMapping
		caseSummaryRequestobj = updatedCaseSummaryPayloadWithGuarantor(caseSummaryRequestobj, guarantorFirstName,
				guarantorLastName, guarantorDateOfBirth, guarantorCountry, guarantorIsActive, primaryGuarantor,
				secondaryGuarantor);
		// Multiple CPT Codes
		caseSummaryRequestobj = updateCaseSumryObjWithMultipleCPTCodes(caseSummaryRequestobj, cptCode, lterality,
				physicianUser,preOpDiagnosisCode);

		LOG.info(String.format("Object before hitting createCaseSummary-> " + caseSummaryRequestobj));
		Response response = runWebServiceRequest("application/json", caseSummaryRequestobj.toString(), relURL,
				Method.POST);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseSummaryResp, response.asString());

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("CreateCaseSummary response-> %s", response.asString()));
			String caseSummaryId = jsonUtils.getObjectFromJsonXpath(response.asString(), "caseSummaryId")
					.toString();
			String appointmentId = jsonUtils.getObjectFromJsonXpath(response.asString(), "appointmentId")
					.toString();
			String procedureStartDt = jsonUtils.getObjectFromJsonXpath(response.asString(), "procedureStartDt")
					.toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseSummaryID, caseSummaryId);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseStartTime, procedureStartDt);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseAppointmentId, appointmentId);
			LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
					ReusableUtils.getCallingMethodName(), this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			updateCaseSummaryWithGuarantorAdditionalInformation(guarantorAdditionalDetails);
		} else {
			LOG.error(String.format("%s - %s, URL - %s, Response - %d (%s)",
					IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
					this.baseURL + relURL, response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));

		}
		return null;
	}

	protected Response getRoomsForOrganization() throws Exception {
		String relURL = "Room/GetRoomsForOrganization";
		// API to GetRoomsForOrganization

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response getAppointmentTypeNameAndID() throws Exception {
		String relURL = "/ApptypeCasepackMap/GetApptypeCasepackMapData";
		// API to GetAppointmentTypeNameAndID

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response getPhysicianeNameAndID() throws Exception {
		String relURL = "/StaffList/GetStaffForFacility";
		// API to GetPhysicianeNameAndID

		return runWebServiceRequest("application/json", "", relURL, Method.POST);
	}

	protected String getRoomIdForRoomName(String RoomName) throws Exception{
		String roomId = null;
		Response response = getRoomsForOrganization();
		JSONArray roomary = jsonUtils.returnJsonArrayFromString(response.asString());
		if(roomary.length() > 0) {
			JSONObject roomjson1 = jsonUtils.getJSONObjectFromJSONArray(roomary, "name", RoomName);
			LOG.info(String.format("roomary - %s", roomary));
			LOG.info(String.format("roomjson1 - %s", roomjson1));
			roomId = jsonUtils.getValueFromJsonObject(roomjson1.toString(), "roomId");
			return roomId;
		} else {
			throw new RuntimeException("Room "+RoomName+" is not present ");
		}
	}

	protected List<Object> getPhysicianNameIDFromPhysicianName(String physicianname) throws Exception{
		String physicianId = null;
		String physicianfullname = null;
		String staffId = null;
		Response response = getPhysicianeNameAndID();
		JSONArray physicianary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("physicianary - %s", physicianary));
		JSONObject physicianjson1 = jsonUtils.getJSONObjectFromJSONArray(physicianary, "lastName", physicianname);
		physicianId = jsonUtils.getValueFromJsonObject(physicianjson1.toString(), "personId");
		staffId = jsonUtils.getValueFromJsonObject(physicianjson1.toString(), "staffId");
		physicianfullname = jsonUtils.getValueFromJsonObject(physicianjson1.toString(), "fullName");

		return Arrays.asList(physicianfullname,staffId,physicianId);
	}

	protected void getAppointmentType(String AppointmentTypeName) throws Exception {
		Response response = getAppointmentTypeNameAndID();
		JSONArray GetAppointmentTypeNameAndID = jsonUtils.returnJsonArrayFromString(response.asString());
		JSONObject SingleAppTypeNameAndID = jsonUtils.getJSONObjectFromJSONArray(GetAppointmentTypeNameAndID,
				"appointment_Type_Desc", AppointmentTypeName);
		LOG.info(String.format("SingleAppTypeNameAndID - %s", SingleAppTypeNameAndID));
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.appointmentType, SingleAppTypeNameAndID);
	}

	protected int getAppointmentTypeId(String AppointmentTypeName) throws Exception{
		int AppointmentTypeId = 0;
		JSONObject SingleAppTypeNameAndID = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.appointmentType).toString());
		LOG.info(String.format("SingleAppTypeNameAndID - %s", SingleAppTypeNameAndID));
		AppointmentTypeId = Integer
				.parseInt(jsonUtils.getValueFromJsonObject(SingleAppTypeNameAndID.toString(), "appointmentTypeId"));
		return AppointmentTypeId;
	}

	protected int getAppointmentTypeCaseType(String AppointmentTypeName) throws Exception{
		int caseTypeAfterStartDate = 0;
		JSONObject SingleAppTypeNameAndID = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.appointmentType).toString());
		LOG.info(String.format("SingleAppTypeNameAndID - %s", SingleAppTypeNameAndID));
		caseTypeAfterStartDate = Integer
				.parseInt(jsonUtils.getValueFromJsonObject(SingleAppTypeNameAndID.toString(), "caseTypeAfterStartDate"));
		return caseTypeAfterStartDate;
	}
	
	protected List<Object> Getlaterality(String lateralitytext) {
		int laterality = 0;

		if ("left".equalsIgnoreCase(lateralitytext)) {
			laterality = 1;
		} else if ("right".equalsIgnoreCase(lateralitytext)) {
			laterality = 3;
		} else if ("bilateral".equalsIgnoreCase(lateralitytext)) {
			laterality = 2;
		}

		return Arrays.asList(laterality, lateralitytext);
	}

	protected Object buildCaseSummaryObj(Object caseSummaryRequestobj, String physicianUser, String roomName,
			String startTime, String endTime, String appointmentType, String preferenceCardName, String cptCode, String lterality, String dos)
					throws Exception {
		String patientresponse = this.mapWebServiceResponses.get(IWebServiceResponseKeys.createjustaPatientResp)
				.toString();
		getAppointmentType(appointmentType);
		JSONObject patientresjsonObject = new JSONObject(patientresponse);
		String patientId = jsonUtils.getObjectFromJsonXpath(patientresponse, "patientId").toString();
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientId, patientId);
		//		System.out.println("patientid with CPT code"+patientId+"for cptcode"+cptCode);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientFirstName,
				jsonUtils.getObjectFromJsonXpath(patientresponse, "firstName"));
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientLastName,
				jsonUtils.getObjectFromJsonXpath(patientresponse, "lastName"));

		Object address = jsonUtils.getObjectFromJsonXpath(caseSummaryRequestobj.toString(), "patient.address");
		
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(
				jsonUtils.returnJsonObjectFromString(caseSummaryRequestobj.toString()), "patient",
				patientresjsonObject);
		// TODO: caseSummaryRequestobj =
		// jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "duration",
		// dos);//Duration must be updaed accordingly
		
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "dateOfService", ReusableUtils.getDate(dos, "MM/dd/yyyy"));
		dos = ReusableUtils.getDate(dos, "yyyy-MM-dd");
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "patient.address",
				address);
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "procedureDt",
				dos + "T" + startTime + ":00"+timeZonveValue);
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "patientId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId));

		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "startTime",
				startTime);
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "endTime", endTime);

		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "procedureStartDt",
				dos + "T" + startTime + ":00"+timeZonveValue);
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "procedureStopDt",
				dos + "T" + endTime + ":00"+timeZonveValue);
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "procedureStartTime",
				dos + "T" + startTime + ":00"+timeZonveValue);
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "procedureStopTime",
				dos + "T" + endTime + ":00"+timeZonveValue);

		
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "roomId",
				getRoomIdForRoomName(roomName));
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "roomName", roomName);
		
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "appointmentTypeId",
				getAppointmentTypeId(appointmentType));
		caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(), "caseType",
				getAppointmentTypeCaseType(appointmentType));
	
		// return Arrays.asList(physicianfullname,staffId,physicianId);
		List<Object> PhysicianDetails = getPhysicianNameIDFromPhysicianName(physicianUser.split("[;]")[0]);
		// List<Object> PhysicianDetails = getPhysicianNameIDFromPhysicianName(referencePhysicianUser);
				
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "primaryPhysicianId",
				Integer.valueOf(PhysicianDetails.get(2).toString()));
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "referringPhysicianId",
				Integer.valueOf(PhysicianDetails.get(2).toString()));
		caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "referringPhysicianName",
				PhysicianDetails.get(0).toString());
		
		if(preferenceCardName != null && !preferenceCardName.isEmpty()) {
			caseSummaryRequestobj = addPreferenceCardToPatient(caseSummaryRequestobj, preferenceCardName);
		}
		/***********************************************************/

		LOG.info(String.format("****caseSummaryRequestobj after buildCaseSummaryObj method -> " + caseSummaryRequestobj
				+ "**************"));
		return caseSummaryRequestobj;
	}

	protected Response getSchedulingData(String startData, String endDate) throws Exception {
		String relURL = "/SchedulingData/Gemini/GetSchedulingData";
		JSONObject request = new JSONObject();
		request.put("startDate", startData + "T04:00:00"+timeZonveValue);
		request.put("endDate", endDate + "T03:59:59.999Z");
		request.put("rowNumber", 0);
		Response schedulingDataResponse = runWebServiceRequest("application/json", request.toString(), relURL,
				Method.POST);
		if (schedulingDataResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					schedulingDataResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return schedulingDataResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					schedulingDataResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected List<String> getPatientInformation(String firstName, String lastName, String startDate, String endDate) throws Exception{
		List<String> patientDetails = new ArrayList<String>();
		Response response = getSchedulingData(startDate, endDate);
		JSONArray patients = jsonUtils.returnJsonArrayFromString(response.asString());
		for (int index = 0; index < patients.length(); index++) {
			JSONObject patient = patients.getJSONObject(index);
			if ((patient.getJSONObject("patient").getString("firstName").equalsIgnoreCase(firstName))
					&& (patient.getJSONObject("patient").getString("lastName").equalsIgnoreCase(lastName))) {
				patientDetails.add("" + patient.getInt("caseSummaryID"));
				patientDetails.add("" + patient.getJSONObject("patient").getInt("patientId"));
				patientDetails.add("" + patient.getJSONObject("patient").getInt("accountNumber"));
				LOG.info(String.format("The given pateint %s , %s is present", firstName, lastName));
				return patientDetails;
			}
		}
		LOG.info(String.format("The given pateint %s , %s is not present", firstName, lastName));
		return null;
	}

	protected void addMultipleGuarantorToPatient(String patientId, String guarantorFirstName, String guarantorLastName,
			String guarantorDateOfBirth, String guarantorCountry, boolean guarantorIsActive) throws Exception {
		String relURL = "PatientGuarantor/SavePatientGuarantor";
		// perform webservice for guarantor

		LOG.info(String.format("I am At WebService - %s", "addMultipleGuarantorToPatient"));
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/MapGuarantorToPatient.json");

		obj = jsonUtils.updateOneJsonElement(obj.toString(), "patientId", patientId);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "firstName", guarantorFirstName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "lastName", guarantorLastName);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "dateOfBirth", guarantorDateOfBirth);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "isActive", guarantorIsActive);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "country", guarantorCountry);

		LOG.info(String.format("**************Object-> " + obj + "**************"));
		Response response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			// set guarantor values for multiple guarantors
			Object guarantorResponse = jsonUtils.getObjectFromJsonXpath(response.asString(), "$");
			String patientGuarantorId = jsonUtils
					.getObjectFromJsonXpath(guarantorResponse, IWebServiceResponseKeys.patientGuarantorId).toString();

			if (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.patientGuarantorId)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientGuarantorId,
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientGuarantorId) + ";"
								+ patientGuarantorId);
			} else {

				this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientGuarantorId, patientGuarantorId);
			}

			if (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.guarantorFirstName)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorFirstName,
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorFirstName) + ";"
								+ guarantorFirstName);
			} else {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorFirstName, guarantorFirstName);
			}

			if (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.guarantorLastName)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorLastName,
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorLastName) + ";"
								+ guarantorLastName);
			} else {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorLastName, guarantorLastName);
			}

			if (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.guarantorDob)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorDob,
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorDob) + ";"
								+ guarantorDateOfBirth);
			} else {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorDob, patientGuarantorId);
			}

			if (this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.guarantorCountry)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorCountry,
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorCountry) + ";"
								+ guarantorCountry);
			} else {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.guarantorCountry, patientGuarantorId);
			}

			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			if (this.reporter != null) {
				this.reporter.logInfo(String.format("Addition of Multiple Guarantors To Patient method is successful"));
			}
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
					IWebServiceResponseKeys.WS_STATUS_FAILURE));
			if (this.reporter != null) {
				this.reporter.logFailure(
						String.format("Addition of Multiple Guarantors To Patient method is not successful"));
			}
		}
	}

	protected Object updatedCaseSummaryPayloadWithGuarantor(Object caseSummaryRequestobj, String guarantorFirstName,
			String guarantorLastName, String guarantorDateOfBirth, String guarantorCountry, String guarantorIsActive,
			String primaryGuarantor, String secondaryGuarantor) throws Exception {
		String guarantorFirstName_mul = guarantorFirstName;
		String guarantorLastName_mul = guarantorLastName;
		String guarantorDateOfBirth_mul = guarantorDateOfBirth;
		String guarantorCountry_mul = guarantorCountry;
		String guarantorIsActive_mul = guarantorIsActive;

		if (guarantorFirstName_mul != null && !guarantorFirstName_mul.isEmpty()) {
			for (int i = 0; i < guarantorFirstName_mul.split("[;]").length; i++) {
				guarantorFirstName = guarantorFirstName_mul.split("[;]")[i];
				try {
					guarantorLastName = guarantorLastName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					guarantorDateOfBirth = guarantorDateOfBirth_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					guarantorCountry = guarantorCountry_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					guarantorIsActive = guarantorIsActive_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				addMultipleGuarantorToPatient(
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString(),
						guarantorFirstName, guarantorLastName, guarantorDateOfBirth, guarantorCountry,
						Boolean.parseBoolean(guarantorIsActive));
			}
		}

		Object guarantorObj = jsonUtils.getObjectFromJsonXpath(caseSummaryRequestobj.toString(),
				"caseGuarantor[0]");
		Object tempObj = guarantorObj;

		if (primaryGuarantor != null && !primaryGuarantor.isEmpty()) {
			guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(), "patientGuarantor.patientId",
					Integer.parseInt(
							this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString()));
			if (primaryGuarantor.equalsIgnoreCase("self")) {
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(),
						"patientGuarantor.firstName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientFirstName).toString());
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(), "patientGuarantor.lastName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientLastName).toString());
			} else {
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(),
						"patientGuarantor.firstName", this.mapWebServiceResponses
						.get(IWebServiceResponseKeys.guarantorFirstName).toString().split("[;]")[0]);
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(), "patientGuarantor.lastName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorLastName).toString()
						.split("[;]")[0]);
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(),
						"patientGuarantor.patientGuarantorId", Integer.parseInt(this.mapWebServiceResponses
								.get(IWebServiceResponseKeys.patientGuarantorId).toString().split("[;]")[0]));
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(), "guarantorId",
						Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientGuarantorId)
								.toString().split("[;]")[0]));
				guarantorObj = jsonUtils.updateObjectJsonXpath(guarantorObj.toString(), "isSelf", false);
			}
			Object guarantorObjDocument = Configuration.defaultConfiguration().jsonProvider()
					.parse(guarantorObj.toString());
			caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
					"caseGuarantor[0]", guarantorObjDocument);
		}

		if (secondaryGuarantor != null && !secondaryGuarantor.isEmpty()) {
			tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.patientId", Integer
					.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString()));
			tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "sortOrder", 2);
			if (secondaryGuarantor.equalsIgnoreCase("self")) {
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.firstName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientFirstName).toString());
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.lastName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientLastName).toString());
			} else {
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.firstName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorFirstName).toString()
						.split("[;]")[guarantorFirstName_mul.split("[;]").length - 1]);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.lastName",
						this.mapWebServiceResponses.get(IWebServiceResponseKeys.guarantorLastName).toString()
						.split("[;]")[guarantorFirstName_mul.split("[;]").length - 1]);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "patientGuarantor.patientGuarantorId",
						Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientGuarantorId)
								.toString().split("[;]")[guarantorFirstName_mul.split("[;]").length - 1]));
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "guarantorId",
						Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientGuarantorId)
								.toString().split("[;]")[guarantorFirstName_mul.split("[;]").length - 1]));
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "isSelf", false);
			}
			Object guarantorObjDocument = Configuration.defaultConfiguration().jsonProvider()
					.parse(tempObj.toString());
			caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
					"caseGuarantor[1]", guarantorObjDocument);
		}
		return caseSummaryRequestobj;
	}

	protected Response insertInsurancetoPatient(String RelationshiptoSubscriber, String firstName, String lastName,
			String gender, String Subscriberid, String Carriername, String insuranceAdditionalDetails) throws Exception{
		Response insertInsurancetoPatientresponse = null;
		String patientresponse = this.mapWebServiceResponses.get(IWebServiceResponseKeys.createjustaPatientResp)
				.toString();
		String relURL = "/Insurance/Gemini/Insert";
		// perform webservice impl


		Object insertInsurancetoPatientobj = jsonUtils
				.getJsonFileAsObject("reqTemplates/InsertInsurancetoPatient.json");

		Response InsurancePlanResponse = GetInsurancePlans(Carriername);

		JSONArray arr = new JSONArray(InsurancePlanResponse.asString());
		JSONObject InsurancePlanobj = (JSONObject) arr.get(0);

		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"patientId", jsonUtils.getObjectFromJsonXpath(patientresponse, "patientId"));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"organizationId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString());
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"insuranceId", Integer.parseInt(jsonUtils.getValueFromJsonObject(InsurancePlanobj.toString(), "insurancePlanId")));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"planName", jsonUtils.getValueFromJsonObject(InsurancePlanobj.toString(), "planName"));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"insuranceCarrierId",
				Integer.parseInt(jsonUtils.getValueFromJsonObject(InsurancePlanobj.toString(), "insuranceCarrierId")));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"carrier", Carriername);
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(), 
				"insurancePlanId", Integer.parseInt(jsonUtils.getValueFromJsonObject(InsurancePlanobj.toString(), "insurancePlanId")));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"insuranceClaimOfficeId",
				Integer.parseInt(jsonUtils.getValueFromJsonObject(InsurancePlanobj.toString(), "claimOfficeId")));
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"relationshipToInsured", RelationshiptoSubscriber);
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"displayName", Subscriberid);
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"firstName", firstName);
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"lastName", lastName);
		insertInsurancetoPatientobj = jsonUtils.updateObjectJsonXpath(insertInsurancetoPatientobj.toString(),
				"gender", gender);

		if (insuranceAdditionalDetails != null && !insuranceAdditionalDetails.isEmpty() && !insuranceAdditionalDetails.equalsIgnoreCase("blank")) {
			String[] additionalDetails = insuranceAdditionalDetails.split("[,]");

			String middleInitial = additionalDetails[0];
			if (!middleInitial.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"middleInitial", middleInitial);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"middleInitial", null);

			String suffix = additionalDetails[1];
			if (!suffix.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"suffix", suffix);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"suffix", null);

			String dateOfBirth = additionalDetails[2];
			if (!dateOfBirth.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"dateOfBirth", dateOfBirth);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"dateOfBirth", null);

			String address1 = additionalDetails[3];
			if (!address1.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"address1", address1);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"address1", null);

			String address2 = additionalDetails[4];
			if (!address2.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"address2", address2);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"address2", null);

			String groupName = additionalDetails[5];
			if (!groupName.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"groupName", groupName);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"groupName", null);

			String groupNumber = additionalDetails[6];
			if (!groupNumber.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"groupNumber", groupNumber);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"groupNumber", null);

			String city = additionalDetails[7];
			if (!city.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"city", city);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"city", null);

			String state = additionalDetails[8];
			if (!state.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"state", state);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"state", null);

			String zipCode = additionalDetails[9];
			String extendedZip = additionalDetails[10];
			if (!zipCode.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"zipCode", zipCode+"-"+extendedZip);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"zipCode", null);

			String employer = additionalDetails[11];
			if (!employer.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"employer", employer);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"employer", null);

			String county = additionalDetails[12];
			if (!county.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"countyName", county);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"countyName", null);

			String country = additionalDetails[13];
			if (!country.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"countryName", country);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"countryName", null);

			String effectiveFrom = additionalDetails[14];
			if (!effectiveFrom.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"effectiveFrom", effectiveFrom);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"effectiveFrom", null);

			String effectiveTo = additionalDetails[15];
			if (!effectiveTo.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"effectiveTo", effectiveTo);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"effectiveTo", null);

			String email = additionalDetails[16];
			if (!email.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"email", email);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"email", null);

			String primaryPhone = additionalDetails[17];
			if (!primaryPhone.equalsIgnoreCase("blank"))
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"primaryPhone", primaryPhone);
			else
				insertInsurancetoPatientobj = jsonUtils.updateOneJsonElement(insertInsurancetoPatientobj.toString(),
						"primaryPhone", null);
		}

		insertInsurancetoPatientresponse = runWebServiceRequest("application/json",
				insertInsurancetoPatientobj.toString(), relURL, Method.POST);

		if (insertInsurancetoPatientresponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertInsurancetoPatientresponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertInsurancetoPatientresponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return insertInsurancetoPatientresponse;
	}

	private Object updatedCaseSummaryPayloadWithinsurance(Object caseSummaryRequestobj, String Carriername,
			String RelationshiptoSubscriber, String firstName, String lastName, String gender, String Subscriberid, String insuranceAdditionalDetails) throws Exception{
		String Carriername_mul = Carriername;
		String RelationshiptoSubscriber_mul = RelationshiptoSubscriber;
		String firstName_mul = firstName;
		String lastName_mul = lastName;
		String gender_mul = gender;
		String Subscriberid_mul = Subscriberid;
		String additionalDetails_mul = insuranceAdditionalDetails;

		if(Carriername!=null && !Carriername.isEmpty()) {
			for (int i = 0; i < Carriername_mul.split("[;]").length; i++) {
				Carriername = Carriername_mul.split("[;]")[i];
				try {
					RelationshiptoSubscriber = RelationshiptoSubscriber_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					firstName = firstName_mul.split("[;]")[i];
					if (firstName.equalsIgnoreCase("blank"))
						firstName = "";
				} catch (Exception e) {
				}
				try {
					lastName = lastName_mul.split("[;]")[i];
					if (lastName.equalsIgnoreCase("blank"))
						lastName = "";
				} catch (Exception e) {
				}
				try {
					gender = gender_mul.split("[;]")[i];
					if (gender.equalsIgnoreCase("blank"))
						gender = "";
				} catch (Exception e) {
				}
				try {
					Subscriberid = Subscriberid_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					if (additionalDetails_mul != null && !additionalDetails_mul.isEmpty() && !additionalDetails_mul.equalsIgnoreCase("blank"))
						insuranceAdditionalDetails = additionalDetails_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				// perform webservice impl
				LOG.info(String.format("I am At WebService - %s", "updatedCaseSummaryPayloadWithinsurance"));
				insertInsurancetoPatient(RelationshiptoSubscriber, firstName, lastName,
						gender, Subscriberid, Carriername, insuranceAdditionalDetails).asString();
			}
		}		
		JSONArray searcharry = new JSONArray(GetPatientInsurancesByPatientId().asString());
		for (int i = 0; i < searcharry.length(); i++) {
			Object patientInsuranceobj = jsonUtils.getObjectFromJsonXpath(searcharry.getJSONObject(i), "$");
			if(i==0) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.primaryInsuranceId, jsonUtils.getObjectFromJsonXpath(patientInsuranceobj.toString(),"patientInsuranceId"));
			}
			if(i==1) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.secondaryInsuranceId, jsonUtils.getObjectFromJsonXpath(patientInsuranceobj.toString(),"patientInsuranceId"));
			}
			if(i==2) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.tertiaryInsuranceId, jsonUtils.getObjectFromJsonXpath(patientInsuranceobj.toString(),"patientInsuranceId"));
			}
			patientInsuranceobj = Configuration.defaultConfiguration().jsonProvider().parse(patientInsuranceobj.toString());
			caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
					"caseInsurances[" + i + "].patientInsurance", patientInsuranceobj);

			caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
					"caseInsurances[" + i + "].sortOrder", i);
			caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
					"caseInsurances[" + i + "].caseSummaryId", 0);
		}

		LOG.info(String.format("****caseSummaryRequestobj AfterupdatedCaseSummaryPayloadWithinsurance-> "
				+ caseSummaryRequestobj + "**************"));
		// patientInsuranceId
		return caseSummaryRequestobj;
	}
	protected Response GetPatientInsurancesByPatientId() throws Exception {
		String patientid = this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString();
		String relURL = "Insurance/Gemini/GetPatientInsurancesByPatientId/"+patientid;
		Response response = null;
		response = runWebServiceRequest("application/json","", relURL, Method.GET);

		return response;
	}

	protected Response getinsuranceCarriers() throws Exception {
		String relURL = "InsuranceCarrierObject/GetInsuranceCarriers";
		// API to getincuranceCarriers

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response GetInsurancePlans(String Insurancename) {
		String relURL = "InsurancePlan/GetInsurancePlans";
		int insuranceCarrierId = 0;
		Response GetInsurancePlansResponce = null;
		JSONObject GetInsurancePlans = new JSONObject();
		try {
			Response response = getinsuranceCarriers();
			JSONArray incuranceCarriersarray = jsonUtils.returnJsonArrayFromString(response.asString());
			JSONObject SingleincuranceCarrierarray = jsonUtils.getJSONObjectFromJSONArray(incuranceCarriersarray,
					"insuranceCarrierName", Insurancename);

			insuranceCarrierId = Integer.parseInt(
					jsonUtils.getValueFromJsonObject(SingleincuranceCarrierarray.toString(), "insuranceCarrierId"));

			GetInsurancePlans.put("insuranceCarrierId", insuranceCarrierId);
			LOG.info(String.format("GetInsurancePlans.........>%s", GetInsurancePlans.toString()));
			GetInsurancePlansResponce = runWebServiceRequest("application/json", GetInsurancePlans.toString(), relURL,
					Method.POST);
			if (GetInsurancePlansResponce.getStatusCode() == 200) {
				LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
						GetInsurancePlansResponce.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			} else {
				LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
						GetInsurancePlansResponce.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		// return GetInsurancePlans;
		return GetInsurancePlansResponce;
	}

	protected Object updateCaseSumryObjWithMultipleCPTCodes(Object caseSummaryRequestobj, String cptCode,
		String lterality, 	String physicianUser,  String preOpDiagnosisCode) throws Exception {
		String cptCode_mul = cptCode;
		String lterality_mul = lterality;
		String physicianUser_mul = physicianUser;
		Object feeScheduleObj = jsonUtils.getObjectFromJsonXpath(caseSummaryRequestobj.toString(), "caseProcedures[0]");
		if(cptCode!=null && !cptCode.isEmpty()) {
			for (int i = 0; i < cptCode_mul.split("[|]").length; i++) {
				cptCode = cptCode_mul.split("[|]")[i];
				try {
					lterality = lterality_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					physicianUser = physicianUser_mul.split("[;]")[i];
				} catch (Exception e) {
				}	
				String diagCodePreOp ="";
				try {
					diagCodePreOp = preOpDiagnosisCode.split("[;]")[i];
				} catch (Exception e) {
				}
						

				String feeScheduleSearchResponse = getFeeScheduleByCptCode(cptCode).asString().replaceAll("\\[", "")
						.replaceAll("\\]", "");
				Object feeschedule = jsonUtils.getObjectFromJsonXpath(feeScheduleSearchResponse, "$");

				Object tempObj = feeScheduleObj;

				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "cptCode", cptCode);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "feeScheduleItem", feeschedule);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "procedureDescription",
						jsonUtils.getObjectFromJsonXpath(feeschedule, "cptProcedure.cptDescription"));
				String completeCPT = jsonUtils.getObjectFromJsonXpath(feeschedule, "cptProcedure.cptCode").toString() + "; "
						+ jsonUtils.getObjectFromJsonXpath(feeschedule, "cptProcedure.cptDescription").toString();
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "procedureDisplayName", completeCPT);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "selfPayTf", false);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "modifiedProcedureDescription",
						jsonUtils.getObjectFromJsonXpath(feeschedule, "cptProcedure.cptDescription"));
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "feeScheduleId",
						jsonUtils.getObjectFromJsonXpath(feeschedule, "feeScheduleId"));

				List<Object> lateral = Getlaterality(lterality);
				List<Object>physiciandetails = getPhysicianNameIDFromPhysicianName(physicianUser);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "lateralityText", lateral.get(1));
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "laterality", lateral.get(0));
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "physicianId",physiciandetails.get(2).toString());
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "physician", physiciandetails.get(0).toString());
				if(!diagCodePreOp.isEmpty()) {
					JSONArray preopArraay = new JSONArray();	
					for (int k = 0; k < diagCodePreOp.split("[,]").length; k++) {
						String icdCodeDesc = returnIcdDescFromICDCode(diagCodePreOp.split("[,]")[k]);
						JSONObject preopObj = new JSONObject();
						preopObj.put("diagnosisId", 0);
						preopObj.put("procedureId",JSONObject.NULL);
						preopObj.put("diagnosis", icdCodeDesc);
						preopObj.put("icdCode", diagCodePreOp.split("[,]")[k]);
						preopObj.put("dictionaryItem", JSONObject.NULL);
						preopObj.put("masterDiagnosisId", 0);
						preopArraay = preopArraay.put(preopObj);
					}
					tempObj = jsonUtils.returnJsonObjectFromString(tempObj.toString()).put("diagnosisList", preopArraay);

				}

				Object feeScheduleObjDocument = Configuration.defaultConfiguration().jsonProvider()
						.parse(tempObj.toString());
				org.json.JSONArray arrayObj = null;
				if (i > 0) {
					String obj = jsonUtils.getObjectFromJsonXpath(caseSummaryRequestobj.toString(), "caseProcedures")
							.toString();
					arrayObj = jsonUtils.returnJsonArrayFromString(obj);
					arrayObj = arrayObj.put(feeScheduleObjDocument);
					caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
							"caseProcedures",
							Configuration.defaultConfiguration().jsonProvider().parse(arrayObj.toString()));
				} else {
					caseSummaryRequestobj = jsonUtils.updateObjectJsonXpath(caseSummaryRequestobj.toString(),
							"caseProcedures[0]", feeScheduleObjDocument);
				}
			}
		}
		return caseSummaryRequestobj;
	}

	protected Response getScheduledProcedures(String caseSummaryId) throws Exception {
		String relURL = "ScheduledCaseProcedure/GetScheduledProcedures/" + caseSummaryId + "/false";
		LOG.info(String.format("Getting scheduled case procedures for %s ", caseSummaryId));
		Response scheduledProceduresResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (scheduledProceduresResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					scheduledProceduresResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return scheduledProceduresResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					scheduledProceduresResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getCaseSummaryInfo(String caseSummaryId) throws Exception {
		String relURL = "CaseSummary/GetCaseSummaryInfo/" + caseSummaryId;
		LOG.info(String.format("Getting case summary info %s", caseSummaryId));
		Response caseSummaryInfoResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (caseSummaryInfoResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseSummaryInfoResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return caseSummaryInfoResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseSummaryInfoResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getCaseSummary(String caseSummaryId) throws Exception {
		String relURL = "CaseSummary/" + caseSummaryId;
		LOG.info(String.format("Getting case summary %s", caseSummaryId));
		Response caseSummaryResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (caseSummaryResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseSummaryResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return caseSummaryResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseSummaryResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response performCasesToCode(String casesToCodeRequest) throws Exception {
		String relURL = "CaseToCode/SavePerformedItems";
		LOG.info(String.format("Performing cases to code "));
		Response casesToCodeResponseObject = runWebServiceRequest("application/json", casesToCodeRequest, relURL,
				Method.POST);		
		if (casesToCodeResponseObject.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					casesToCodeResponseObject.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.casesToCodeResponse, casesToCodeResponseObject.asString()); 
			return casesToCodeResponseObject;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					casesToCodeResponseObject.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response updateCaseStatus(String caseSummaryId, String caseStatus) throws Exception {
		String relURL = "CaseSummary/UpdateCaseSatus/" + caseSummaryId;
		LOG.info(String.format("Updating case status"));
		Response updateCaseStatusResponse = runWebServiceRequest("application/json", caseStatus, relURL, Method.POST);
		if (updateCaseStatusResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateCaseStatusResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return updateCaseStatusResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateCaseStatusResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response upsertCaseSummaryInfo(String caseSummaryInfo) throws Exception {
		String relURL = "CaseSummary/UpsertCaseSummaryInfo";
		LOG.info(String.format("Upserting case summary info "));
		Response upsertCaseSummaryInfoResponse = runWebServiceRequest("application/json", caseSummaryInfo, relURL,
				Method.POST);
		if (upsertCaseSummaryInfoResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					upsertCaseSummaryInfoResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return upsertCaseSummaryInfoResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					upsertCaseSummaryInfoResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getStaffDetails(String UserName) throws Exception {
		Response staffResponse = getPhysicianeNameAndID();
		if (staffResponse.getStatusCode() == 200) {

			JSONArray staffArray = jsonUtils.returnJsonArrayFromString(staffResponse.asString());
			LOG.info(String.format("staffArray - %s", staffArray));
			JSONObject staffDetails = jsonUtils.getJSONObjectFromJSONArray(staffArray, "lastName", UserName);
			LOG.info(String.format("staffdetails.....>%s", staffDetails.toString()));

			this.mapWebServiceResponses.put(IWebServiceResponseKeys.staffId, staffDetails.get("staffId"));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.staffFullName, staffDetails.get("fullName"));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.staffRoleId, staffDetails.get("roleId"));
		}
		return staffResponse;
	}

	protected Object getCaseDetailInformation(String departmentname) throws Exception {
		String patientID = this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString();
		String caseSummaryID = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();

		String relURL = "PatientFacesheet/GetCaseDetailInformation/" + patientID + "/" + caseSummaryID;
		// API to getCaseDetailInformation
		Response caseDetailInfoResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (caseDetailInfoResp.getStatusCode() == 200) {

			JSONArray moduleary = jsonUtils.returnJsonArrayFromString(
					jsonUtils.getObjectFromJsonXpath(caseDetailInfoResp.asString(), "modules").toString());
			JSONObject recoverObject = jsonUtils.getJSONObjectFromJSONArray(moduleary, "moduleName", departmentname);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseItemId, recoverObject.get("itemId"));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseModuleId, recoverObject.get("moduleId"));
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseDetailInfoResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseDetailInfoResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return caseDetailInfoResp;
	}

	protected Object getFormByName() throws Exception {
		String relURL = "RecordHeader/Patient Panel/GetFormbyName";
		// API to getFormByName
		Response formByNameResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (formByNameResp.getStatusCode() == 200) {

			String formId = jsonUtils.getObjectFromJsonXpath(formByNameResp.asString(), "formId").toString();
			String formName = jsonUtils.getObjectFromJsonXpath(formByNameResp.asString(), "formName").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseFormId, formId);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseFormName, formName);
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formByNameResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formByNameResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		return formByNameResp;

	}

	protected Object getFormUsagebyByFormOwner() throws Exception {
		String moduleId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString();
		String caseSummaryID = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		String formId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString();

		String relURL = "FormUsage/GetFormUsagebyByFormOwner";
		// API to getFormUsagebyByFormOwner
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/GetFormUsagebyByFormOwner.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId", caseSummaryID);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId", Integer.parseInt(moduleId));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formId", Integer.parseInt(formId));

		Response formUsageByOwnerResp = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (formUsageByOwnerResp.getStatusCode() == 200) {
			LOG.info(String.format("formUsageByOwnerResp..................>%s", formUsageByOwnerResp.asString()));
			String formUsageId = jsonUtils.getObjectFromJsonXpath(formUsageByOwnerResp.asString(), "formId").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseFormUsageId, formUsageId);

			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formUsageByOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formUsageByOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return formUsageByOwnerResp;
	}

	protected Object updateFormUsagebyByFormOwner() throws Exception {
		String relURL = "FormUsage/UpdateFormUsageByFormOwner";
		// API to updateFormUsagebyByFormOwner
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/updateFormUsagebyByFormOwner.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formUsageId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormUsageId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "staffId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "staffName",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffFullName).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "lastUpdated",
				ReusableUtils.getDate("yyyy-MM-dd") + "T01:00:00.000");

		Response updateFormUsagebyByFormOwnerResp = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (updateFormUsagebyByFormOwnerResp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateFormUsagebyByFormOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateFormUsagebyByFormOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return updateFormUsagebyByFormOwnerResp;
	}

	protected Object insertAreaOfCareInformation(String procedureDt) throws Exception {
		String relURL = "AreaCareInformation/InsertAreaCareInformation";
		// API to insertAreaOfCareInformation
		Object obj = null;
		procedureDt = ReusableUtils.addDate(procedureDt, "yyyy-MM-dd");
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/InsertAreaOfCareInformation.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId",
				Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "patientId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "admissionTime",
				procedureDt + "T" + ReusableUtils.getDate("hh:mm") + ":00+05:30");//2020-08-31T22:43:00+05:30
		Response insertAreaOfCareInforResp = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (insertAreaOfCareInforResp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertAreaOfCareInforResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertAreaOfCareInforResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return insertAreaOfCareInforResp;
	}

	protected Object saveAreaOfCareStaffDetails() throws Exception {
		String relURL = "AreaOfCareStaffEntry/SaveAreaOfCareStaffDetails";
		// API to saveAreaOfCareStaffDetails
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/SaveAreaOfCareStaffDetails.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].staffId",
				Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].staffRoleId",
				Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffRoleId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].inTimeDt",
				ReusableUtils.getDate("yyyy-MM-dd") + "T" + ReusableUtils.getDate("hh:mm") + ":00"+timeZonveValue);

		Response saveAreaOfCareStaffDetailsResp = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (saveAreaOfCareStaffDetailsResp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					saveAreaOfCareStaffDetailsResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					saveAreaOfCareStaffDetailsResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return saveAreaOfCareStaffDetailsResp;
	}

	protected Object saveAreaOfCareStaffDetails(String Outtime) throws Exception {
		String relURL = "AreaOfCareStaffEntry/SaveAreaOfCareStaffDetails";
		// API to saveAreaOfCareStaffDetails
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/SaveAreaOfCareStaffDetailsWithOutTime.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].staffId",
				Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].staffRoleId",
				Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.staffRoleId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].inTimeDt",
				ReusableUtils.getDate("yyyy-MM-dd") + "T" + ReusableUtils.getDate("hh:mm") + ":00"+timeZonveValue);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "areaofCareStaffEntryDetails[0].outTimeDt",
				ReusableUtils.getDate("yyyy-MM-dd") + "T" + ReusableUtils.getDate("hh:mm") + ":00"+timeZonveValue);

		Response saveAreaOfCareStaffDetailsResp = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (saveAreaOfCareStaffDetailsResp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					saveAreaOfCareStaffDetailsResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					saveAreaOfCareStaffDetailsResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return saveAreaOfCareStaffDetailsResp;
	}

	protected String getModulesBycaseId(String Departmentname) throws Exception {

		String casesummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		String orgId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString();
		JSONObject request = new JSONObject();
		String relURL = "Module/GetModulesBycaseId/" + casesummaryId + "/undefined?organisationId=" + orgId;
		LOG.info(String.format(" getModulesBycaseId"));
		String ModuleId = null;
		Response response = runWebServiceRequest("application/json", request.toString(), relURL, Method.GET);
		JSONArray GetModulesBycaseIdary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("GetModulesBycaseIdary - %s", GetModulesBycaseIdary));
		JSONObject Modulesjson1 = jsonUtils.getJSONObjectFromJSONArray(GetModulesBycaseIdary, "moduleName",
				Departmentname);

		ModuleId = jsonUtils.getValueFromJsonObject(Modulesjson1.toString(), "moduleId");
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseModuleId, ModuleId);
		return ModuleId;

	}

	protected Response getAreaCareInformationsbyCase() throws Exception {
		String patientId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString();
		String casesummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		JSONObject request = new JSONObject();
		String relURL = "AreaCareInformation/GetAreaCareInformationsbyCase";
		request.put("casesummaryId", Integer.parseInt(casesummaryId));
		request.put("patientId", Integer.parseInt(patientId));
		
		LOG.info(String.format("get AreaCare Informations by Case"));
		Response getAreaCareInformationsbyCase = runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
		
		
		if (getAreaCareInformationsbyCase.asString() != null && !getAreaCareInformationsbyCase.asString().equalsIgnoreCase("") && !getAreaCareInformationsbyCase.asString().equalsIgnoreCase("[]"))
		{
			String areaOfCareInformationIdvalue = jsonUtils.getObjectFromJsonXpath(getAreaCareInformationsbyCase.asString(), "$.[0].areaOfCareInformationId").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.areaOfCareInformationId,areaOfCareInformationIdvalue);
		}
		return getAreaCareInformationsbyCase;
	}

	protected Response getAreaCareInformationsbyCase(String Departmentname) throws Exception {
		int patientId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString());
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		int moduleId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		JSONObject request = new JSONObject();
		String relURL = "AreaCareInformation/GetAreaCareInformationsbyCase";
		request.put("casesummaryId", casesummaryId);
		request.put("patientId", patientId);
		request.put("moduleId", moduleId);
		LOG.info(String.format("get AreaCare Informations by Case"));
		Response getAreaCareInformationsbyCase = runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
		
		
		if (getAreaCareInformationsbyCase.asString() != null && !getAreaCareInformationsbyCase.asString().equalsIgnoreCase("") && !getAreaCareInformationsbyCase.asString().equalsIgnoreCase("[]"))
		{
			String areaOfCareInformationIdvalue = jsonUtils.getObjectFromJsonXpath(getAreaCareInformationsbyCase.asString(), "$.[0].areaOfCareInformationId").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.areaOfCareInformationId,areaOfCareInformationIdvalue);
		}
		return getAreaCareInformationsbyCase;
	}

	protected Response CaseSummaryUpdateCaseSatus(int casestatus) throws Exception {

		String casesummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		String relURL = "CaseSummary/UpdateCaseSatus/" + casesummaryId;
		// TODO: find out proper format to send case status and find out from where do
		// we get case status
		LOG.info(String.format("get AreaCare Informations by Case"));
		return runWebServiceRequest("application/json", "0", relURL, Method.POST);
	}

	protected Response getAreaCareInformationsbyCase(int moduleid) throws Exception {
		int patientId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString());
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		JSONObject request = new JSONObject();
		String relURL = "AreaCareInformation/GetAreaCareInformationsbyCase";
		request.put("casesummaryId", casesummaryId);
		request.put("patientId", patientId);
		request.put("moduleId", moduleid);
		LOG.info(String.format("get AreaCare Informations by Case"));
		return runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
	}

	protected Response requestLock() throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		int moduleId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		JSONObject request = new JSONObject();
		String relURL = "Security/RecordLock/RequestLock";
		request.put("casesummaryId", casesummaryId);
		request.put("RecordLockTypeId", 16);
		request.put("moduleId", moduleId);
		LOG.info(String.format("requestLock"));
		return runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
	}
	
	protected Response getPatientHandsOffData() throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		int moduleId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());
		String relURL = "/patientHandOff/GetPatientHandsOffData?casesummaryId=" + casesummaryId + "&moduleId="
				+ moduleId;
		LOG.info(String.format("get PatientHandsOffData"));
		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Object insertPatientHandOffData(int caseStatus, int defaultCaseStatusId, String discharged_To_Value) throws Exception {
				String relURL = "patientHandOff/InsertPatientHandOffData";
		String getPatientHandsOffDataResponse = getPatientHandsOffData().asString();
		Object getPatientHandsOffDataobj = jsonUtils.getObjectFromJsonXpath(getPatientHandsOffDataResponse, "$");
		Object insertPatientHandOffData = getPatientHandsOffDataobj;
		Response insertPatientHandOffDataresponse = null;

		String transfertime = ReusableUtils.getDate("yyyy-MM-dd") + "T" + ReusableUtils.getDate("hh:mm") + ":00+05:30";
		String transferTimeOF_Time = ReusableUtils.getDate("MM-dd-yyyy") + " " + ReusableUtils.getDate("hh:mm");

		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(), "transferTime",
				transfertime);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(),
				"transferredById", null);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(),
				"dischargedOnDt", transfertime);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(),
				"transferTimeOF_Time", transferTimeOF_Time);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(), "caseStatus",
				caseStatus);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(),
				"defaultCaseStatusId", defaultCaseStatusId);
		insertPatientHandOffData = jsonUtils.updateObjectJsonXpath(insertPatientHandOffData.toString(),
				"dischargeNormalTf", true);
		JSONObject patienthandsoff = new JSONObject(insertPatientHandOffData.toString());
		if(caseStatus != 4 && discharged_To_Value != null) {
			patienthandsoff.put("discharged_To_Value", discharged_To_Value);
			patienthandsoff.put("dischargedToLocationId", Integer.parseInt(getdischargedToLocationIdByvalue(discharged_To_Value)));
		}
		LOG.info(String.format("insertPatientHandOffData.......>%s", insertPatientHandOffData.toString()));
		
		insertPatientHandOffDataresponse = runWebServiceRequest("application/json", patienthandsoff.toString(),
				relURL, Method.POST);
		

		return insertPatientHandOffDataresponse;
	}

	protected Object UpsertCaseSummaryInfo() throws Exception {

		String relURL = "CaseSummary/UpsertCaseSummaryInfo";
		// API to UpsertCaseSummaryInfo
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/UpsertCaseSummaryInfo.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "acuteChronicTf", true);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "created",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseStartTime).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "status", "10");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "statusAtDischarge", "10");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "previousStatus", "04");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "appointmentId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseAppointmentId).toString());

		Response UpsertCaseSummaryInfoResponse = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.PUT);

		LOG.info(String.format("insertPatientHandOffData.......>%s", UpsertCaseSummaryInfoResponse.toString()));

		return UpsertCaseSummaryInfoResponse;
	}

	protected Object UpsertCaseSummaryInfo(String currentStatus, String previousStatus) throws Exception {

		String relURL = "CaseSummary/UpsertCaseSummaryInfo";
		// API to UpsertCaseSummaryInfo
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/UpsertCaseSummaryInfo.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "acuteChronicTf", true);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "created",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseStartTime).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "status", currentStatus);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "statusAtDischarge", "10");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "previousStatus", previousStatus);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "appointmentId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseAppointmentId).toString());

		Response UpsertCaseSummaryInfoResponse = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.PUT);

		LOG.info(String.format("insertPatientHandOffData.......>%s", UpsertCaseSummaryInfoResponse.toString()));

		return UpsertCaseSummaryInfoResponse;
	}

	protected Object UpsertCaseSummaryInfoForArrival() throws Exception {

		String relURL = "CaseSummary/UpsertCaseSummaryInfo";
		JSONObject appointmentTypeJSONObject = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.appointmentType).toString());
		int caseType = Integer.parseInt(jsonUtils.getValueFromJsonObject(appointmentTypeJSONObject.toString(), "caseTypeAfterStartDate"));
		// API to UpsertCaseSummaryInfo
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/UpsertCaseSummaryInfo.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "acuteChronicTf", true);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "created",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseStartTime).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "status", "2");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "statusAtDischarge", null);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "previousStatus", "1");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "appointmentId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseAppointmentId).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseType", caseType);
		Response UpsertCaseSummaryInfoResponse = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.PUT);

		LOG.info(String.format("insertPatientHandOffData.......>%s", UpsertCaseSummaryInfoResponse.toString()));

		return UpsertCaseSummaryInfoResponse;
	}

	protected void dischargePatient(String DischargeDetails, String procedureDt,String preoperationdetails) throws Exception {
		String departmentName;
		String userID;
		String discharged_To = null;
		try {
			if (DischargeDetails.contains(";")) {
				departmentName = DischargeDetails.split("\\;")[0];
				userID = DischargeDetails.split("\\;")[1];
				try {
					discharged_To = DischargeDetails.split("\\;")[2];
				} catch (Exception e) {
					discharged_To = null;
				}
				
			}else
			{
				departmentName = "Recovery";	
				userID = DischargeDetails;
			}
			getStaffDetails(userID);
			getCaseDetailInformation(departmentName);
			getFormByName();
			getFormUsagebyByFormOwner();
			updateFormUsagebyByFormOwner();
			getAreaCareInformationsbyCase();
			getModulesBycaseId(departmentName);
			CaseSummaryUpdateCaseSatus(0);
			requestLock();
			getAreaCareInformationsbyCase(departmentName);
			insertAreaOfCareInformation(procedureDt);
			saveAreaOfCareStaffDetails();
			getAreaCareInformationsbyCase(departmentName);
			getPatientHandsOffData();
			getPatientHandsOffData();
			insertPatientHandOffData(4, 0,null);
			saveAreaOfCareStaffDetails();
			insertPatientHandOffData(10, 10,discharged_To);
			saveAreaOfCareStaffDetails();
			requestLock();
			UpsertCaseSummaryInfo();
			releaseLockPatient(departmentName);
			
			
			if (preoperationdetails != null && !preoperationdetails.isEmpty() && !preoperationdetails.equalsIgnoreCase("blank")) {
				departmentName = "Pre-Operative";	
			//FOr Pre_Operation Add Admit Source value
			requestLock(departmentName);
			getAreaCareInformationsbyCase();
			insertAreaOfCareinforamtion_Operative(preoperationdetails,procedureDt);
			releaseLockPatient(departmentName);
			}
			if (this.reporter != null) {
				this.reporter.logInfo(
						String.format("************** dischargePatient Was success With Out any exceptions*********"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("************** dischargePatient Was un-success With an exception*********"));
			}
			throw e;
		}

	}

	protected Response getPerformedProcedures(String caseSummaryId) throws Exception {
		String relURL = "CaseToCodeComplex/GetPerformProcedures/" + caseSummaryId;
		LOG.info(String.format("Get Performed cases"));
		Response casesToCodeResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (casesToCodeResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					casesToCodeResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					casesToCodeResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getAllPeriods() throws Exception {
		String relURL = "PeriodBatch/GetPeriodBatch/false";
		LOG.info(String.format("Getting all periods"));
		Response periodResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (periodResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					periodResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.allPeriods, new org.json.JSONArray(periodResponse.getBody().asString()));
			return periodResponse;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					periodResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected String getPeriodByName(String periodName) throws Exception {
		org.json.JSONArray periods = new org.json.JSONArray(getAllPeriods().asString());

		for (int index = 0; index < periods.length(); index++) {
			JSONObject period = periods.getJSONObject(index);
			if (period.getString("periodName").equalsIgnoreCase(periodName)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.period, period);
				return period.toString();
			}
		}
		return null;
	}

	protected String getPeriodAndBatchForChargeEntry(String periodName) throws Exception {
		getPeriodByName(periodName);
		JSONObject jsonObject = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.period).toString());
		JSONArray batches = new JSONArray();
		for (int index = 0; index < jsonObject.getJSONArray("batches").length(); index++) {
			org.json.JSONObject batch = jsonObject.getJSONArray("batches").getJSONObject(index);
			batch.put("value", batch.getInt("batchId"));
			batch.put("label", batch.getString("batchDescription"));
			batches.put(batch);
		}
		jsonObject.put("batches", new org.json.JSONArray());
		jsonObject.put("batches", batches);
		return jsonObject.toString();
	}

	protected String getBatchForChargeEntry(String periodName, String batchName) throws Exception {
		JSONObject jsonObject = new JSONObject(getPeriodByName(periodName)); 
		JSONArray batches = jsonObject.getJSONArray("batches");
		for (int i = 0; i < batches.length(); i++) {
			JSONObject batch = batches.getJSONObject(i);
			if (batch.getString("batchDescription").equalsIgnoreCase(batchName)) {
				batch.put("value", batch.getInt("batchId"));
				batch.put("label", batch.getString("batchDescription"));
				return batch.toString();
			}
		}
		return null;
	}

	protected String performChargeEntry(org.json.JSONArray requestBody) throws Exception {
		String relURL = "CaseToCharge/SavePerformedProcedure/";
		LOG.info(String.format("Perform charge entry"));
		Response chargeEntryResponse = runWebServiceRequest("application/json", requestBody.toString(), relURL, Method.POST);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeEntryResponse, chargeEntryResponse.asString()); 
		if (chargeEntryResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					chargeEntryResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return chargeEntryResponse.asString();
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					chargeEntryResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected String createPeriod(String userName, String periodName, String periodBeginDate, String periodEndDate, boolean isActive) throws Exception{
		String relURL = "PeriodConfig/UpsertPeriodObject";
		String existingPeriod = getPeriodByName(periodName);
		List<Object> Physiciandetails = getPhysicianNameIDFromPhysicianName(userName);
		// API to createPeriod
		Object obj = null;
		if(existingPeriod == null) {
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddPeriod.json");
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "periodCreatorUsrId", Physiciandetails.get(2));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "periodName", periodName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "periodBeginDate", periodBeginDate+"T12:50:00"+timeZonveValue);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "periodEndDate", periodEndDate+"T12:50:00"+timeZonveValue);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "isActive", isActive);

			Response periodResponse = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
			String periodId = null;
			if (periodResponse.getStatusCode() == 200) {
				periodId = jsonUtils.getObjectFromJsonXpath(periodResponse.asString(), "periodId").toString();
			}
			return periodId;
		} else {
			return jsonUtils.getObjectFromJsonXpath(existingPeriod, "periodId").toString();
		}
	}

	protected Response createBatch(String userName, String periodId, String batchName)  throws Exception{
		String relURL = "PeriodBatch/InsertBatch";
		List<Object> Physiciandetails = getPhysicianNameIDFromPhysicianName(userName);
		// API to createBatch
		getPeriodById(periodId);
		String periodObject = this.mapWebServiceResponses.get(IWebServiceResponseKeys.period).toString();
		String periodName = jsonUtils.getValueFromJsonObject(periodObject, "periodName");
		String batchObject = getBatchForChargeEntry(periodName, batchName);
		if(batchObject == null) {
			Object obj = null;
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/InsertBatch.json");
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "batchCreatorUsrId", Physiciandetails.get(2));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "periodId", Integer.parseInt(periodId));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "batchDescription", batchName);

			return runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		}
		return null;
	}

	protected org.json.JSONObject performPatientCasesToCode(String diagnosisCode) throws Exception{
		Object casesToCodeRequestObj = null;
		casesToCodeRequestObj = jsonUtils.getJsonFileAsObject("reqTemplates/CasesToCodeRequest.json");

		String caseSummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		org.json.JSONArray scheduledProcedures = null;

		scheduledProcedures = new org.json.JSONArray(getScheduledProcedures(caseSummaryId).asString());
		org.json.JSONArray diagnosisCodes = new org.json.JSONArray(getICDCode(diagnosisCode).asString());
		org.json.JSONObject diagnosisCodeObject = jsonUtils.getJSONObjectFromJSONArray(diagnosisCodes, "icdCode",
				diagnosisCode);
		Object performedProcedure = jsonUtils.getObjectFromJsonXpath(casesToCodeRequestObj.toString(),
				"performedItems[0]");
		org.json.JSONArray performedItems = new org.json.JSONArray();
		org.json.JSONArray deletedPerformedItems = new org.json.JSONArray();
		org.json.JSONObject casesToCode = new org.json.JSONObject();

		for (int index = 0; index < scheduledProcedures.length(); index++) {
			Object tempObject = performedProcedure;
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "units", 1.0);
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "caseSummaryId",
					jsonUtils.getIntegerFromJsonObject(scheduledProcedures.getJSONObject(index).toString(),
							"caseSummaryId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "providerId", jsonUtils
					.getIntegerFromJsonObject(scheduledProcedures.getJSONObject(index).toString(), "physicianId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "cptProcedureId", jsonUtils
					.getIntegerFromJsonObject(scheduledProcedures.getJSONObject(index).toString(), "cptProcedureId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "feeScheduleItem",
					jsonUtils.getObjectFromJsonXpath(scheduledProcedures.getJSONObject(index).toString(),
							"feeScheduleItem"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "sortorder", index);
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "feeScheduleId",
					jsonUtils.getIntegerFromJsonObject(scheduledProcedures.getJSONObject(index).toString(),
							"feeScheduleId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "caseProcedureId",
					jsonUtils.getIntegerFromJsonObject(scheduledProcedures.getJSONObject(index).toString(),
							"caseProcedureId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "cptCode", jsonUtils
					.getObjectFromJsonXpath(scheduledProcedures.getJSONObject(index).toString(), "cptCode"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "cptProcedureDescription", jsonUtils
					.getObjectFromJsonXpath(scheduledProcedures.getJSONObject(index).toString(), "cptDescription"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "physicianName", jsonUtils
					.getObjectFromJsonXpath(scheduledProcedures.getJSONObject(index).toString(), "physicianName"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(),
					"diagnosisList[0].dictionaryItem.id",
					jsonUtils.getIntegerFromJsonObject(diagnosisCodeObject.toString(), "icdCodeId"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(),
					"diagnosisList[0].dictionaryItem.quickCode",
					jsonUtils.getObjectFromJsonXpath(diagnosisCodeObject.toString(), "icdCode"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(),
					"diagnosisList[0].dictionaryItem.value",
					jsonUtils.getObjectFromJsonXpath(diagnosisCodeObject.toString(), "icdCodeDescription"));
			tempObject = jsonUtils.updateObjectJsonXpath(tempObject.toString(), "diagnosisList[0].diagnosisId",
					jsonUtils.getIntegerFromJsonObject(diagnosisCodeObject.toString(), "icdCodeId"));
			performedItems.put(new org.json.JSONObject(tempObject.toString()));
		}
		casesToCode = casesToCode.put("performedItems", performedItems);
		casesToCode = casesToCode.put("deletedPerformedItems", deletedPerformedItems);
		LOG.info("Cases to code request object ");
		LOG.info(casesToCode.toString(4));

		String casesToCodeResponse = performCasesToCode(casesToCode.toString()).asString();
		org.json.JSONObject casesToCodeObject = new org.json.JSONObject(casesToCodeResponse);
		LOG.info(casesToCodeResponse);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.casesToCodeResponse, casesToCodeResponse);
		updateCaseStatus(caseSummaryId, "11");
		UpsertCaseSummaryInfo("11", "10");
		LOG.info(casesToCodeObject.toString(4));
		return casesToCodeObject;
	}

	protected void performPatientChargeEntry(JSONObject casesToCodeResponse, String PeriodName, String BatchName, String amount) throws Exception{
		org.json.JSONArray chargeEntryRequestBody = new org.json.JSONArray();
		org.json.JSONObject period = new org.json.JSONObject(getPeriodAndBatchForChargeEntry(PeriodName).toString());
		org.json.JSONObject batch = new org.json.JSONObject(getBatchForChargeEntry(PeriodName, BatchName).toString());

		LOG.info(casesToCodeResponse.toString(4));
		String amount_mul = amount;
		//String amountForChargeEntry = null;
		List<String> allAmounts = new ArrayList<String>();
		if(amount_mul != null) {
			if(amount_mul.contains(";")) {
				allAmounts = Arrays.asList(amount_mul.split("[;]"));
			} else {
				allAmounts.add(amount_mul);
			}
		}
		org.json.JSONArray performedProcedures = casesToCodeResponse.getJSONArray("performedItems");
		String caseSummaryId = "";
		for(int i = 0; i < performedProcedures.length(); i++) {
			org.json.JSONObject performedProcedure = performedProcedures.getJSONObject(i);
			org.json.JSONArray chargeEntryRequestObject = new org.json.JSONArray(jsonUtils.getJsonFileAsObject("reqTemplates/chargeEntryRequest.json").toString());
			org.json.JSONObject chargeEntryObject = chargeEntryRequestObject.getJSONObject(0);
			org.json.JSONArray transactionList = chargeEntryObject.getJSONArray("transactionList");
			org.json.JSONObject transactionObject = transactionList.getJSONObject(0);
			org.json.JSONObject chargeDetails = transactionObject.getJSONObject("chargeDetails");
			org.json.JSONObject chargeTransactionObject = chargeEntryObject.getJSONObject("chargeTransaction");
			org.json.JSONObject chargeTransactionChargeDetails = chargeTransactionObject.getJSONObject("chargeDetails");
			chargeEntryObject.put("cptProcedureId", performedProcedure.getInt("cptProcedureId"));
			chargeEntryObject.put("patientId", performedProcedure.getInt("patientId"));
			chargeEntryObject.put("caseProcedureId", performedProcedure.getInt("caseProcedureId"));
			chargeEntryObject.put("cptCode", performedProcedure.getString("cptCode"));
			chargeEntryObject.put("physicianName", performedProcedure.getString("physicianName"));
			chargeEntryObject.put("performedCaseProcedureId", performedProcedure.getInt("performedCaseProcedureId"));
			chargeDetails.put("performedCaseProcedureId", performedProcedure.getInt("performedCaseProcedureId"));
			chargeDetails.put("balance", Integer.valueOf(Math.round(Float.parseFloat(allAmounts.get(i)))));
			chargeDetails.put("transactionId", 0);
			chargeEntryObject.put("units", 1);
			chargeEntryObject.put("sortorder", i);
			caseSummaryId = ""+performedProcedure.getInt("caseSummaryId");
			chargeEntryObject.put("feeScheduleItem", performedProcedure.getJSONObject("feeScheduleItem"));
			chargeEntryObject.put("cptProcedureDescription", performedProcedure.getString("cptProcedureDescription"));
			chargeEntryObject.put("caseSummaryId", performedProcedure.getInt("caseSummaryId"));
			chargeEntryObject.put("providerId", performedProcedure.getInt("providerId"));
			chargeEntryObject.put("feeScheduleId", performedProcedure.getInt("feeScheduleId"));
			chargeEntryObject.put("diagnosisList", performedProcedure.getJSONArray("diagnosisList"));
			chargeTransactionObject.put("period", period);
			chargeTransactionObject.put("batch", batch);
			chargeTransactionObject.put("transactionId", 0);
			chargeEntryObject.put("batch", batch);
			transactionObject.put("period", period);
			transactionObject.put("batch", batch);
			transactionObject.put("periodId", period.getInt("periodId"));
			transactionObject.put("batchId", batch.getInt("batchId"));
			transactionObject.put("transactionId", 0);
			transactionObject.put("amount", allAmounts.get(i));
			transactionObject.put("batchDescription", batch.getString("batchDescription"));
			transactionList = new org.json.JSONArray();
			transactionObject.put("chargeDetails", chargeDetails);
			transactionList.put(transactionObject);
			chargeEntryObject.put("transactionList", transactionList);
			chargeTransactionChargeDetails.put("peformedCaseProcedureId", performedProcedure.getInt("performedCaseProcedureId"));
			chargeTransactionChargeDetails.put("balance", Integer.valueOf(Math.round(Float.parseFloat(allAmounts.get(i)))));
			chargeTransactionChargeDetails.put("transactionId", 0);
			chargeTransactionObject.put("periodId", period.getInt("periodId"));
			chargeTransactionObject.put("batchId", batch.getInt("batchId"));
			chargeTransactionObject.put("batchDescription", batch.getString("batchDescription"));
			chargeTransactionObject.put("amount", Float.parseFloat(allAmounts.get(i)));
			chargeTransactionObject.put("period", period);
			chargeTransactionObject.put("batch", batch);
			chargeTransactionObject.put("chargeDetails", chargeTransactionChargeDetails);
			chargeEntryObject.put("chargeTransaction", chargeTransactionObject);
			
			
			JSONArray chargeEntryPatientInsMapArr = new JSONArray();
			if(this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.primaryInsuranceId)
					&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.primaryInsuranceId)!=null) {
				
				int patientInsuranceId =  Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.primaryInsuranceId).toString());
				chargeEntryObject.put("primaryInsuranceId", patientInsuranceId);
				JSONObject chargeEntryPatientInsMapObj = new JSONObject();
				chargeEntryPatientInsMapObj.put("patientInsuranceId", patientInsuranceId);
				chargeEntryPatientInsMapObj.put("chargeEntryDetailsId", 0);
				chargeEntryPatientInsMapObj.put("insuranceUsedInTransfer", false);
				chargeEntryPatientInsMapObj.put("sortOrder", 0);
				chargeEntryPatientInsMapObj.put("canBillGenerated", true);
				chargeEntryPatientInsMapArr.put(chargeEntryPatientInsMapObj);
				chargeEntryObject.put("chargeEntryPatientInsMap", chargeEntryPatientInsMapArr);
				
				JSONArray primaryInsurancesListArr = new JSONArray();
				JSONObject primaryInsurancesListObj = new JSONObject();
				primaryInsurancesListObj.put("patientInsuranceId", patientInsuranceId);
				primaryInsurancesListObj.put("displayName", JSONObject.NULL);
				primaryInsurancesListArr.put(primaryInsurancesListObj);
				chargeEntryObject.put("primaryInsurancesList", primaryInsurancesListArr);
			}
						
			if(this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.secondaryInsuranceId)
					&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.secondaryInsuranceId)!=null) {
				
				int patientInsuranceId =  Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.secondaryInsuranceId).toString());
				chargeEntryObject.put("secondaryInsuranceId", patientInsuranceId);
				
				JSONObject chargeEntryPatientInsMapObj = new JSONObject();
				chargeEntryPatientInsMapObj.put("patientInsuranceId", patientInsuranceId);
				chargeEntryPatientInsMapObj.put("chargeEntryDetailsId", 0);
				chargeEntryPatientInsMapObj.put("insuranceUsedInTransfer", false);
				chargeEntryPatientInsMapObj.put("sortOrder", 1);
				chargeEntryPatientInsMapObj.put("canBillGenerated", true);
				chargeEntryPatientInsMapArr.put(chargeEntryPatientInsMapObj);
				chargeEntryObject.put("chargeEntryPatientInsMap", chargeEntryPatientInsMapArr);
				
				JSONArray secondaryInsurancesListArr = new JSONArray();
				JSONObject secondaryInsurancesListObj = new JSONObject();
				secondaryInsurancesListObj.put("patientInsuranceId", patientInsuranceId);
				secondaryInsurancesListObj.put("displayName",  JSONObject.NULL);
				secondaryInsurancesListArr.put(secondaryInsurancesListObj);
				chargeEntryObject.put("secondaryInsurancesList", secondaryInsurancesListArr);
			}
						
			if(this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.tertiaryInsuranceId)
					&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.tertiaryInsuranceId)!=null) {
				
				int patientInsuranceId =  Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.tertiaryInsuranceId).toString());
				chargeEntryObject.put("tertiaryInsuranceId", patientInsuranceId);
				JSONObject chargeEntryPatientInsMapObj = new JSONObject();
				chargeEntryPatientInsMapObj.put("patientInsuranceId", patientInsuranceId);
				chargeEntryPatientInsMapObj.put("chargeEntryDetailsId", 0);
				chargeEntryPatientInsMapObj.put("insuranceUsedInTransfer", false);
				chargeEntryPatientInsMapObj.put("sortOrder", 2);
				chargeEntryPatientInsMapObj.put("canBillGenerated", true);
				chargeEntryPatientInsMapArr.put(chargeEntryPatientInsMapObj);
				chargeEntryObject.put("chargeEntryPatientInsMap", chargeEntryPatientInsMapArr);
				
				JSONArray tertiaryInsurancesListArr = new JSONArray();
				JSONObject tertiaryInsurancesListObj = new JSONObject();
				tertiaryInsurancesListObj.put("patientInsuranceId", patientInsuranceId);
				tertiaryInsurancesListObj.put("displayName",  JSONObject.NULL);
				tertiaryInsurancesListArr.put(tertiaryInsurancesListObj);
				chargeEntryObject.put("tertiaryInsurancesList", tertiaryInsurancesListArr);
			}
			chargeEntryRequestBody.put(chargeEntryObject);
			
		}

		String chargeEntryResponse = performChargeEntry(chargeEntryRequestBody);
		LOG.info(chargeEntryRequestBody.toString(4));

		updateCaseStatus(caseSummaryId, "12").asString();
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeEntryResponse, chargeEntryResponse);
		//Update ChargeDetails Value into map which will be used in transactions(Debit, writeoff, payment)
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry, getChargeDetailsFromChargeEntryResp().toString());

		updateCaseStatus(caseSummaryId, "12").asString();
		UpsertCaseSummaryInfo("12", "11");
	}

	protected org.json.JSONArray getTitratedDrugs(String drugName) {
		String relURL = "FDB/GetDrugNames";
		LOG.info(String.format("Getting drug "+drugName));
		org.json.JSONObject requestBody = new org.json.JSONObject();
		requestBody.put("searchText", drugName.substring(0, 4));
		requestBody.put("searchType", 1);
		requestBody.put("offset", 1);
		requestBody.put("limit", 100);
		Response drugsResponse = runWebServiceRequest("application/json", requestBody.toString(), relURL, Method.POST);
		if (drugsResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONObject drugsResponseObject = new org.json.JSONObject(drugsResponse.asString());
			org.json.JSONArray drugs = drugsResponseObject.getJSONArray("items");
			return drugs;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected org.json.JSONArray getMedicationDrugs(String drugName) {
		String relURL = "Inventory/Search?searchText="+drugName.substring(0,4)+"&category=Medication";
		LOG.info(String.format("Getting drug "+drugName));
		Response drugsResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (drugsResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONArray drugs = new JSONArray(drugsResponse.asString());
			return drugs;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected org.json.JSONArray getMedicationDrugs(String searchText, String drugName) {
		String relURL = "Inventory/Search?searchText="+searchText+"&category=Medication";
		LOG.info(String.format("Getting drug "+drugName));
		Response drugsResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (drugsResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONArray drugs = new JSONArray(drugsResponse.asString());
			return drugs;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					drugsResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected org.json.JSONObject getDrug(String drugType, String searchText, String drugName) {
		org.json.JSONArray drugsByName = null;
		if(drugType.equalsIgnoreCase("Titrated")) {
			drugsByName = getTitratedDrugs(drugName);
			for(int i = 0; i < drugsByName.length(); i++) {
				if(drugsByName.getJSONObject(i).getString("drugNameDesc").equalsIgnoreCase(drugName)) {
					return drugsByName.getJSONObject(i);
				}
			}
		} else if(drugType.equalsIgnoreCase("Compound")) {
			drugsByName = getMedicationDrugs(searchText, drugName);
			for(int i = 0; i < drugsByName.length(); i++) {
				if(drugsByName.getJSONObject(i).getString("name").equalsIgnoreCase(drugName)) {
					return drugsByName.getJSONObject(i);
				}
			}
		}
		return null;
	}

	protected org.json.JSONArray getMedicationTemplates() throws Exception {
		String relURL = "MedicationTemplate/GetMedicationTemplates";
		LOG.info(String.format("Getting all medication templates"));
		Response medicationTemplateResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (medicationTemplateResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONArray medicationTemplates = new org.json.JSONArray(medicationTemplateResponse.asString());
			return medicationTemplates;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected void insertMedicationTemplate(String medicationTemplate) throws Exception {
		String relURL = "MedicationTemplate/Insert/false";
		LOG.info(String.format("Adding new medication template"));
		Response medicationTemplateResponse = runWebServiceRequest("application/json", medicationTemplate, relURL, Method.POST);
		if (medicationTemplateResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected org.json.JSONArray getAllCptProcedures() {
		String relURL = "Procedures/GetAllProcedures";
		LOG.info(String.format("Getting all available cpt procedures"));
		Response cptProceduresResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (cptProceduresResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					cptProceduresResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONArray cptProcedures = new org.json.JSONArray(cptProceduresResponse.asString());
			return cptProcedures;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					cptProceduresResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected org.json.JSONArray getAllFeeSchedules() {
		String relURL = "FeeSchedule/GetFeeSchedules";
		LOG.info(String.format("Getting all available fee schedules"));
		Response feeSchedulesResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (feeSchedulesResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeSchedulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONArray feeSchedules = new org.json.JSONArray(feeSchedulesResponse.asString());
			return feeSchedules;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeSchedulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected org.json.JSONArray getDispensableDrugNames(String drugId) throws Exception {
		String relURL = "FDB/GetDispensableDrugNamesByDrugId";
		LOG.info(String.format("Getting all medication templates %s", drugId));
		org.json.JSONObject requestBody = new org.json.JSONObject();
		requestBody.put("offset", 1);
		requestBody.put("limit", 100);
		requestBody.put("drugNameId", drugId);
		Response medicationTemplateResponse = runWebServiceRequest("application/json", requestBody.toString(), relURL, Method.POST);
		if (medicationTemplateResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			org.json.JSONObject medicationObject = new org.json.JSONObject(medicationTemplateResponse.asString());
			org.json.JSONArray medicationTemplates = medicationObject.getJSONArray("items");
			return medicationTemplates;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					medicationTemplateResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected String addWorklistTemplate(String worklistType, String worklistName, boolean generalFlag, boolean painFlag, boolean giFlag, boolean eyeFlag, boolean laserFlag, String questions) throws Exception{
		String relURL = "WorklistConfiguration/CreateWorklistTemplate";
		// API to createPeriod
		Object obj = null;
		int workListArea = getWorklistArea(worklistType);
		String worklistId = "";
		boolean isPresent = isWorklistPresent(worklistType, worklistName);
		if(!(isPresent)) {
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddWorklistTemplate.json");
			String encodedTemplateName = ReusableUtils.encodeString2Base64(worklistName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "name", encodedTemplateName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistArea", workListArea);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistMappings[0].defaultWorklist", generalFlag);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistMappings[1].defaultWorklist", painFlag);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistMappings[2].defaultWorklist", giFlag);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistMappings[3].defaultWorklist", eyeFlag);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "worklistMappings[4].defaultWorklist", laserFlag);
			LOG.info(String.format("payload object for worklist addition-> %s", obj.toString()));

			Response worklistResponse = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
			worklistId = worklistResponse.asString();

			//Mapping questions to worklist
			if(questions != null&& !questions.trim().isEmpty()) {
				String encodedQuestions = "";
				JsonObject parentObject = new JsonObject();
				JsonArray questionsArray = new JsonArray();
				if(questions.contains(",")) {
					List<String> questionsList = new ArrayList<>();
					questionsList = Arrays.asList(questions.split(","));
					for(int index = 0; index < questionsList.size(); index++) {
						questionsArray.add(getEncodedQuestions(questionsList.get(index)));
					}
				} else {
					JsonObject quesObj = getEncodedQuestions(questions);
					questionsArray.add(quesObj);
				}
				parentObject.add("Questions", questionsArray);
				encodedQuestions = ReusableUtils.encodeString2Base64(parentObject.toString());
				String relURL1 = "WorklistConfiguration/UpdateWorklistTemplate";

				Object requestLock = jsonUtils.getJsonFileAsObject("reqTemplates/recordLock.json");
				requestLock = jsonUtils.updateObjectJsonXpath(requestLock.toString(), "ObjectId", worklistId);
				lockWorklistrecord(requestLock.toString());

				Response worklistObject = runWebServiceRequest("application/json", "", "WorklistConfiguration/GetWorklistTemplate?id=" +worklistId , Method.GET);
				JSONObject worklistRequestObject = new JSONObject(worklistObject.asString());
				worklistRequestObject.put("encodedTemplate", encodedQuestions);
				worklistRequestObject.put("templateObject", JSONObject.NULL);
				try {
					runWebServiceRequest("application/json", worklistRequestObject.toString(), relURL1, Method.POST);
					unlockWorklistRecord(requestLock.toString());
				}catch(Exception e) {
					unlockWorklistRecord(requestLock.toString());
					throw e;
				}
			}
		} else {
			this.reporter.logSuccess(String.format("Worklist %s is already present utilizing the existing one ", worklistName));
			worklistId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.worklistId).toString();
		}
		return worklistId;
	}

	protected String addConsent(String consentName, boolean generalFlag, boolean painFlag, boolean giFlag, boolean eyeFlag, boolean laserFlag,boolean physicianScheduleFlag, boolean procdeureScheduleFlag, 
			boolean diagnosisScheduleFlag, String consentStatementText, String signeeDetails) throws Exception{
		String relURL = "ConsentConfiguration ";
		// API to addConsent
		JSONObject consentCreateObj = new JSONObject();
		String encodedConsentName = ReusableUtils.encodeString2Base64(consentName);
		consentCreateObj.put("consentConfigurationName", encodedConsentName);
		consentCreateObj.put("schedulePhysicianTf", physicianScheduleFlag);
		consentCreateObj.put("scheduleProcedureTf", procdeureScheduleFlag);
		consentCreateObj.put("scheduleDiagnosisTf", diagnosisScheduleFlag);
		consentCreateObj.put("expireTf", false);

		Response consentPostResp = runWebServiceRequest("application/json", consentCreateObj.toString(), relURL, Method.POST);
		int consentID = 0;
		if (consentPostResp.getStatusCode() == 200) {
			consentID = Integer.parseInt(jsonUtils.getObjectFromJsonXpath(consentPostResp.asString(), "consentConfigurationId").toString());
		}

		Object obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddConsents.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentConfigurationId", consentID);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentConfigurationName", encodedConsentName);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "schedulePhysicianTf", physicianScheduleFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "scheduleProcedureTf", procdeureScheduleFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "scheduleDiagnosisTf", diagnosisScheduleFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[0].defaultTf", generalFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[0].consentConfigurationId", consentID);

		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[1].defaultTf", painFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[1].consentConfigurationId", consentID);

		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[2].defaultTf", giFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[2].consentConfigurationId", consentID);

		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[3].defaultTf", eyeFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[3].consentConfigurationId", consentID);

		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[4].defaultTf", laserFlag);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentCaseMappings[4].consentConfigurationId", consentID);

		if(consentStatementText!=null && !consentStatementText.isEmpty()) {
			JSONArray consentStatementTextArry = new JSONArray();
			int statementOrder = 0;
			for(String consentStmtText: consentStatementText.split("[|]")) {
				String signeeDetail = signeeDetails.split("[|]")[statementOrder];
				JSONObject consentStatementTextObj = new JSONObject();
				consentStatementTextObj.put("patientSigneeTf", true);
				if(consentStmtText.contains(",")) {
					String stmtConsents = consentStmtText;
					consentStmtText = consentStmtText.split("[,]")[0];
					String signeeFlag = stmtConsents.split("[,]")[1];
					if(signeeFlag.equalsIgnoreCase("yes")) {
						consentStatementTextObj.put("patientSigneeTf", true);
					}else if(signeeFlag.equalsIgnoreCase("no")) {
						consentStatementTextObj.put("patientSigneeTf", false);
					}
				}

				consentStatementTextObj.put("consentConfigurationId", consentID);

				consentStatementTextObj.put("statementOrder", statementOrder);
				consentStatementTextObj.put("isEditorFocused", false);
				consentStatementTextObj.put("isEditorDisabled", false);
				JSONArray consentStatementSigneeArry = new JSONArray();
				if(signeeDetail!=null && !signeeDetail.isEmpty() && !signeeDetail.equalsIgnoreCase("BLANK")){
					int i = 1;
					for(String signe: signeeDetail.split("[,]")) {
						JSONObject consentStatementSignee = new JSONObject();
						getDictionaryDetails("Mandatory Signee", signe);

						consentStatementSignee.put("signeeDictionaryId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.dictionaryItemId));
						consentStatementSignee.put("signeeDictionaryOrder", i);
						i++;
						consentStatementSigneeArry.put(consentStatementSignee);
					}
				}
				JSONObject consentStatementTextChildObj = new JSONObject();
				consentStatementTextChildObj.put("statementText", ReusableUtils.encodeString2Base64(consentStmtText));
				consentStatementTextObj = consentStatementTextObj.put("consentStatementSignee", consentStatementSigneeArry);
				consentStatementTextObj = consentStatementTextObj.put("consentStatementText", consentStatementTextChildObj);
				consentStatementTextArry = consentStatementTextArry.put(consentStatementTextObj);
				statementOrder++;
			}
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "consentStatements", Configuration.defaultConfiguration().jsonProvider().parse(consentStatementTextArry.toString()));
		}

		LOG.info(String.format("payload object for Consent addition-> %s", obj.toString()));
		Response consentResp = runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
		LOG.info(String.format("Consent Addition response for ConsentName: %s is -> %s", consentName, consentResp.asString()));
		return consentResp.asString();
	}

	protected JSONArray getCptCodes(String cptCode) {
		String relURL = "Procedures/GetAllProceduresBySearchString";
		LOG.info(String.format("Get available CPT codes"));
		Response cptProcedures = runWebServiceRequest("application/json", ""+cptCode+"", relURL, Method.POST);
		if (cptProcedures.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					cptProcedures.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return new JSONArray(cptProcedures.asString());
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					cptProcedures.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected JSONArray getAnesthesiaModulesForOrganization() {
		String relURL = "Module/GetAnesthesiaModulesForOrganization/true";
		LOG.info(String.format("Get modules "));
		Response modulesResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (modulesResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					modulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return new JSONArray(modulesResponse.asString());
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					modulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected JSONObject insertFeeSchedule(String feeScheduleJson) {
		String relURL = "FeeSchedule/Insert";
		LOG.info(String.format("Insert feeschedule "));
		Response feeScheduleResponse = runWebServiceRequest("application/json", feeScheduleJson, relURL, Method.POST);
		if (feeScheduleResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeScheduleResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return new JSONObject(feeScheduleResponse.asString());
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeScheduleResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected void updateFeeSchedule(String feeScheduleJson) {
		String relURL = "FeeSchedule/Update";
		LOG.info(String.format("Update feeschedule "));
		Response feeScheduleResponse = runWebServiceRequest("application/json", feeScheduleJson, relURL, Method.POST);

		if (feeScheduleResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeScheduleResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeScheduleResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected void insertFeeScheduleRecord(String cptCode, int amount, String billableStatus) throws Exception {
		try {
			// Get available CPT Procedures for given cpt code
			org.json.JSONArray cptProcedures = getCptCodes(cptCode);

			Object insertFeeScheduleRequestobj = jsonUtils.getJsonFileAsObject("reqTemplates/insertFeeSchedule.json");
			Object updateFeeScheduleRequestobj = jsonUtils.getJsonFileAsObject("reqTemplates/updateFeeSchedule.json");

			// Get request objects
			org.json.JSONObject insertFeeScheduleRequest = new org.json.JSONObject(insertFeeScheduleRequestobj.toString());
			org.json.JSONObject updateFeeScheduleRequest = new org.json.JSONObject(updateFeeScheduleRequestobj.toString());

			// Get required cpt procedure
			org.json.JSONObject cptCodeObject = jsonUtils.getJSONObjectFromJSONArray(cptProcedures, "cptCode", cptCode);

			// Inserting feeschedule for given cpt code
			insertFeeScheduleRequest.put("feeScheduleHistoryId", 0);
			insertFeeScheduleRequest.put("feeScheduleRootId", 0);
			insertFeeScheduleRequest.put("procedureDisplayName", cptCode+"; "+cptCodeObject.getString("cptDescription"));
			insertFeeScheduleRequest.put("feeScheduleId", 0);
			insertFeeScheduleRequest.put("procedure", cptCodeObject.getString("cptDescription"));
			insertFeeScheduleRequest.put("status", JSONObject.NULL);
			insertFeeScheduleRequest.put("cptProcedure",cptCodeObject);
			insertFeeScheduleRequest.put("amount", JSONObject.NULL);
			insertFeeScheduleRequest.put("cptProcedureId", cptCodeObject.getInt("cptProcedureId"));
			insertFeeScheduleRequest.put("effectiveDate", JSONObject.NULL);
			insertFeeScheduleRequest.put("procedureDisplayName", insertFeeScheduleRequest.get("procedureDisplayName"));
			insertFeeScheduleRequest.put("modifiedProcedureDescription", JSONObject.NULL);
			insertFeeScheduleRequest.put("activeTf", true);
			insertFeeScheduleRequest.put("isIncludeStateReportTf", true);
			org.json.JSONObject insertFeeScheduleResponse = insertFeeSchedule(insertFeeScheduleRequest.toString());

			// Updating feeschedule for given amount and display name
			updateFeeScheduleRequest.put("feeScheduleId", insertFeeScheduleResponse.getInt("feeScheduleId"));
			updateFeeScheduleRequest.put("procedure", cptCodeObject.getString("cptDescription"));
			updateFeeScheduleRequest.put("cptProcedureId", cptCodeObject.getInt("cptProcedureId"));
			cptCodeObject.put("procedureDisplayName", cptCodeObject.getString("cptCode") + "; "+ cptCodeObject.getString("cptDescription"));
			updateFeeScheduleRequest.put("cptProcedure", cptCodeObject);
			updateFeeScheduleRequest.put("procedureDisplayName", cptCodeObject.getString("procedureDisplayName"));
			updateFeeScheduleRequest.put("modifiedProcedureDescription", insertFeeScheduleRequest.getString("procedureDisplayName"));
			updateFeeScheduleRequest.put("effectiveDate", ReusableUtils.getDate("yyyy-MM-dd") + "T00:00:00+00:00");
			updateFeeScheduleRequest.put("feeScheduleHistoryId", insertFeeScheduleResponse.getInt("feeScheduleHistoryId"));
			updateFeeScheduleRequest.put("feeScheduleRootId", insertFeeScheduleResponse.getInt("feeScheduleRootId"));
			updateFeeScheduleRequest.put("activeTf", true);
			updateFeeSchedule(updateFeeScheduleRequest.toString());
			updateFeeScheduleRequest.put("amount", amount);
			updateFeeSchedule(updateFeeScheduleRequest.toString());
			updateFeeScheduleRequest.put("status", billableStatus);
			updateFeeSchedule(updateFeeScheduleRequest.toString());
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(String.format("Unable to add fee schedule for given cpt code %s", cptCode));
			throw e;
		}
	}

	protected org.json.JSONArray getDictionaryItems(String dictionaryItemId) {
		String relURL = "Dictionary/v2/" + dictionaryItemId;
		LOG.info(String.format("Get dictionary items "+ dictionaryItemId));
		Response dictionaryItems = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (dictionaryItems.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					dictionaryItems.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return new JSONArray(dictionaryItems.asString());
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					dictionaryItems.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Object getMedicationObject(org.json.JSONObject titratedDrug, org.json.JSONObject dispensableDrugObject, String department, String speciality, String Medication, String TemplateName, String TotalUnits,
			String BolusUnit, String BolusDose, String DispensableDrug, String RouteDesc, String isTitratedMedication) throws Exception{		

		Object compoundMedicationRequestObj = jsonUtils.getJsonFileAsObject("reqTemplates/medicationTemplate.json");
		compoundMedicationRequestObj = jsonUtils.updateOneJsonElement(compoundMedicationRequestObj.toString(), "compoundTf", false);
		compoundMedicationRequestObj = jsonUtils.updateOneJsonElement(compoundMedicationRequestObj.toString(), "titratedTf", false);
		if(!titratedDrug.isNull("defaultETCDesc")) {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCDesc", titratedDrug.get("defaultETCDesc"));
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "defaultETCDesc", titratedDrug.get("defaultETCDesc"));
		}
		if(!titratedDrug.isNull("defaultETCID")) {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCID", titratedDrug.get("defaultETCID"));
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "defaultETCID", titratedDrug.get("defaultETCID"));
		}

		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", titratedDrug.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", titratedDrug.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCode", titratedDrug.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCodeDesc", titratedDrug.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCode", titratedDrug.getInt("statusCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCodeDesc", titratedDrug.getString("statusCodeDesc"));				
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "dispensableDrugId", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableDrugID", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableDrugDesc", dispensableDrugObject.getString("dispensableDrugDesc"));
		if(!dispensableDrugObject.isNull("dispensableGenericID")) {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericID", dispensableDrugObject.get("dispensableGenericID").toString());
		} else {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericID", null);
		}

		if(!dispensableDrugObject.isNull("dispensableGenericDesc")) {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericDesc", dispensableDrugObject.get("dispensableGenericDesc").toString());
		} else {
			compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericDesc", null);
		}

		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", dispensableDrugObject.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", dispensableDrugObject.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCode", dispensableDrugObject.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCodeDesc", dispensableDrugObject.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCodeDesc", dispensableDrugObject.getString("statusCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "templateName", TemplateName);
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medication", dispensableDrugObject.getString("dispensableDrugDesc"));

		if(department != null) {
			JSONArray medicationTemplateModuleMapList = new JSONArray(); 
			JSONArray modules = this.getAnesthesiaModulesForOrganization();
			if(department.contains(";")) {
				List<String> departments = Arrays.asList(department.split("[;]"));
				for(String depName: departments) {
					medicationTemplateModuleMapList.put(new JSONObject().put("moduleId", jsonUtils.getJSONObjectFromJSONArray(modules, "moduleName", depName).getInt("moduleId")));	
				}				
			} else {
				medicationTemplateModuleMapList.put(new JSONObject().put("moduleId", jsonUtils.getJSONObjectFromJSONArray(modules, "moduleName", department).getInt("moduleId")));	
			}
			JSONObject compoundMedicationRequest = new JSONObject(compoundMedicationRequestObj.toString());
			compoundMedicationRequest.remove("medicationTemplateModuleMapList");
			compoundMedicationRequest.put("medicationTemplateModuleMapList", medicationTemplateModuleMapList);
			compoundMedicationRequestObj = (Object) compoundMedicationRequest;
		}

		if(speciality != null) {
			JSONArray medicationTemplateCasePackMapList = new JSONArray();
			JSONArray casePacks = this.getCaseDetails();
			if(speciality.contains(";")) {
				List<String> specialities = Arrays.asList(speciality.split("[;]"));
				for(String specName: specialities) {
					medicationTemplateCasePackMapList.put(new JSONObject().put("casePackId", jsonUtils.getJSONObjectFromJSONArray(casePacks, "casePackName", specName).getInt("casePackId")));	
				} 				
			} else {
				medicationTemplateCasePackMapList.put(new JSONObject().put("casePackId", jsonUtils.getJSONObjectFromJSONArray(casePacks, "casePackName", speciality).getInt("casePackId")));
			}
			JSONObject compoundMedicationRequest = new JSONObject(compoundMedicationRequestObj.toString());
			compoundMedicationRequest.remove("medicationTemplateCasePackMapList");
			compoundMedicationRequest.put("medicationTemplateCasePackMapList", medicationTemplateCasePackMapList);
			compoundMedicationRequestObj = (Object) compoundMedicationRequest;
		}		
		return compoundMedicationRequestObj;
	}

	protected Object getCompoundMedicationObject(org.json.JSONObject titratedDrug, org.json.JSONObject dispensableDrugObject, String Medication, String TemplateName, String TotalUnits,
			String BolusUnit, String BolusDose, String DispensableDrug, String RouteDesc, String isTitratedMedication) throws Exception{		
		Object compoundMedicationRequestObj = jsonUtils.getJsonFileAsObject("reqTemplates/insertCompoundMedication.json");
		compoundMedicationRequestObj = jsonUtils.updateOneJsonElement(compoundMedicationRequestObj.toString(), "compoundTf", true);
		compoundMedicationRequestObj = jsonUtils.updateOneJsonElement(compoundMedicationRequestObj.toString(), "titratedTf", false);
		if(titratedDrug.getString("defaultETCID") == null) {

		}
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.drugNameID", titratedDrug.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.drugNameDesc", titratedDrug.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.nameTypeCode", titratedDrug.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.nameTypeCodeDesc", titratedDrug.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.statusCode", titratedDrug.getInt("statusCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.statusCodeDesc", titratedDrug.getString("statusCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.defaultETCID", titratedDrug.getString("defaultETCID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "$.medicationTemplateItemList[*].selectedDispensableDrug.defaultETCDesc", titratedDrug.get("defaultETCDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", titratedDrug.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", titratedDrug.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCode", titratedDrug.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCodeDesc", titratedDrug.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCode", titratedDrug.getInt("statusCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCodeDesc", titratedDrug.getString("statusCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCID", titratedDrug.getInt("defaultETCID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "defaultETCID", titratedDrug.getInt("defaultETCID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCDesc", titratedDrug.getString("defaultETCDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "defaultETCDesc", titratedDrug.getString("defaultETCDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].defaultETCID", titratedDrug.getString("defaultETCID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].dispensableDrugId", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "dispensableDrugId", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.dispensableDrugID", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableDrugID", dispensableDrugObject.getInt("dispensableDrugID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.dispensableGenericID", dispensableDrugObject.getInt("dispensableGenericID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericID", dispensableDrugObject.getInt("dispensableGenericID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.dispensableGenericDesc", dispensableDrugObject.getString("dispensableGenericDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericDesc", dispensableDrugObject.getString("dispensableGenericDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.drugNameID", dispensableDrugObject.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", dispensableDrugObject.getInt("drugNameID"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.drugNameDesc", dispensableDrugObject.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", dispensableDrugObject.getString("drugNameDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.nameTypeCode", dispensableDrugObject.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCode", dispensableDrugObject.getInt("nameTypeCode"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.nameTypeCodeDesc", dispensableDrugObject.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCodeDesc", dispensableDrugObject.getString("nameTypeCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "medicationTemplateItemList[*].selectedDispensableDrug.statusCodeDesc", dispensableDrugObject.getString("statusCodeDesc"));
		compoundMedicationRequestObj = jsonUtils.updateObjectJsonXpath(compoundMedicationRequestObj.toString(), "selectedDispensableDrug.statusCodeDesc", dispensableDrugObject.getString("statusCodeDesc"));
		return compoundMedicationRequestObj;
	}

	protected Object getTitratedMedicationObject(JSONObject titratedDrug, JSONObject dispensableDrugObject, String Medication, String TemplateName, String TotalUnits,
			String BolusUnit, String BolusDose, String DispensableDrug, String RouteDesc, String isTitratedMedication) throws Exception{

		Object titratedMedicationRequestObj = jsonUtils.getJsonFileAsObject("reqTemplates/insertTitratedMedication.json");
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "compoundTf", false);
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "titratedTf", true);
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", titratedDrug.getInt("drugNameID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", titratedDrug.getString("drugNameDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCode", titratedDrug.getInt("nameTypeCode"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.nameTypeCodeDesc", titratedDrug.getString("nameTypeCodeDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.statusCode", titratedDrug.getInt("statusCode"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.statusCodeDesc", titratedDrug.getString("statusCodeDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCID",  titratedDrug.getString("defaultETCID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "defaultETCID",  titratedDrug.getString("defaultETCID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "defaultETCDesc",  titratedDrug.getString("defaultETCDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.defaultETCDesc",  titratedDrug.getString("defaultETCDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "templateName",  TemplateName);
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableDrugID",  dispensableDrugObject.getInt("dispensableDrugID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "dispensableDrugId",  dispensableDrugObject.getInt("dispensableDrugID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableDrugDesc", dispensableDrugObject.getString("dispensableDrugDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericID", dispensableDrugObject.getInt("dispensableGenericID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.dispensableGenericDesc", dispensableDrugObject.getString("dispensableGenericDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.routeID", dispensableDrugObject.getInt("routeID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.medStrength",  dispensableDrugObject.getString("medStrength"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.medStrengthUnit",  dispensableDrugObject.getString("medStrengthUnit"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.routeDesc",  dispensableDrugObject.getString("routeDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.doseFormID", dispensableDrugObject.getInt("doseFormID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.doseFormDesc", dispensableDrugObject.getString("doseFormDesc"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameID", dispensableDrugObject.getInt("drugNameID"));
		titratedMedicationRequestObj = jsonUtils.updateOneJsonElement(titratedMedicationRequestObj.toString(), "selectedDispensableDrug.drugNameDesc", dispensableDrugObject.getString("drugNameDesc"));
		return titratedMedicationRequestObj;
	}

	protected void createMedicationTemplate(String Medication, String fullMedication, String searchString, String department, String speciality, String templateName,
			String totalUnits, String bolusUnit, String bolusDose, String dispensableDrug, String routeDesc, String isTitratedMedication) throws Exception{


		LOG.info("Creating medication template ");
		LOG.info(Medication+" "+ fullMedication+" "+ department+" "+
				speciality+" "+ templateName+" "+ totalUnits+" "+ bolusUnit+" "+ bolusDose+" "+ dispensableDrug);

		JSONArray getTitratedDrugs = getTitratedDrugs(searchString);
		JSONObject titratedDrug = jsonUtils.getJSONObjectFromJSONArray(getTitratedDrugs, "drugNameDesc", Medication);

		JSONArray dispensableDrugs = null;
		JSONObject dispensableDrugObject = null;

		//getMedicationDrugs("test", Medication);

		dispensableDrugs = getDispensableDrugNames(String.valueOf(titratedDrug.getInt("drugNameID")));
		dispensableDrugObject = jsonUtils.getJSONObjectFromJSONArray(dispensableDrugs, "dispensableDrugDesc", fullMedication);


		if(isTitratedMedication.equalsIgnoreCase("false")) {
			Object compoundMedicationRequestObj = getCompoundMedicationObject(titratedDrug, dispensableDrugObject, Medication, templateName, totalUnits, bolusUnit, bolusDose, dispensableDrug, routeDesc, isTitratedMedication);
			insertMedicationTemplate(compoundMedicationRequestObj.toString());
		}

		if(isTitratedMedication.equalsIgnoreCase("true")) {
			Object titratedMedicationRequestObj = getTitratedMedicationObject(titratedDrug, dispensableDrugObject, Medication, templateName, totalUnits, bolusUnit, bolusDose, dispensableDrug, routeDesc, isTitratedMedication);
			insertMedicationTemplate(titratedMedicationRequestObj.toString());
		}

		if(isTitratedMedication.equalsIgnoreCase("NA")) {
			Object medicationRequestObj = getMedicationObject(titratedDrug, dispensableDrugObject, department, speciality, Medication, templateName, totalUnits, bolusUnit, bolusDose, dispensableDrug, routeDesc, isTitratedMedication);			
			insertMedicationTemplate(medicationRequestObj.toString());
		}
	}

	protected boolean getDictionaryDetails(String dictionaryName) throws Exception {
		String relURL = "Dictionary/v2";
		Response dictionaryResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (dictionaryResponse.getStatusCode() >= 200 && dictionaryResponse.getStatusCode() < 300) {
			org.json.JSONArray dictionaryArry = new org.json.JSONArray(dictionaryResponse.asString());
			for (int index = 0; index < dictionaryArry.length(); index++) {
				JSONObject dictionary = dictionaryArry.getJSONObject(index);
				if (dictionary.getString("name").equalsIgnoreCase(dictionaryName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.dictionaryName, dictionary.get("name"));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.dictionaryId, dictionary.get("id"));
					break;
				}
			}
			return true;
		}else {
			return false;
		}
	}

	protected void getDictionaryDetails(String dictionaryName, String dictionaryValue) throws Exception {
		boolean flag = getDictionaryDetails(dictionaryName);
		if(flag) {
			String dictionaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.dictionaryId).toString();
			String relURL = "Dictionary/v2/"+dictionaryId+"/All";
			Response dictionaryItemResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);

			if (dictionaryItemResponse.getStatusCode() >= 200 && dictionaryItemResponse.getStatusCode() < 300) {
				org.json.JSONArray array = new org.json.JSONArray(dictionaryItemResponse.asString());
				for (int i = 0; i < array.length(); i++) {
					JSONObject dictionaryItem = array.getJSONObject(i);
					if (dictionaryItem.getString("value").equalsIgnoreCase(dictionaryValue)) {
						this.mapWebServiceResponses.put(IWebServiceResponseKeys.dictionaryItemId, dictionaryItem.get("id"));
						break;
					}
				}
			}
		}
	}

	protected void getCaseDetails(String name) throws Exception {
		String relURL = "CasePack/GetCasePacks";
		Response caseDetailsResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (caseDetailsResp.getStatusCode() >= 200 && caseDetailsResp.getStatusCode() < 300) {
			org.json.JSONArray caseDetailArry = new org.json.JSONArray(caseDetailsResp.asString());
			for (int index = 0; index < caseDetailArry.length(); index++) {
				JSONObject caseDtl = caseDetailArry.getJSONObject(index);
				if (caseDtl.getString("casePackName").equalsIgnoreCase(name)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.casePackId, caseDtl.get("casePackId"));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.casePackName, caseDtl.getString("casePackName"));
					break;
				}
			}
		}
	}

	protected JSONArray getCaseDetails() throws Exception {
		String relURL = "CasePack/GetCasePacks";
		Response caseDetailsResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (caseDetailsResp.getStatusCode() >= 200 && caseDetailsResp.getStatusCode() < 300) {
			org.json.JSONArray caseDetailArry = new org.json.JSONArray(caseDetailsResp.asString());
			return caseDetailArry;
		}
		return null;
	}

	protected boolean getPhysicianOrderDetails(String name) throws Exception {
		String relURL = "PhysicianOrdersConfiguration/names";
		Response physicianOrderResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (physicianOrderResp.getStatusCode() >= 200 && physicianOrderResp.getStatusCode() < 300) {
			org.json.JSONArray physicianOrderDetailsArry = new org.json.JSONArray(physicianOrderResp.asString());
			for (int index = 0; index < physicianOrderDetailsArry.length(); index++) {
				JSONObject physicianOrder = physicianOrderDetailsArry.getJSONObject(index);
				if (physicianOrder.getString("name").equalsIgnoreCase(name)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.physicianOrderId, physicianOrder.get("physicianOrderId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getPhysicianOpNotesDetails(String name) throws Exception {
		String relURL = "/OpNoteConfiguration/Names";
		Response physicianOpNotesResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (physicianOpNotesResp.getStatusCode() >= 200 && physicianOpNotesResp.getStatusCode() < 300) {
			org.json.JSONArray physicianOpNotesDetailsArry = new org.json.JSONArray(physicianOpNotesResp.asString());
			for (int index = 0; index < physicianOpNotesDetailsArry.length(); index++) {
				JSONObject physicianOpNotes = physicianOpNotesDetailsArry.getJSONObject(index);
				if (physicianOpNotes.getString("opNoteName").equalsIgnoreCase(name)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.physicianOpNotesId, physicianOpNotes.get("opNoteId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getConsentDetails(String name) throws Exception {
		String relURL = "ConsentConfiguration/names";
		Response consentResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		name = ReusableUtils.encodeString2Base64(name);
		if (consentResp.getStatusCode() >= 200 && consentResp.getStatusCode() < 300) {
			org.json.JSONArray consentDetailsArry = new org.json.JSONArray(consentResp.asString());
			for (int index = 0; index < consentDetailsArry.length(); index++) {
				JSONObject consent = consentDetailsArry.getJSONObject(index);
				if (consent.getString("name").equalsIgnoreCase(name)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.consentsId, consent.get("consentId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getDischargeInstrDetails(String configurationName) throws Exception {
		String relURL = "DischargeInstructionConfiguration/Names";
		Response dischargeInstrResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		configurationName = ReusableUtils.encodeString2Base64(configurationName);
		if (dischargeInstrResp.getStatusCode() >= 200 && dischargeInstrResp.getStatusCode() < 300) {
			org.json.JSONArray dischargeInstrDetailsArry = new org.json.JSONArray(dischargeInstrResp.asString());
			for (int index = 0; index < dischargeInstrDetailsArry.length(); index++) {
				JSONObject dischargeInstr = dischargeInstrDetailsArry.getJSONObject(index);
				if (dischargeInstr.getString("configurationName").equalsIgnoreCase(configurationName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.dischargeInstrConfigurationId, dischargeInstr.get("configurationId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getWorklistDetails(int workListArea, String worklistName) throws Exception {
		String relURL = "WorklistConfiguration/GetWorklistTemplates?worklistArea="+workListArea;
		Response workListResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		worklistName = ReusableUtils.encodeString2Base64(worklistName);
		if (workListResp.getStatusCode() >= 200 && workListResp.getStatusCode() < 300) {
			org.json.JSONArray workListDetailsArry = new org.json.JSONArray(workListResp.asString());
			for (int index = 0; index < workListDetailsArry.length(); index++) {
				JSONObject workList = workListDetailsArry.getJSONObject(index);
				if (workList.getString("name").equalsIgnoreCase(worklistName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.worklistId, workList.get("worklistId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getDiscountDetails(String discountName) throws Exception {
		String relURL = "/SourceOfRevenue/GetSourceOfRevenueList";
		Response discountsResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (discountsResp.getStatusCode() >= 200 && discountsResp.getStatusCode() < 300) {
			org.json.JSONArray discountsArry = new org.json.JSONArray(discountsResp.asString());
			for (int index = 0; index < discountsArry.length(); index++) {
				JSONObject discount = discountsArry.getJSONObject(index);
				if (discount.getString("sourceOfRevenueName").equalsIgnoreCase(discountName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.discountId, discount.get("sourceOfRevenueId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean updateWorklistToPrefeCard(int prefCardId, int workListArea, String worklistNames) throws Exception {
		String relURL = "PreferenceCardConfig/UpsertPreferenceConfigWorklistMap";
		JSONObject WorklistObj = new JSONObject();
		getWorklistDetails(workListArea, worklistNames);
		String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.worklistId).toString();
		WorklistObj.put("worklistArea", workListArea);
		WorklistObj.put("worklistId", Integer.parseInt(id));
		WorklistObj.put("preferenceCardId", prefCardId);
		Response response = runWebServiceRequest("application/json", WorklistObj.toString(), relURL, Method.PUT);
		if (response.getStatusCode() >= 200 && response.getStatusCode() < 300) {
			return true;
		}else {
			return false;
		}
	}

	protected Response addNewOrder(String orderName)  throws Exception{
		String relURL = "/PhysicianOrdersConfiguration";
		String PhysicianOrdersId=  null;
		// API to create Physician Order
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", orderName);
		Response PhysicianOrdersConfigurationresp = runWebServiceRequest("application/json", jsonObject.toString(), relURL, Method.POST);
		if (PhysicianOrdersConfigurationresp.getStatusCode() == 200) {
			PhysicianOrdersId = jsonUtils.getObjectFromJsonXpath(PhysicianOrdersConfigurationresp.asString(), "physicianOrderId").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.physicianOrderId,PhysicianOrdersId);
		}
		return PhysicianOrdersConfigurationresp;
	}

	protected Response UpdatePhysicians(String physicianname)  throws Exception{
		String PhysicianOrdersId=  this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOrderId).toString();
		String staffidstr = getPhysicianOrdersConfiguration();
		String relURL = "PhysicianOrdersConfiguration/PhysicianOrder/"+PhysicianOrdersId+"/UpdatePhysicians";
		// API to Update Physician in created Physician order
		if(physicianname!=null && !physicianname.isEmpty()) {
			for (int k = 0; k < physicianname.split("[,]").length; k++) {
				List<Object> Physiciandetails = getPhysicianNameIDFromPhysicianName(physicianname.split("[,]")[k]);
				if (staffidstr == null) {
					staffidstr = ((Physiciandetails.get(1)).toString());
				}else {
					staffidstr = staffidstr+","+(Physiciandetails.get(1)).toString();
				}
			}
		}
		return runWebServiceRequest("application/json", "["+staffidstr+"]", relURL, Method.PUT);
	}

	protected String getPhysicianOrdersConfiguration() throws Exception {
		String PhysicianOrdersId=  this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOrderId).toString();
		String staffidstr = null;
		String relURL = "PhysicianOrdersConfiguration/"+PhysicianOrdersId;
		// API to getCaseDetailInformation
		Response caseDetailInfoResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (caseDetailInfoResp.getStatusCode() == 200) {
			JSONArray PhysicianOrdersConfigurationary = jsonUtils.returnJsonArrayFromString(jsonUtils.getObjectFromJsonXpath(caseDetailInfoResp.asString(), "orderPhysicians").toString());
			for (int i = 0; i < PhysicianOrdersConfigurationary.length(); i++)	{	
				String staffIdObject = jsonUtils.getValueFromJsonObject(PhysicianOrdersConfigurationary.get(i).toString(), "staffId");
				if (staffidstr!=null) { 
					staffidstr = staffidstr+","+staffIdObject;
				}else {
					staffidstr = staffIdObject;
				}
			}
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseDetailInfoResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					caseDetailInfoResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return staffidstr;
	}

	protected Response UpdateBaseOrder(String department, String ordertext)  throws Exception{
		String relURL = "PhysicianOrdersConfiguration/BaseOrder";
		int departmentid = 0;

		if(department.equalsIgnoreCase("Recovery")){
			departmentid = 1060;
		} else if (department.contentEquals("Pre-Operative")) {
			departmentid = 1020;
		} else if (department.contentEquals("Operative")) {
			departmentid = 1030;
		}				

		// API to UpdateBaseOrder
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/BaseOrder.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "departmentId", departmentid);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "textOrder.text", ordertext);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "physicianOrderId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOrderId));

		return runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
	}

	protected Response OpNoteConfigurationAdd(String OpNoteName) throws Exception {
		String relURL = "/OpNoteConfiguration/Add";
		int opNoteId=  0;
		// API to create Physician Order
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("opNoteName", OpNoteName);
		Response OpNoteConfigurationAddresonse = runWebServiceRequest("application/json", jsonObject.toString(), relURL, Method.POST);
		if (OpNoteConfigurationAddresonse.getStatusCode() == 200) {
			opNoteId = Integer.parseInt(OpNoteConfigurationAddresonse.asString());
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.opNoteId,opNoteId);
		}
		return OpNoteConfigurationAddresonse;
	}

	protected Response updateOpNoteConfiguration(String OpNoteName, String physicianname, String Opnotetext)  throws Exception{
		String relURL = "/OpNoteConfiguration/Update";
		int opNoteId =  Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.opNoteId).toString());
		// API to update OpNoteConfiguration
		Object tempobj = null;
		tempobj = jsonUtils.getJsonFileAsObject("reqTemplates/UpdateOpNoteConfiguration.json");
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "opNoteId", opNoteId);
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "textObject.opNoteId", opNoteId);
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "variableObject.opNoteId", opNoteId);
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "opNoteName", OpNoteName);
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "organizationId",  Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
		tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(), "textObject.noteText", ReusableUtils.encodeString2Base64(Opnotetext));


		for (int i = 0; i < physicianname.split("[,]").length; i++) {
			List<Object> Physiciandetails = getPhysicianNameIDFromPhysicianName(physicianname.split("[,]")[i]);
			org.json.JSONArray arrayObj = null;
			if (i > 0) {
				String obj = jsonUtils.getObjectFromJsonXpath(tempobj.toString(), "physicianMappings").toString();
				arrayObj = jsonUtils.returnJsonArrayFromString(obj);
				JSONObject jsonobj = new JSONObject();
				jsonobj.put("staffId", Physiciandetails.get(1).toString());
				arrayObj = arrayObj.put(jsonobj);
				tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(),"physicianMappings",Configuration.defaultConfiguration().jsonProvider().parse(arrayObj.toString()));
			} else {
				tempobj = jsonUtils.updateObjectJsonXpath(tempobj.toString(),"physicianMappings[0].staffId", Physiciandetails.get(1).toString());
			}
		}
		LOG.info(String.format("updateOpNoteConfiguration %s",tempobj.toString()));
		Response updateOpNoteConfigurationresonse = runWebServiceRequest("application/json", tempobj.toString(), relURL, Method.POST);
		return updateOpNoteConfigurationresonse;
	}

	protected Response SaveSourceOfRevenue(String discountName)  throws Exception{
		String relURL = "SourceOfRevenue/SaveSourceOfRevenue";
		// API to SaveSourceOfRevenue
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("sourceOfRevenueName", discountName);

		Response SaveSourceOfRevenueAddresonse = runWebServiceRequest("application/json", jsonObject.toString(), relURL, Method.PUT);
		return SaveSourceOfRevenueAddresonse;
	}

	protected Response createSaveSourceOfRevenue(String discountName, String writeOffGroupCode, String WriteOffReasonCode, String transactionCodeName, String discountpercent) throws Exception {
		String relURL = "SourceOfRevenue/SaveSourceOfRevenue";
		boolean isDiscountPresent = false;
		isDiscountPresent = getDiscountDetails(discountName);
		Response SaveSourceOfRevenueAddresonseupdated = null;
		if(!(isDiscountPresent)) {
			String SaveSourceOfRevenueResponse = SaveSourceOfRevenue(discountName).asString();
			Object createDiscount = jsonUtils.getObjectFromJsonXpath(SaveSourceOfRevenueResponse, "$");
			if(writeOffGroupCode != null &&  !writeOffGroupCode.isEmpty() && !writeOffGroupCode.equalsIgnoreCase("BLANK")){	// if 	writeOffGroupCode is not requried 		
				List<Object> getWriteOffGroupdetails = getWriteOffGroupList(writeOffGroupCode);
				createDiscount = jsonUtils.updateObjectJsonXpath(createDiscount.toString(), "writeoffGroupId", Integer.parseInt(getWriteOffGroupdetails.get(0).toString()));
			}
			if(WriteOffReasonCode != null &&  !WriteOffReasonCode.isEmpty() && !WriteOffReasonCode.equalsIgnoreCase("BLANK")){	// if 	WriteOffReasonCode is not requried 
				List<Object> getWriteOffReasondetails = getWriteOffReasonList(WriteOffReasonCode);
				createDiscount = jsonUtils.updateObjectJsonXpath(createDiscount.toString(), "writeoffReasonId", Integer.parseInt(getWriteOffReasondetails.get(0).toString()));
			}
			if(transactionCodeName != null &&  !transactionCodeName.isEmpty() && !transactionCodeName.equalsIgnoreCase("BLANK")){	// if 	transactionCodeName is not requried 
				List<Object> getTransactionCodeListByType = getTransactionCodeListByType(transactionCodeName);
				createDiscount = jsonUtils.updateObjectJsonXpath(createDiscount.toString(), "transactionCodeId", Integer.parseInt(getTransactionCodeListByType.get(0).toString()));	
			}
			createDiscount = jsonUtils.updateObjectJsonXpath(createDiscount.toString(), "discountPercent", Float.parseFloat(discountpercent));			
			SaveSourceOfRevenueAddresonseupdated = runWebServiceRequest("application/json", createDiscount.toString(), relURL, Method.PUT);
		}
		return SaveSourceOfRevenueAddresonseupdated;
	}

	protected List<Object> getWriteOffGroupList(String writeOffGroupCode) {
		String relURL = "StaticList/GetWriteOffGroupList";
		String writeOffGroupId = null;
		String description = null;

		try {
			Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
			JSONArray getWriteOffGroupListary = jsonUtils.returnJsonArrayFromString(response.asString());
			LOG.info(String.format("getWriteOffGroupListary - %s", getWriteOffGroupListary));
			JSONObject getWriteOffGroupjson1 = jsonUtils.getJSONObjectFromJSONArray(getWriteOffGroupListary, "writeOffGroupCode", writeOffGroupCode);
			writeOffGroupId = jsonUtils.getValueFromJsonObject(getWriteOffGroupjson1.toString(), "writeOffGroupId");
			description = jsonUtils.getValueFromJsonObject(getWriteOffGroupjson1.toString(), "description");
		} catch (Exception e) {
			LOG.error(e);
		}
		return Arrays.asList(writeOffGroupId,description);
	}

	protected List<Object> getWriteOffReasonList(String WriteOffReasonCode) {
		String relURL = "StaticList/GetWriteOffReasonList";
		String writeOffReasonId = null;
		String description = null;

		try {
			Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
			JSONArray getWriteOffReasonListary = jsonUtils.returnJsonArrayFromString(response.asString());
			LOG.info(String.format("getWriteOffReasonListary - %s", getWriteOffReasonListary));
			JSONObject getWriteOffReasonjson1 = jsonUtils.getJSONObjectFromJSONArray(getWriteOffReasonListary, "writeOffReasonCode", WriteOffReasonCode);
			writeOffReasonId = jsonUtils.getValueFromJsonObject(getWriteOffReasonjson1.toString(), "writeOffReasonId");
			description = jsonUtils.getValueFromJsonObject(getWriteOffReasonjson1.toString(), "description");
		} catch (Exception e) {
			LOG.error(e);
		}
		return Arrays.asList(writeOffReasonId,description);
	}

	protected List<Object> getTransactionCodeListByType(String transactionCodeName) throws Exception{
		String relURL = "TransactionCode/GetTransactionCodeListByType/4";
		String transactionCodeId = null;

		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray getTransactionCodeListary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("getTransactionCodeListary - %s", getTransactionCodeListary));
		JSONObject getTransactionCodejson1 = jsonUtils.getJSONObjectFromJSONArray(getTransactionCodeListary, "transactionCodeName", transactionCodeName);
		transactionCodeId = jsonUtils.getValueFromJsonObject(getTransactionCodejson1.toString(), "transactionCodeId");
		return Arrays.asList(transactionCodeId);
	}

	protected void createDictionary(String Dictionaryname, String DictionaryitemName, boolean value) throws Exception{
		Response response = null;
		boolean isPresent = getDictionaryDetails(Dictionaryname);
		String dictionaryid = this.mapWebServiceResponses.get(IWebServiceResponseKeys.dictionaryId).toString();
		String relURL = "Dictionary/v2/"+dictionaryid+"/Add";
		// API to createDictionary
		if(!(isPresent)) {
			Object obj = null;
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/DictionaryAdd.json");
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "dictionary", Dictionaryname);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "dictionaryId", dictionaryid);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "value", DictionaryitemName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "showInClinicalTf", value);
			response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
			if (response.getStatusCode() == 200) {
				LOG.info(String.format("Dictionary Item creation is successfull with DictionaryitemName-> %s under dictionarytype ->%s", DictionaryitemName, Dictionaryname));
			}
		} else {
			LOG.info(String.format("Dictionary Item is already present with DictionaryitemName-> %s under dictionarytype ->%s", DictionaryitemName, Dictionaryname));
		}
	}

	protected boolean getImplantDetails(String implantName) throws Exception {
		String relURL = "Inventory/Search?searchText="+implantName+"&category=Implant";
		Response implantResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (implantResp.getStatusCode() >= 200 && implantResp.getStatusCode() < 300) {
			org.json.JSONArray implantDetailsArry = new org.json.JSONArray(implantResp.asString());
			for (int index = 0; index < implantDetailsArry.length(); index++) {
				JSONObject implant = implantDetailsArry.getJSONObject(index);
				if (implant.getString("name").equalsIgnoreCase(implantName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.implantId, implant.get("itemNumber"));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.ImplantExternalIdentifier,implant.get("externalItemId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getManufacturersDetails(String Manufacturer) throws Exception {
		String relURL = "Inventory/Manufacturers?searchText="+Manufacturer;
		Response manufacturerResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (manufacturerResp.getStatusCode() >= 200 && manufacturerResp.getStatusCode() < 300) {
			org.json.JSONArray manufacturerArry = new org.json.JSONArray(manufacturerResp.asString());
			for (int index = 0; index < manufacturerArry.length(); index++) {
				JSONObject implant = manufacturerArry.getJSONObject(index);
				if (implant.getString("name").equalsIgnoreCase(Manufacturer)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.ManufacturerExternalIdentifier, implant.get("externalItemId"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getSupplyDetails(String supplyName) throws Exception {
		String relURL = "Inventory/Search?searchText="+supplyName+"&category=Supply/Instrument";
		Response supplyResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (supplyResp.getStatusCode() >= 200 && supplyResp.getStatusCode() < 300) {
			org.json.JSONArray supplyDetailsArry = new org.json.JSONArray(supplyResp.asString());
			for (int index = 0; index < supplyDetailsArry.length(); index++) {
				JSONObject supply = supplyDetailsArry.getJSONObject(index);
				if (supply.getString("name").equalsIgnoreCase(supplyName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.supplyId, supply.get("itemNumber"));
					return true;
				}
			}
		}
		return false;
	}

	protected boolean getEquipmentDetails(String equipmentName) throws Exception {
		String relURL = "Inventory/Search?searchText="+equipmentName+"&category=Equipment";
		Response equipmentResp = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (equipmentResp.getStatusCode() >= 200 && equipmentResp.getStatusCode() < 300) {
			org.json.JSONArray equipmentDetailsArry = new org.json.JSONArray(equipmentResp.asString());
			for (int index = 0; index < equipmentDetailsArry.length(); index++) {
				JSONObject equipment = equipmentDetailsArry.getJSONObject(index);
				if (equipment.getString("name").equalsIgnoreCase(equipmentName)) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.equipmentId, equipment.get("itemNumber"));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.equipmentExternalItemId, equipment.get("externalItemId"));
					return true;
				}
			}
		}
		return false;
	}

	protected void mapEquipmentToPreferenceCard(int prefCardId, String equipmentName, String serialNumber, String notes) throws Exception{

		if(equipmentName!=null && !equipmentName.isEmpty()) {
			String relURL = "PreferenceCardConfig/Equipment";
			JSONArray equipmentArry = new JSONArray();
			Object equipmentObj = jsonUtils.getJsonFileAsObject("reqTemplates/EquipmentToPrefCard.json");

			for (int i = 0; i < equipmentName.split("[,]").length; i++) {
				Object obj = jsonUtils.getObjectFromJsonXpath(equipmentObj.toString(), "$.[0]");

				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "preferenceCardId", prefCardId);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "equipmentName", ReusableUtils.encodeString2Base64(equipmentName.split("[,]")[i]));
				getEquipmentDetails(equipmentName.split("[,]")[i]);
				String inventoryNumber = this.mapWebServiceResponses.get(IWebServiceResponseKeys.equipmentId).toString();
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "inventoryNumber", ReusableUtils.encodeString2Base64(inventoryNumber));
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "serialNumber", serialNumber, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "notes", notes, "[,]", i);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "sortOrder", i);

				equipmentArry.put(Configuration.defaultConfiguration().jsonProvider()
						.parse(obj.toString()));
			}
			runWebServiceRequest("application/json", equipmentArry.toString(), relURL, Method.POST);
		}
	}

	protected void mapSuppliesToPreferenceCard(int prefCardId, String supplyName, String prOpen, String prHold, String orOpen, String orHold,
			String p1Open, String p1Hold, String p2Open, String p2Hold, String p3Open, String p3Hold, String notes) throws Exception{

		if(supplyName!=null && !supplyName.isEmpty()) {
			String relURL = "PreferenceCardConfig/Supplies";
			JSONArray supplyArry = new JSONArray();
			Object supplyObj = jsonUtils.getJsonFileAsObject("reqTemplates/SupplyToPrefCard.json");

			boolean recoveryflag = false;
			if((p3Hold.split("[|]")[0].equalsIgnoreCase("Recovery")&& (p3Open.split("[|]")[0].equalsIgnoreCase("Recovery"))))
			{
				recoveryflag = true;
				p3Hold = p3Hold.split("[|]")[1];
				p3Open = p3Open.split("[|]")[1];
			}

			for (int i = 0; i < supplyName.split("[,]").length; i++) {
				Object obj = jsonUtils.getObjectFromJsonXpath(supplyObj.toString(), "$.[0]");

				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "preferenceCardId", prefCardId);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "supplyName", ReusableUtils.encodeString2Base64(supplyName.split("[,]")[i]));
				getSupplyDetails(supplyName.split("[,]")[i]);
				String inventoryNumber = this.mapWebServiceResponses.get(IWebServiceResponseKeys.supplyId).toString();
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "inventoryNumber", ReusableUtils.encodeString2Base64(inventoryNumber));
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "notes", notes, "[,]", i);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "sortOrder", i);

				//				Pre-Op Open
				obj = jsonUtils.updateDataWhenNotnull(obj, "pROpen", prOpen, "[,]", i);
				obj = jsonUtils.updateDataWhenNotnull(obj, "quantities[0].open", prOpen, "[,]", i);

				//				Pre-Op Hold
				obj = jsonUtils.updateDataWhenNotnull(obj, "pRHold", prHold, "[,]", i);
				obj = jsonUtils.updateDataWhenNotnull(obj, "quantities[0].hold", prHold, "[,]", i);

				//				OR Open
				obj = jsonUtils.updateDataWhenNotnull(obj, "oROpen", orOpen, "[,]", i);
				obj = jsonUtils.updateDataWhenNotnull(obj, "quantities[1].open", orOpen, "[,]", i);
				//				OR Hold
				obj = jsonUtils.updateDataWhenNotnull(obj, "oRHold", orHold, "[,]", i);
				obj = jsonUtils.updateDataWhenNotnull(obj, "quantities[1].hold", orHold, "[,]", i);

				if (recoveryflag) {
					obj = updateSuppliesopenholdvalues(obj, "rCOpen", p3Open, "rCHold", p3Hold, "1060", "[,]", i);
				}else {
					obj = updateSuppliesopenholdvalues(obj, "p1Open", p1Open, "p1Hold", p1Hold, "1040", "[,]", i);
					obj = updateSuppliesopenholdvalues(obj, "p2Open", p2Open, "p2Hold", p2Hold, "1050", "[,]", i);
					obj = updateSuppliesopenholdvalues(obj, "p3Open", p3Open, "p3Hold", p3Hold, "1070", "[,]", i);
				}
				supplyArry.put(Configuration.defaultConfiguration().jsonProvider()
						.parse(obj.toString()));

			}
			runWebServiceRequest("application/json", supplyArry.toString(), relURL, Method.PUT);
		}
	}

	protected void mapImplantToPreferenceCard(int prefCardId, String implantName, String manfacturerName, String size, String lotNum,
			String serialNum, String expiration, String referenceNum, String quantity, String notes) throws Exception{

		if(implantName!=null && !implantName.isEmpty()) {
			String relURL = "PreferenceCardConfig/ImplantProsthesis";

			for (int i = 0; i < implantName.split("[,]").length; i++) {
				getImplantDetails(implantName.split("[,]")[i]);
				Object obj = jsonUtils.getJsonFileAsObject("reqTemplates/ImplantToPrefCard.json");
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "preferenceCardId", prefCardId);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "implantName", ReusableUtils.encodeString2Base64(implantName.split("[,]")[i]));
				String inventoryNumber = this.mapWebServiceResponses.get(IWebServiceResponseKeys.implantId).toString();
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "inventoryNumber", ReusableUtils.encodeString2Base64(inventoryNumber));
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "manufacturerName", ReusableUtils.encodeString2Base64(manfacturerName.split("[,]")[i]));
				obj = jsonUtils.updateDataWhenNotnull(obj, "quantity", quantity, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "size", size, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "lotNum", lotNum, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "serialNum", serialNum, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "expiration", expiration, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "referenceNum", referenceNum, "[,]", i);
				obj = jsonUtils.updateEncodedDataWhenNotnull(obj, "notes", notes, "[,]", i);

				runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
			}
		}
	}

	protected void mapDocumentationToPreferenceCards(int prefCardId, String physicianOrder, String opNote, String consent, String dischargeInstruction) throws Exception{
		String relURL = null;
		//		Map physicianOrder to Preference Card
		if(physicianOrder!=null && !physicianOrder.isEmpty()) {
			relURL = "PreferenceCardConfig/InsertPreferenceConfigPhysOrderMaps";
			JSONArray arrayObj = new JSONArray();

			for (int i = 0; i < physicianOrder.split("[,]").length; i++) {
				JSONObject orderObj = new JSONObject();
				getPhysicianOrderDetails(physicianOrder.split("[,]")[i]);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOrderId).toString();
				orderObj.put("physicianOrderId", Integer.parseInt(id));
				orderObj.put("preferenceCardId", prefCardId);
				arrayObj.put(orderObj);
			}
			runWebServiceRequest("application/json", arrayObj.toString(), relURL, Method.POST);
		}
		//		Map opNote to Preference Card
		if(opNote!=null && !opNote.isEmpty()) {
			relURL = "PreferenceCardConfig/InsertPreferenceConfigOpnotesMaps";
			JSONArray arrayObj = new JSONArray();

			for (int i = 0; i < opNote.split("[,]").length; i++) {
				JSONObject opNoteObj = new JSONObject();
				getPhysicianOpNotesDetails(opNote.split("[,]")[i]);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOpNotesId).toString();
				opNoteObj.put("opnoteId", Integer.parseInt(id));
				opNoteObj.put("preferenceCardId", prefCardId);
				arrayObj.put(opNoteObj);
			}
			runWebServiceRequest("application/json", arrayObj.toString(), relURL, Method.POST);
		}
		//		Map consent to Preference Card
		if(consent!=null && !consent.isEmpty()) {
			relURL = "PreferenceCardConfig/InsertPreferenceConfigConsentsMaps";
			JSONArray arrayObj = new JSONArray();

			for (int i = 0; i < consent.split("[,]").length; i++) {
				JSONObject consentObj = new JSONObject();
				getConsentDetails(consent.split("[,]")[i]);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.consentsId).toString();
				consentObj.put("consentConfigurationId", Integer.parseInt(id));
				consentObj.put("preferenceCardId", prefCardId);
				arrayObj.put(consentObj);
			}
			runWebServiceRequest("application/json", arrayObj.toString(), relURL, Method.POST);
		}
		//		Map dischargeInstruction to Preference Card
		if(dischargeInstruction!=null && !dischargeInstruction.isEmpty()) {
			relURL = "PreferenceCardConfig/InsertPreferenceConfigDiscConfigMaps";
			JSONArray arrayObj = new JSONArray();

			for (int i = 0; i < dischargeInstruction.split("[,]").length; i++) {
				JSONObject dischargeInstrObj = new JSONObject();
				getDischargeInstrDetails(dischargeInstruction.split("[,]")[i]);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.dischargeInstrConfigurationId).toString();
				dischargeInstrObj.put("dischargeConfigurationId", Integer.parseInt(id));
				dischargeInstrObj.put("preferenceCardId", prefCardId);
				arrayObj.put(dischargeInstrObj);
			}
			runWebServiceRequest("application/json", arrayObj.toString(), relURL, Method.POST);
		}
	}

	protected void mapWorklistsToPreferenceCards(int prefCardId, String preAdmissionQxWorklist, String preAdmissionInstructionsWorklist, String preOperativeWorklist, String operativeWorklist, 
			String phase1Worklist, String phase2Worklist, String phase3Worklist, String recoveryWorklist, String postoperativeQXWorklist) throws Exception{
		//		Map preAdmissionQxWorklist to Preference Card
		int workListArea = 1;
		if(preAdmissionQxWorklist!=null && !preAdmissionQxWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, preAdmissionQxWorklist);
		}

		//		Map preAdmissionInstructionsWorklist to Preference Card
		workListArea = 2;
		if(preAdmissionInstructionsWorklist!=null && !preAdmissionInstructionsWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, preAdmissionInstructionsWorklist);
		}

		//		Map preOperativeWorklist to Preference Card
		workListArea = 3;
		if(preOperativeWorklist!=null && !preOperativeWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, preOperativeWorklist);
		}

		//		Map operativeWorklist to Preference Card
		workListArea = 4;
		if(operativeWorklist!=null && !operativeWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, operativeWorklist);
		}

		//		Map phase1Worklist to Preference Card
		workListArea = 5;
		if(phase1Worklist!=null && !phase1Worklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, phase1Worklist);
		}

		//		Map phase2Worklist to Preference Card
		workListArea = 6;
		if(phase2Worklist!=null && !phase2Worklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, phase2Worklist);
		}

		//		Map recoveryWorklist to Preference Card
		workListArea = 7;
		if(recoveryWorklist!=null && !recoveryWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, recoveryWorklist);
		}

		//		Map phase3Worklist to Preference Card
		workListArea = 8;
		if(phase3Worklist!=null && !phase3Worklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, phase3Worklist);
		}

		//		Map postoperativeQXWorklist to Preference Card
		workListArea = 9;
		if(postoperativeQXWorklist!=null && !postoperativeQXWorklist.isEmpty()) {
			updateWorklistToPrefeCard(prefCardId, workListArea, postoperativeQXWorklist);
		}
	}

	protected int addPreferenceCard(String preferenceCardName, String caseSpecialtiy, String appointmentTypeValue, String physician, String anesthesiaTypeValue,
			String physicianOrder, String opNote, String consent, String dischargeInstruction,
			String preAdmissionQxWorklist, String preAdmissionInstructionsWorklist, String preOperativeWorklist, String operativeWorklist, 
			String phase1Worklist, String phase2Worklist, String phase3Worklist, String recoveryWorklist, String postoperativeQXWorklist, String implantName, String manfacturerName, 
			String size, String lotNum, String serialNum, String expiration, String referenceNum, String quantity, String implantNotes,
			String supplyName, String prOpen, String prHold, String orOpen, String orHold,
			String p1Open, String p1Hold, String p2Open, String p2Hold, String p3Open, String p3Hold, String supplyNotes,
			String equipmentName, String serialNumber, String equipmentNotes, String cptCodes) throws Exception{
		String relURL = "PreferenceCardConfig/UpsertPreferenceCardConfig";
		// API to add preference cards
		int prefCardId = 0;
		JSONObject prefCardObject = new JSONObject();
		prefCardObject.put("preferenceCardName", preferenceCardName);
		boolean isPreferenceCardExists = false;
		isPreferenceCardExists = isPreferenceCardPresent(preferenceCardName);
		if(!(isPreferenceCardExists)) {
			Response prefCardResp = runWebServiceRequest("application/json", prefCardObject.toString(), relURL, Method.PUT);
			prefCardId = 0;
			if (prefCardResp.getStatusCode() >= 200 && prefCardResp.getStatusCode() < 300) {
				prefCardId = Integer.parseInt(jsonUtils.getObjectFromJsonXpath(prefCardResp.asString(), "preferenceCardId").toString());
			}

			Object obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddPreferenceCard.json");
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "preferenceCardId", prefCardId);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "preferenceCardName", preferenceCardName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
			if(physician!=null && !physician.isEmpty()) {
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "physicianId", Integer.parseInt(getPhysicianNameIDFromPhysicianName(physician).get(2).toString()));
			}
			if(caseSpecialtiy!=null && !caseSpecialtiy.isEmpty()) {
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSpecialtyName", caseSpecialtiy);
				getCaseDetails(caseSpecialtiy);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSpecialtyId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.casePackId).toString()));
			}

			if(anesthesiaTypeValue!=null && !anesthesiaTypeValue.isEmpty()) {
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "anesthesiaTypeName", anesthesiaTypeValue);
				getDictionaryDetails("Anesthesia Type", anesthesiaTypeValue);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.dictionaryItemId).toString();
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "anesthesiaTypeId", Integer.parseInt(id));
			}

			if(appointmentTypeValue!=null && !appointmentTypeValue.isEmpty()) {
				getDictionaryDetails("Appointment Type", appointmentTypeValue);
				String id = this.mapWebServiceResponses.get(IWebServiceResponseKeys.dictionaryItemId).toString();
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "appointmentTypeId", Integer.parseInt(id));
			}
			prefCardResp = runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);

			if (prefCardResp.getStatusCode() >= 200 && prefCardResp.getStatusCode() < 300) {
				prefCardId = Integer.parseInt(jsonUtils.getObjectFromJsonXpath(prefCardResp.asString(), "preferenceCardId").toString());
			}
			// Map Documentation to PreferenceCard
			mapDocumentationToPreferenceCards(prefCardId, physicianOrder, opNote, consent, dischargeInstruction);

			// map Worklists To PreferenceCard
			mapWorklistsToPreferenceCards(prefCardId, preAdmissionQxWorklist, preAdmissionInstructionsWorklist, preOperativeWorklist,
					operativeWorklist, phase1Worklist, phase2Worklist, phase3Worklist, recoveryWorklist, postoperativeQXWorklist);

			// Map Implant or Prosthetic to PreferenceCard
			mapImplantToPreferenceCard(prefCardId, implantName, manfacturerName, size, lotNum, serialNum, expiration, referenceNum, quantity, implantNotes);

			// Map Supplies to PreferenceCard
			mapSuppliesToPreferenceCard(prefCardId, supplyName, prOpen, prHold, orOpen, orHold, p1Open, p1Hold, p2Open, p2Hold, p3Open, p3Hold, supplyNotes);

			//Map map Equipment To PreferenceCard
			mapEquipmentToPreferenceCard(prefCardId, equipmentName, serialNumber, equipmentNotes);

			//Map Feeschedule to Preference Cards
			if(cptCodes!=null && !cptCodes.isEmpty()) {
				InsertPreferenceConfigFeeScheduelMap(prefCardId, cptCodes);
			}
		} else {
			prefCardId = Integer.valueOf(this.mapWebServiceResponses.get(IWebServiceResponseKeys.preferebceCardId).toString());
		}
		return prefCardId;
	}

	protected JSONArray getAllFeeSchedules(String cptCode) {
		String relURL = "FeeSchedule/GetFeeSchedules";
		LOG.info(String.format("Getting all available fee schedules"));
		Response feeSchedulesResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (feeSchedulesResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeSchedulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));

			JSONArray feeSchedules = new JSONArray(feeSchedulesResponse.asString());
			for (int index = 0; index < feeSchedules.length(); index++) {
				JSONObject dictionary = feeSchedules.getJSONObject(index);
				JSONObject cptProcedure = dictionary.getJSONObject("cptProcedure");
				if (cptProcedure.getString("cptCode").equalsIgnoreCase(cptCode)) {
					LOG.info(String.format("dictionary %s",dictionary.toString()));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.feeScheduleId, dictionary.get("feeScheduleId").toString());
					LOG.info(String.format("feeScheduleId %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.feeScheduleId)));
					break;
				}
			}
			return feeSchedules;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					feeSchedulesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response InsertPreferenceConfigFeeScheduelMap(int prefCardId, String cptCode)  throws Exception{
		String relURL = "PreferenceCardConfig/InsertPreferenceConfigFeeScheduelMap";
		JSONArray arrayObj = new JSONArray();
		for (int i = 0; i < cptCode.split("[,]").length; i++) {
			getAllFeeSchedules(cptCode.split("[,]")[i]);
			int feeScheduleid = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.feeScheduleId).toString());

			// API to update InsertPreferenceConfigFeeScheduelMap
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("preferenceCardId", prefCardId);
			jsonObject.put("feeScheduleId", feeScheduleid);
			jsonObject.put("feeScheduleRootId", feeScheduleid);
			jsonObject.put("displayOrder", i+1);
			arrayObj = arrayObj.put(jsonObject);
		}
		LOG.info(String.format("InsertPreferenceConfigFeeScheduelMap request %s",arrayObj.toString()));
		Response InsertPreferenceConfigFeeScheduelMapresonse = runWebServiceRequest("application/json", arrayObj.toString(), relURL, Method.POST);
		return InsertPreferenceConfigFeeScheduelMapresonse;
	}

	protected Response getStateReportInsuranceList() throws Exception{
		String relURL = "/StateReportingConfig/GetStateReportInsuranceList";
		// API to GetStateReportInsuranceList

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response getStateReportRaceList() throws Exception{
		String relURL = "/StateReportingConfig/GetStateReportRaceList";
		// API to GetStateReportRaceList

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response getStateReportEthnicityList() throws Exception{
		String relURL = "/StateReportingConfig/GetStateReportEthnicityList";
		// API to GetStateReportEthnicityList

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected Response getStateReportPhysicianList() throws Exception{
		String relURL = "/StateReportingConfig/GetStateReportPhysicianList";
		// API to GetStateReportPhysicianList
		Object physicianObj = jsonUtils.getJsonFileAsObject("reqTemplates/getStateReportPhysician.json");

		return runWebServiceRequest("application/json", physicianObj.toString(), relURL, Method.POST);
	}

	protected Response getStateReportLanguageList() throws Exception{
		String relURL = "/StateReportingConfig/GetStateReportLanguageList";
		// API to GetStateReportLanguageList

		return runWebServiceRequest("application/json", "", relURL, Method.GET);
	}

	protected void updateStateReportInsurance(String payerCode, String stateCode) throws Exception{
		String relURL = "/StateReportingConfig/SaveStateReportInsurance";
		// API to SaveStateReportInsurance
		Response rsp = getStateReportInsuranceList();
		Object insuranceTemplateObj = jsonUtils.getJsonFileAsObject("reqTemplates/UpdateStateReportInsurance.json");

		JSONArray stateInsrnceArry = jsonUtils.returnJsonArrayFromString(rsp.asString());
		for (int i = 0; i < stateInsrnceArry.length(); i++) {
			JSONObject insuranceObj = stateInsrnceArry.getJSONObject(i);
			JSONArray planArry = insuranceObj.getJSONArray("plans");
			for (int j = 0; j < planArry.length(); j++) {
				JSONObject planObj = planArry.getJSONObject(j);
				String planName = planObj.getString("planName");
				String planId = planObj.get("planId").toString();
				Object obj = insuranceTemplateObj;
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "planId", Integer.parseInt(planId));
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "planName", planName);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "stateCode", stateCode);
				obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "payerCode", payerCode);
				runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
			}
		}
	}

	protected void updateStateReportEthnicity(String stateCode) throws Exception{
		String relURL = "/StateReportingConfig/SaveStateReportEthnicity";
		// API to SaveStateReportEthnicity
		Response rsp = getStateReportEthnicityList();
		Object ethnicityTemplateObj = jsonUtils.getJsonFileAsObject("reqTemplates/UpdateStateReportEthnicity.json");

		JSONArray stateEthinicityArry = jsonUtils.returnJsonArrayFromString(rsp.asString());
		for (int i = 0; i < stateEthinicityArry.length(); i++) {
			JSONObject ethnicityObj = stateEthinicityArry.getJSONObject(i);
			String ethnicityName = ethnicityObj.getString("name");
			String ethnicityId = ethnicityObj.get("id").toString();
			Object obj = ethnicityTemplateObj;
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "id", Integer.parseInt(ethnicityId));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "name", ethnicityName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "stateCode", stateCode);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
			runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		}
	}

	protected void updateStateReportLanguage(String stateCode) throws Exception{
		String relURL = "/StateReportingConfig/SaveStateReportLanguage";
		// API to SaveStateReportLanguage
		Response rsp = getStateReportLanguageList();
		Object languageTemplateObj = jsonUtils.getJsonFileAsObject("reqTemplates/UpdateStateReportLanguage.json");

		JSONArray stateLanguageArry = jsonUtils.returnJsonArrayFromString(rsp.asString());
		for (int i = 0; i < stateLanguageArry.length(); i++) {
			JSONObject languageObj = stateLanguageArry.getJSONObject(i);
			String languageName = languageObj.getString("name");
			String languageId = languageObj.get("id").toString();
			Object obj = languageTemplateObj;
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "id", Integer.parseInt(languageId));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "name", languageName);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "stateCode", stateCode);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
			runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		}
	}

	protected void updateStateReportPhysician(String stateCode) throws Exception{
		String relURL = "/StateReportingConfig/SaveStateReportPhysician";
		// API to SaveStateReportPhysician
		Response rsp = getStateReportPhysicianList();
		Object physicianTemplateObj = jsonUtils.getJsonFileAsObject("reqTemplates/UpdateStateReportPhysician.json");

		JSONArray statePhysicianArry = jsonUtils.returnJsonArrayFromString(rsp.asString());
		for (int i = 0; i < statePhysicianArry.length(); i++) {
			JSONObject physicianObj = statePhysicianArry.getJSONObject(i);
			String name = physicianObj.getString("name");
			String id = physicianObj.get("id").toString();
			Object obj = physicianTemplateObj;
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "id", Integer.parseInt(id));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "name", name);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "stateCode", stateCode);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
			runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		}
	}

	protected void updateStateReportRace(String stateCode) throws Exception{
		String relURL = "/StateReportingConfig/SaveStateReportRace";
		// API to SaveStateReportRace
		Response rsp = getStateReportRaceList();
		Object raceTemplateObj = jsonUtils.getJsonFileAsObject("reqTemplates/updateStateReportRace.json");

		JSONArray stateRaceArry = jsonUtils.returnJsonArrayFromString(rsp.asString());
		for (int i = 0; i < stateRaceArry.length(); i++) {
			JSONObject raceObj = stateRaceArry.getJSONObject(i);
			String name = raceObj.getString("name");
			String id = raceObj.get("id").toString();
			Object obj = raceTemplateObj;
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "id", Integer.parseInt(id));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "name", name);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "stateCode", stateCode);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId).toString()));
			runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		}
	}

	protected Response CreateNewUser(String firstName, String middleInitial, String lastName)  throws Exception{
		String relURL = "User/CreateNewUser";
		Response CreateNewUserresponse = null;
		// API to UpdateBaseOrder
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/CreateNewUser.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "firstName", firstName);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "middleInitial", middleInitial);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "lastName",lastName);

		CreateNewUserresponse =  runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (CreateNewUserresponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					CreateNewUserresponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			String personId = jsonUtils.getObjectFromJsonXpath(CreateNewUserresponse.asString(), "personId")
					.toString();
			String usrId = jsonUtils.getObjectFromJsonXpath(CreateNewUserresponse.asString(), "usrId")
					.toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.personId, personId);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.usrId, usrId);

		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					CreateNewUserresponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return CreateNewUserresponse;
	}

	protected JSONArray getProfile(String profileName) {
		String relURL = "Profile";
		LOG.info(String.format("Getting all available details Profile"));
		Response getProfileResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (getProfileResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					getProfileResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));

			JSONArray Profiles = new JSONArray(getProfileResponse.asString());
			for (int index = 0; index < Profiles.length(); index++) {
				JSONObject Profilesobj = Profiles.getJSONObject(index);
				if (Profilesobj.getString("profileAccessLevelName").equalsIgnoreCase(profileName)) {
					LOG.info(String.format("profile %s",Profilesobj.toString()));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.profileLevelId, Profilesobj.get("profileLevelId").toString());
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.profileAccessLevelName, Profilesobj.get("profileAccessLevelName").toString());
					LOG.info(String.format("profileLevelId %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.profileLevelId)));
					LOG.info(String.format("profileAccessLevelName %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.profileAccessLevelName)));
					break;
				}
			}
			return Profiles;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					getProfileResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected JSONArray getRoles(String roleName) {
		String relURL = "User/Roles";
		LOG.info(String.format("Getting all available details Profile"));
		Response getRolesResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (getRolesResponse.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					getRolesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));

			JSONArray Roles = new JSONArray(getRolesResponse.asString());
			for (int index = 0; index < Roles.length(); index++) {
				JSONObject Rolesobj = Roles.getJSONObject(index);
				if (Rolesobj.getString("text").equalsIgnoreCase(roleName)) {
					LOG.info(String.format("Role %s",Rolesobj.toString()));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.roleId, Rolesobj.get("id").toString());
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.roleName, Rolesobj.get("text").toString());
					LOG.info(String.format("roleId %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.roleId)));
					LOG.info(String.format("roleName %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.roleName)));
					break;
				}
			}
			return Roles;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					getRolesResponse.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected void SetUserOrganizationAssignment(String orgName, String profileName, String roleName)  throws Exception{
		String relURL = "Profile/SetUserOrganizationAssignment";
		getProfile(profileName);
		getRoles(roleName);
		GetAllBusinessEntities(orgName);
		Response SetUserOrgAssignmentresp = null;
		int orgid = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.businessfacilityId).toString());
		int usrId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.usrId).toString());
		int profLevelId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.profileLevelId).toString());
		int roleId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.roleId).toString());
		// API to UpdateBaseOrder
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/SetUserOrganizationAssignment.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationId", orgid);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "organizationName", orgName);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "usrId",usrId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "profileLevelName",profileName);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "profileLevelId",profLevelId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "roleId",roleId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "roleName",roleName);

		SetUserOrgAssignmentresp =  runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (SetUserOrgAssignmentresp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					SetUserOrgAssignmentresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					SetUserOrgAssignmentresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

	}

	protected void StaffUpsert(String businessfacility)  throws Exception{
		String relURL = "Staff/Upsert";
		GetAllBusinessEntities(businessfacility);
		int orgid = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.businessfacilityId).toString());
		int roleId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.roleId).toString());
		int personId = Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.personId).toString());
		// API to UpdateBaseOrder
		JSONObject obj = new JSONObject();
		obj.put("activeTf", true);
		obj.put("businessEntityId", orgid);
		obj.put("roleId", roleId);
		obj.put("personId", personId);
		obj.put("staffId", -1);

		runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
	}

	protected JSONArray GetAllBusinessEntities(String businessfacility) {
		String relURL = "Organization/GetAllBusinessEntities";
		LOG.info(String.format("Getting all available GetAllBusinessEntities"));
		Response BusinessEntitiesresp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (BusinessEntitiesresp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					BusinessEntitiesresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));

			JSONArray BusinessEntities = new JSONArray(BusinessEntitiesresp.asString());
			for (int index = 0; index < BusinessEntities.length(); index++) {
				JSONObject BusinessEntitieobj = BusinessEntities.getJSONObject(index);
				if (BusinessEntitieobj.getString("name").equalsIgnoreCase(businessfacility)) {
					LOG.info(String.format("BusinessEntitieobj %s",BusinessEntitieobj.toString()));
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.businessfacilityId, BusinessEntitieobj.get("organizationId").toString());
					LOG.info(String.format("feeScheduleId %s",this.mapWebServiceResponses.get(IWebServiceResponseKeys.businessfacilityId)));
					break;
				}
			}
			return BusinessEntities;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					BusinessEntitiesresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected String getChargeDetailsFromChargeEntryResp() throws Exception{
		String obj = this.mapWebServiceResponses.get(IWebServiceResponseKeys.chargeEntryResponse).toString();
		return jsonUtils.getObjectFromJsonXpath(obj, "$.[0].transactionList[0].chargeDetails").toString();
	}

	protected String getwriteOffDetailsObj(String writeOffGroupCode, String WriteOffReasonCode)  throws Exception{
		List<Object> getWriteOffGroupdetails = getWriteOffGroupList(writeOffGroupCode);
		List<Object> getWriteOffReasondetails = getWriteOffReasonList(WriteOffReasonCode);

		JSONObject obj = new JSONObject();
		obj.put("transactionId", 0);
		obj.put("writeoffReasonId", getWriteOffReasondetails.get(0).toString());
		obj.put("writeoffGroupId", getWriteOffGroupdetails.get(0).toString());
		obj.put("writeOffGroupDescription", getWriteOffGroupdetails.get(1).toString());
		obj.put("writeoffReasonDescription", getWriteOffReasondetails.get(1).toString());

		return obj.toString();
	}


	protected List<Object> getTransactionChargeDetails() throws Exception{
		String obj = this.mapWebServiceResponses.get(IWebServiceResponseKeys.chargeEntryResponse).toString();
		String batchId = jsonUtils.getObjectFromJsonXpath(obj, "$.[0].transactionList[0].batchId").toString();
		String transactionParentId = jsonUtils.getObjectFromJsonXpath(obj, "$.[0].transactionList[0].transactionParentId").toString();
		String transactionRootId = jsonUtils.getObjectFromJsonXpath(obj, "$.[0].transactionList[0].transactionRootId").toString();
		return Arrays.asList(batchId,transactionParentId, transactionRootId);
	}

	protected List<Object> getPaymentTransactionCodeListByType(String transactionCodeName) throws Exception{
		String relURL = "TransactionCode/GetTransactionCodeList";
		String transactionCodeId = null;

		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray getTransactionCodeListary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("getPaymentTransactionCodeListByType - %s", getTransactionCodeListary));
		JSONObject getTransactionCodejson1 = jsonUtils.getJSONObjectFromJSONArray(getTransactionCodeListary, "transactionCodeName", transactionCodeName);
		transactionCodeId = jsonUtils.getValueFromJsonObject(getTransactionCodejson1.toString(), "transactionCodeId");
		return Arrays.asList(transactionCodeId);
	}


	protected void addPaymentTransaction(String writeOffGroupCode, String WriteOffReasonCode, String amount,String transactionCodeName) {
		try {
			if(amount!=null && !amount.isEmpty()) {
				for(int i=0; i<amount.split("[;]").length;i++) {
					String relURL = "Transactions/SavePaymentTransactions";
					Object chargeentrydetailsObj = this.mapWebServiceResponses.get(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry);
					float prevBalance = Float.parseFloat(jsonUtils.getValueFromJsonObject(chargeentrydetailsObj.toString(), "balance").toString());
					chargeentrydetailsObj  = jsonUtils.updateOneJsonElement(chargeentrydetailsObj.toString(), "balance", ""+(prevBalance-Float.parseFloat(amount.split("[;]")[i])));
					chargeentrydetailsObj = Configuration.defaultConfiguration().jsonProvider().parse(chargeentrydetailsObj.toString());

					Object writeoffdetails = Configuration.defaultConfiguration().jsonProvider()
							.parse(getwriteOffDetailsObj(writeOffGroupCode, WriteOffReasonCode).toString());
					List<Object> TransactionCodedetails = getPaymentTransactionCodeListByType(transactionCodeName);

					List<Object> getTransactionChargeDetails = getTransactionChargeDetails();
					// API to UpdateBaseOrder
					Object obj = null;
					obj = jsonUtils.getJsonFileAsObject("reqTemplates/SavePaymentTransactions.json");
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.chargeDetails", chargeentrydetailsObj);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.writeOffDetails", writeoffdetails);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.transactionCodeId", Integer.parseInt(TransactionCodedetails.get(0).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.amount",amount.split("[;]")[i]);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.batchId",Integer.parseInt(getTransactionChargeDetails.get(0).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.transactionDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.transactionParentId",Integer.parseInt(getTransactionChargeDetails.get(1).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.transactionRootId",Integer.parseInt(getTransactionChargeDetails.get(2).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.postedDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.createdDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					//obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.[0].transaction.receivedFrom",null);

					Response addNewPaymentTransactionresp =  runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
					if (addNewPaymentTransactionresp.getStatusCode() == 200) {
						this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry, jsonUtils.getObjectFromJsonXpath(addNewPaymentTransactionresp.asString(),"$.[0].chargeDetails"));
						LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentTransactionresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
					} else {
						LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentTransactionresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void addNewWriteoffTransaction(String writeOffGroupCode, String WriteOffReasonCode, String amount,String transactionCodeName) {
		try {
			if(amount!=null && !amount.isEmpty()) {
				for(int i=0; i<amount.split("[;]").length;i++) {
					String relURL = "Transactions/SaveTransaction";

					Object chargeentrydetailsObj = this.mapWebServiceResponses.get(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry);
					float prevBalance = Float.parseFloat(jsonUtils.getValueFromJsonObject(chargeentrydetailsObj.toString(), "balance").toString());
					chargeentrydetailsObj  = jsonUtils.updateOneJsonElement(chargeentrydetailsObj.toString(), "balance", ""+(prevBalance-Float.parseFloat(amount.split("[;]")[i])));
					chargeentrydetailsObj = Configuration.defaultConfiguration().jsonProvider().parse(chargeentrydetailsObj.toString());

					Object writeoffdetails = Configuration.defaultConfiguration().jsonProvider()
							.parse(getwriteOffDetailsObj(writeOffGroupCode, WriteOffReasonCode).toString());
					List<Object> TransactionCodedetails = getPaymentTransactionCodeListByType(transactionCodeName);

					List<Object> getTransactionChargeDetails = getTransactionChargeDetails();
					// API to UpdateBaseOrder
					Object obj = null;
					obj = jsonUtils.getJsonFileAsObject("reqTemplates/SavePaymentWriteOffTransactions.json");
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.chargeDetails", chargeentrydetailsObj);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.writeOffDetails", writeoffdetails);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionCodeId", Integer.parseInt(TransactionCodedetails.get(0).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.amount",amount.split("[;]")[i]);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.batchId",Integer.parseInt(getTransactionChargeDetails.get(0).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionParentId",Integer.parseInt(getTransactionChargeDetails.get(1).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionRootId",Integer.parseInt(getTransactionChargeDetails.get(2).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.postedDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);

					Response addNewPaymentWriteOffresp =  runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
					if (addNewPaymentWriteOffresp.getStatusCode() == 200) {
						this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry, jsonUtils.getObjectFromJsonXpath(addNewPaymentWriteOffresp.asString(),"$.[0].chargeDetails"));
						LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentWriteOffresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
					} else {
						LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentWriteOffresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void addNewDebitTransaction(String amount) {
		try {
			if(amount!=null && !amount.isEmpty()) {
				for(int i=0; i<amount.split("[;]").length;i++) {
					String relURL = "Transactions/SaveTransaction";

					Object chargeentrydetailsObj = this.mapWebServiceResponses.get(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry);
					float prevBalance = Float.parseFloat(jsonUtils.getValueFromJsonObject(chargeentrydetailsObj.toString(), "balance").toString());
					chargeentrydetailsObj  = jsonUtils.updateOneJsonElement(chargeentrydetailsObj.toString(), "balance", ""+(prevBalance+Float.parseFloat(amount.split("[;]")[i])));
					chargeentrydetailsObj = Configuration.defaultConfiguration().jsonProvider().parse(chargeentrydetailsObj.toString());

					List<Object> getTransactionChargeDetails = getTransactionChargeDetails();
					// API to UpdateBaseOrder
					Object obj = null;
					obj = jsonUtils.getJsonFileAsObject("reqTemplates/SaveDebitTransactions.json");
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.chargeDetails", chargeentrydetailsObj);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.amount",amount.split("[;]")[i]);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.batchId",Integer.parseInt(getTransactionChargeDetails.get(0).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionParentId",Integer.parseInt(getTransactionChargeDetails.get(1).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.transactionRootId",Integer.parseInt(getTransactionChargeDetails.get(2).toString()));
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.postedDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);
					obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "$.transaction.createdDate",ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+timeZonveValue);

					Response addNewPaymentWriteOffresp =  runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
					if (addNewPaymentWriteOffresp.getStatusCode() == 200) {
						this.mapWebServiceResponses.put(IWebServiceResponseKeys.chargeDetailsRespFromChargeEntry, jsonUtils.getObjectFromJsonXpath(addNewPaymentWriteOffresp.asString(),"$.[0].chargeDetails"));
						LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentWriteOffresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
					} else {
						LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
								addNewPaymentWriteOffresp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected List<Object> getPaymentTransactionCodeListByType(String transactionCodeName,String abc) throws Exception{
		String relURL = "TransactionCode/GetTransactionCodeList";
		String transactionCodeId = null;

		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray getTransactionCodeListary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("getPaymentTransactionCodeListByType - %s", getTransactionCodeListary));
		JSONObject getTransactionCodejson1 = jsonUtils.getJSONObjectFromJSONArray(getTransactionCodeListary, "transactionCodeName", transactionCodeName);
		transactionCodeId = jsonUtils.getValueFromJsonObject(getTransactionCodejson1.toString(), "transactionCodeId");
		return Arrays.asList(transactionCodeId);
	}

	protected void createNewTransactionCode(String transactionCodeName,String transactiontype) {
		String relURL = "TransactionCode/UpsertTransactionCode";
		int transtypeid = 0;
		try {
			JSONObject jsonobj = new JSONObject();
			jsonobj.put("transactionCodeName", transactionCodeName);
			Response response = runWebServiceRequest("application/json", jsonobj.toString(), relURL, Method.POST);

			if(response.getStatusCode() == 200) {
				Object transrespobj = jsonUtils.getObjectFromJsonXpath(response.asString(), "$");
				Object tempObj = transrespobj;
				if(transactiontype.equalsIgnoreCase("Write-Off")) {
					transtypeid=4;
				} else if (transactiontype.equalsIgnoreCase("Payment")) {
					transtypeid=2;
				}  else if (transactiontype.equalsIgnoreCase("Charge")) {
					transtypeid=1;
				}  else if (transactiontype.equalsIgnoreCase("Unassigned Payment")) {
					transtypeid=3;
				}  else if (transactiontype.equalsIgnoreCase("Correction")) {
					transtypeid=5;
				}  else if (transactiontype.equalsIgnoreCase("Debit")) {
					transtypeid=6;
				} else if (transactiontype.equalsIgnoreCase("Transfer")) {
					transtypeid=7;
				}  else if (transactiontype.equalsIgnoreCase("Allocation")) {
					transtypeid=8;
				}
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "transactionTypeId", transtypeid);
				tempObj = jsonUtils.updateObjectJsonXpath(tempObj.toString(), "transactionType", transactiontype);

				response = runWebServiceRequest("application/json", tempObj.toString(), relURL, Method.POST);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected String getOrganizationId() {
		String relURL = "UserSession/UserSessionOrganizationId";
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);

		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		return response.asString(); 
	}

	protected void lockWorklistrecord(String recordLock) throws Exception{
		String relURL = "Security/RecordLock/RequestLock";
		Response response = runWebServiceRequest("application/json", recordLock, relURL, Method.POST);	

		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		LOG.info(String.format("Lock Worklist Record "));		
	}

	protected void unlockWorklistRecord(String recordLock) throws Exception{
		String relURL = "Security/RecordLock/ReleaseLock";
		Response response = runWebServiceRequest("application/json", recordLock, relURL, Method.POST);

		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		LOG.info(String.format("Unlock Worklist Record "));		
	}

	protected int getWorklistArea(String worklistType) {
		int workListArea = 0;
		if(worklistType.equalsIgnoreCase("PreAdmissionQx")) {
			workListArea =1;
		}else if(worklistType.equalsIgnoreCase("PreAdmissionInstructions")) {
			workListArea =2;
		}else if(worklistType.equalsIgnoreCase("Pre-Operative")) {
			workListArea =3;
		}else if(worklistType.equalsIgnoreCase("Operative")){
			workListArea =4;
		}else if(worklistType.equalsIgnoreCase("Recovery")){
			workListArea =7;
		}else if(worklistType.equalsIgnoreCase("PostoperativeQX")){
			workListArea =9;
		}else if(worklistType.equalsIgnoreCase("Phase1")){
			workListArea =5;
		}else if(worklistType.equalsIgnoreCase("Phase2")){
			workListArea =6;
		}else if(worklistType.equalsIgnoreCase("Phase3")){
			workListArea =8;
		}
		return workListArea;
	}

	protected void insertMedicationAdministrations(String userName) throws Exception{
		List<Object>physiciandetails = getPhysicianNameIDFromPhysicianName(userName);
		String staffID = physiciandetails.get(1).toString();
		String personId = physiciandetails.get(2).toString();
		String userFullName = physiciandetails.get(0).toString();
		String moduleid =  this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString();
		String caseSummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		String relURL = "Medication/GetMedications?caseSummaryId="+caseSummaryId+"&moduleId="+moduleid;// 1020 is module ID for pre-op
		String resp = runWebServiceRequest("application/json", "", relURL, Method.GET).asString();
		JSONArray medicationarry = jsonUtils.returnJsonArrayFromString(resp);

		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/InsertMedicationAdministrations.json");
		JSONArray medicationAdministrationReqArry = new JSONArray();

		for(int i=0; i< medicationarry.length(); i++) {
			JSONObject tempObj = jsonUtils.returnJsonArrayFromString(obj.toString()).getJSONObject(0);

			JSONObject medicationObj = medicationarry.getJSONObject(i);
			/*String medicationID = medicationObj.get("medicationId").toString();
			String dose = medicationObj.get("dose").toString();
			String route = medicationObj.get("route").toString();
			String unit = medicationObj.get("unit").toString();
			String site = medicationObj.get("site").toString();
			String routeId = medicationObj.get("routeId").toString();
			String unitId = medicationObj.get("unitId").toString();
			String siteId = medicationObj.get("siteId").toString();*/
			if(medicationObj.get("medicationId")!=null)
				tempObj = tempObj.put("medicationId", medicationObj.get("medicationId"));
			if(medicationObj.get("dose")!=null)
				tempObj = tempObj.put("dose", medicationObj.get("dose"));
			if(medicationObj.get("route")!=null)
				tempObj = tempObj.put("route", medicationObj.get("route"));
			if(medicationObj.get("unit")!=null)
				tempObj = tempObj.put("unit", medicationObj.get("unit"));
			if(medicationObj.get("site")!=null)
				tempObj = tempObj.put("site", medicationObj.get("site"));
			if(medicationObj.get("routeId")!=null)
				tempObj = tempObj.put("routeId", medicationObj.get("routeId"));
			if(medicationObj.get("unitId")!=null)
				tempObj = tempObj.put("unitId", medicationObj.get("unitId"));
			if(medicationObj.get("siteId")!=null)
				tempObj = tempObj.put("siteId", medicationObj.get("siteId"));
			tempObj.put("administeredById", staffID);
			tempObj.put("administeredBy", userFullName);
			tempObj.put("chartedBy", userFullName);
			tempObj.put("chartedById", personId);
			//			update dates to current date
			tempObj.put("date", ReusableUtils.getDate("MM/dd/yyyy"));
			tempObj.put("previousServerDate", ReusableUtils.getDate("MM/dd/yyyy"));
			tempObj.put("time", ReusableUtils.getDate("hh:mm:ss"));
			tempObj.put("previousServerTime", ReusableUtils.getDate("hh:mm"));
			tempObj.put("dateTime", ReusableUtils.getDate("yyyy-MM-dd")+"T"+ReusableUtils.getDate("hh:mm:ss")+"+05:30");
			medicationAdministrationReqArry.put(tempObj);

		}
		relURL = "Medication/InsertMedicationAdministrations";
		runWebServiceRequest("application/json", medicationAdministrationReqArry.toString(), relURL, Method.POST);
	}

	protected ArrayList<Integer> getMedication(String medicationname) throws Exception{
		String relURL = "/MedicationTemplate/GetMedicationTemplates";
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		// API to GetPhysicianeNameAndID
		ArrayList<Integer> medicationidlist=new ArrayList<Integer>();
		Integer medicationid = 0;
		String medicationname_mul = medicationname;
		for(int i=0; i<medicationname_mul.split("[;]").length;i++) {
			medicationname = medicationname_mul.split("[;]")[i];
			JSONArray medicationtemparray = jsonUtils.returnJsonArrayFromString(response.asString());
			LOG.info(String.format("medicationtemparray - %s", medicationtemparray));
			JSONObject medicationtempjson1 = jsonUtils.getJSONObjectFromJSONArray(medicationtemparray, "templateName", medicationname);
			medicationid = Integer.parseInt(jsonUtils.getValueFromJsonObject(medicationtempjson1.toString(), "medicationTemplateId"));
			medicationidlist.add(medicationid);
		}
		return medicationidlist;
	}

	protected Response addMedicationtopatient(String medicationname,String departmentname)  throws Exception{
		String relURL = "/Medication/AddMedications";
		getCaseDetailInformation(departmentname);
		boolean isOrdersEnabled = isFeatureEnabled("Orders");
		JSONObject obj = new JSONObject();
		if(isOrdersEnabled) {
			createCasePhysicianOrderId(departmentname);
			getCasePhysicianOrderId(departmentname);
			Response response = addMedicationToOrders(medicationname, departmentname);
			return response;
		} else {
			obj.put("caseSummaryId",this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
			obj.put("moduleId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString()));
			JSONArray medicationListobj = new JSONArray();
			obj.put("medicationList", medicationListobj);
			obj.put("templateIdList", getMedication(medicationname));
			Response response = runWebServiceRequest("application/json",obj.toString(), relURL, Method.POST);
			return response;
		}
	}

	protected void addMedication(String userName, String medicationname, String departmentname) throws Exception {
		addMedicationtopatient(medicationname, departmentname);
		if(isFeatureEnabled("Orders")) {
			administerMedicationsInOrders(departmentname);
		} else {
			insertMedicationAdministrations(userName);
		}

		if (this.reporter != null) {
			this.reporter.logSuccess(String.format("Successfully created addMedication for %s",departmentname));
		}
	}

	protected void signPatientDepartment(String departmentname) throws Exception {
		getCaseDetailInformation(departmentname);
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		int moduleId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString());

		String relURL = "BasicModuleInfoSignature/SignByCurrentUser/" + casesummaryId + "/"+ moduleId;
		LOG.info(String.format("signPatientDepartment"));
		runWebServiceRequest("application/json", "", relURL, Method.POST);
	}

	protected boolean verifyExistanceofinsurance(String insurancename,String Insuranceplanname) {
		String relURL = "InsurancePlan/GetInsurancePlans";
		int insuranceCarrierId = 0;
		Response GetInsurancePlansResponce = null;
		JSONObject GetInsurancePlans = new JSONObject();
		try {
			Response response = getinsuranceCarriers();
			JSONArray incuranceCarriersarray = jsonUtils.returnJsonArrayFromString(response.asString());
			JSONObject SingleincuranceCarrierarray = jsonUtils.getJSONObjectFromJSONArray(incuranceCarriersarray,
					"insuranceCarrierName", insurancename);
			if (SingleincuranceCarrierarray == null) {
				return false;
			}
			insuranceCarrierId = Integer.parseInt(
					jsonUtils.getValueFromJsonObject(SingleincuranceCarrierarray.toString(), "insuranceCarrierId"));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceCarrierId, insuranceCarrierId);
			GetInsurancePlans.put("insuranceCarrierId", insuranceCarrierId);
			LOG.info(String.format("GetInsurancePlans.........>%s", GetInsurancePlans.toString()));
			GetInsurancePlansResponce = runWebServiceRequest("application/json", GetInsurancePlans.toString(), relURL,
					Method.POST);
			JSONArray GetInsurancePlansResponsearray = jsonUtils.returnJsonArrayFromString(GetInsurancePlansResponce.asString());
			JSONObject Singleincuranceplanobj = jsonUtils.getJSONObjectFromJSONArray(GetInsurancePlansResponsearray,"planName", Insuranceplanname);
			if (Singleincuranceplanobj == null) {
				return false;
			}else {

				String insurancePlanId = Singleincuranceplanobj.get("insurancePlanId").toString();
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.insurancePlanId, insurancePlanId);
				if (!Singleincuranceplanobj.get("claimOfficeId").equals(null) ) {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceClaimOfficeid, Singleincuranceplanobj.get("claimOfficeId"));
				}else {
					this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceClaimOfficeid, null);
				}
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	protected int getWorklistTemplatesForCase(String templateName, String caseSummaryId, String workListArea) throws Exception {
		String relURL = "WorklistClinical/GetTemplatesForCase/"+caseSummaryId+"/" + workListArea;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);	

		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		JSONArray worklistTemplates = new JSONArray(response.asString());
		for(int i = 0; i < worklistTemplates.length(); i++) {
			JSONObject worklistTemplate = worklistTemplates.getJSONObject(i);
			String encodedTemplateName = ReusableUtils.encodeString2Base64(templateName);
			if(encodedTemplateName.contentEquals(worklistTemplate.getString("name"))) {
				return worklistTemplate.getInt("worklistId");
			}
		}
		LOG.info(String.format("Getting worklist template id "));		
		return -1;
	}

	protected Response mapWorklistToPatient(String caseSummaryId, String worklistArea, String moduleId, int worklistId) {
		String relURL = "WorklistClinical/CopyWorklistFromConfig/"+caseSummaryId+"/"+worklistArea+"/"+moduleId+"/"+worklistId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getWorklistCaseDetailInformation(String caseSummaryId, String patientId, String moduleId) {
		String relURL = "PatientFacesheet/GetWorkListCaseDetailInformation/"+patientId+"/"+caseSummaryId+"/"+moduleId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getModules() {
		String relURL = "Module/GetModules/undefined";
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getModulesAndFormsByCaseId(String caseSummaryId) {
		String relURL = "ModuleComplex/GetModulesAndFormsByCaseId/"+caseSummaryId+"/undefined";
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getBasicModuleInfoByCaseSummaryId(String caseSummaryId) {
		String relURL = "BasicModuleInfo/GetBasicModuleInfoByCaseSummaryId/"+caseSummaryId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response isSpecimenSigned(String caseSummaryId, String moduleId) {
		String relURL = "SpecimenEntry/IsSpecimenSigned/"+caseSummaryId+"/"+moduleId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected Response getWorklistCaseDetails(String caseSummaryId, String moduleId) {
		String relURL = "WorklistCaseDetails/GetCaseDetails/"+caseSummaryId+"/"+moduleId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected int getWorklistTemplatesForCase(String templateName, String caseSummaryId, String workListArea, String moduleId) throws Exception {
		String relURL = "WorklistClinical/GetWorklist/"+caseSummaryId+"/" + workListArea+"/" + moduleId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);	

		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		JSONArray worklistTemplates = new JSONArray(response.asString());
		for(int i = 0; i < worklistTemplates.length(); i++) {
			JSONObject worklistTemplate = worklistTemplates.getJSONObject(i);
			String encodedTemplateName = ReusableUtils.encodeString2Base64(templateName);
			if(encodedTemplateName.contentEquals(worklistTemplate.getString("name"))) {
				return worklistTemplate.getInt("worklistId");
			}
		}
		LOG.info(String.format("Getting worklist template id "));		
		return -1;
	}

	protected Response updateWorklist(String worklistObject) {
		String relURL = "WorklistClinical/UpdateWorklist/false";
		Response response = runWebServiceRequest("application/json", worklistObject, relURL, Method.POST);
		if (response.getStatusCode() == 200) {			
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			return response;
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return null;
	}

	protected JSONObject getFormUsagebyByFormOwner(String caseSummaryId, String moduleId, String formId) throws Exception {

		String relURL = "FormUsage/GetFormUsagebyByFormOwner";
		// API to getFormUsagebyByFormOwner
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/GetFormUsagebyByFormOwner.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId", caseSummaryId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId", Integer.parseInt(moduleId));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formId", Integer.parseInt(formId));

		Response formUsageByOwnerResp = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if (formUsageByOwnerResp.getStatusCode() == 200) {
			LOG.info(String.format("formUsageByOwnerResp..................>%s", formUsageByOwnerResp.asString()));
			String formUsageId = jsonUtils.getObjectFromJsonXpath(formUsageByOwnerResp.asString(), "formId").toString();
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseFormUsageId, formUsageId);

			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formUsageByOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					formUsageByOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return new JSONObject(formUsageByOwnerResp.asString());
	}

	protected Response updateFormUsagebyByFormOwner(String formUsageId, String caseSummaryId, String moduleId, String formId, String staffId, String staffName) throws Exception {
		String relURL = "FormUsage/UpdateFormUsageByFormOwner";
		// API to updateFormUsagebyByFormOwner
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/updateFormUsagebyByFormOwner.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formUsageId", formUsageId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId", caseSummaryId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId", moduleId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "formId", formId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "staffId", staffId);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "staffName", staffName);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "lastUpdated",
				ReusableUtils.getDate("yyyy-MM-dd") + "T01:00:00.000");

		Response updateFormUsagebyByFormOwnerResp = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (updateFormUsagebyByFormOwnerResp.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateFormUsagebyByFormOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					updateFormUsagebyByFormOwnerResp.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return updateFormUsagebyByFormOwnerResp;
	}

	protected JsonObject getImplantsObject(JsonObject jsonObject, String implantsAndProsthesisByInventory, String implantName, String manufacturerName, String otherDetails) throws Exception {
		String DefimplantName = "",DefmanufacturerName = "",DefotherDetails="";
		List<Integer> otherdetails = new ArrayList<>();
		if(implantsAndProsthesisByInventory != null) {
			for(int i = 0; i < implantsAndProsthesisByInventory.split("[,]").length; i++) {
				JsonObject ImplantsProsthesisObject = new JsonObject(); 
				try {
					DefimplantName = implantName.split("[,]")[i];
				}catch(Exception e) {}
				try {
					DefmanufacturerName = manufacturerName.split("[,]")[i];
				}catch(Exception e) {}
				try {
					DefotherDetails = otherDetails.split("[;]")[i];
				}catch(Exception e) {}
				if(implantsAndProsthesisByInventory.split("[,]")[i].equalsIgnoreCase("Y")) {
					getImplantDetails(DefimplantName);
					getManufacturersDetails(DefmanufacturerName);
					ImplantsProsthesisObject.addProperty("HardwareTF", true);
					ImplantsProsthesisObject.addProperty("IsKeySearchEnabledImplant", true);
					ImplantsProsthesisObject.addProperty("IsKeySearchEnabledManufacture", true);
					ImplantsProsthesisObject.addProperty("ImplantProsthesis", DefimplantName);
					ImplantsProsthesisObject.addProperty("inventoryNumber", ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.implantId));
					ImplantsProsthesisObject.addProperty("ImplantExternalIdentifier", ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.ImplantExternalIdentifier));
				} else {
					ImplantsProsthesisObject.addProperty("HardwareTF", true);
					ImplantsProsthesisObject.addProperty("IsKeySearchEnabledImplant", false);
					ImplantsProsthesisObject.addProperty("IsKeySearchEnabledManufacture", false);
					ImplantsProsthesisObject.addProperty("ImplantProsthesis", DefimplantName);
				}
				ImplantsProsthesisObject.addProperty("Manufacturer", DefmanufacturerName);
				if(implantsAndProsthesisByInventory.split("[,]")[i].equalsIgnoreCase("Y")) {
					ImplantsProsthesisObject.addProperty("ManufacturerExternalIdentifier", ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.ManufacturerExternalIdentifier));
				}
				for (int k = 0; k < DefotherDetails.split("[,]").length; k++) {
					otherdetails.add(Integer.parseInt(DefotherDetails.split("[,]")[k]));
				}
				ImplantsProsthesisObject.addProperty("Quantity", otherdetails.get(0));
				ImplantsProsthesisObject.addProperty("Size", otherdetails.get(1));
				ImplantsProsthesisObject.addProperty("LotNumber", otherdetails.get(2));
				ImplantsProsthesisObject.addProperty("SerialNumber", otherdetails.get(3));
				ImplantsProsthesisObject.addProperty("Expiration", otherdetails.get(4));
				ImplantsProsthesisObject.addProperty("ReferenceNumber", otherdetails.get(5));
				ImplantsProsthesisObject.addProperty("Notes", "Notes");
				otherdetails.clear();
				ImplantsProsthesisObject.addProperty("sortOrder", (i));
				jsonObject.getAsJsonArray("Questions").get(0).getAsJsonObject().getAsJsonArray("ImplantsProsthesisList").add(ImplantsProsthesisObject);
			}
		}
		return jsonObject; 
	}

	protected JsonObject getSuppliesObject(JsonObject jsonObject, String suppliesAndInstrumentsByInventory, String supplyNames, String supplyotherDetails) throws Exception {
		String DefSupplyName = "";
		String DefotherDetails = "";
		List<Integer> otherdetails = new ArrayList<>();
		if(suppliesAndInstrumentsByInventory != null) {
			for(int i = 0; i < suppliesAndInstrumentsByInventory.split("[,]").length; i++) {
				JsonObject supplyInstrObj = new JsonObject(); 
				try {
					DefSupplyName = supplyNames.split("[,]")[i];
				}catch(Exception e) {}
				try {
					DefotherDetails = supplyotherDetails.split("[;]")[i];
				}catch(Exception e) {}
				if(suppliesAndInstrumentsByInventory.split("[,]")[i].equalsIgnoreCase("Y")) {
					getSupplyDetails(DefSupplyName);
					supplyInstrObj.addProperty("inventoryNumber", ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.supplyId));		

				} else {
					supplyInstrObj.addProperty("externalIdentifier", "");
				}
				supplyInstrObj.addProperty("supplyName", DefSupplyName);
				supplyInstrObj.addProperty("notes", "1");
				supplyInstrObj.add("quantities", new JsonArray());
				for (int k = 0; k < DefotherDetails.split("[,]").length; k++) {
					otherdetails.add(Integer.parseInt(DefotherDetails.split("[,]")[k]));
				}
				supplyInstrObj.addProperty("qtyUsed", otherdetails.get(0));
				supplyInstrObj.addProperty("qtyWasted", otherdetails.get(1));
				supplyInstrObj.addProperty("qtyDefective", otherdetails.get(2));
				supplyInstrObj.addProperty("isEditable", false);
				if(jsonObject.getAsJsonArray("Questions").size() != 1) {
					jsonObject.getAsJsonArray("Questions").get(1).getAsJsonObject().getAsJsonArray("suppliesInstrumentsList").add(supplyInstrObj);
				} else {
					jsonObject.getAsJsonArray("Questions").get(0).getAsJsonObject().getAsJsonArray("suppliesInstrumentsList").add(supplyInstrObj);
				}
			}
		}
		return jsonObject;

	}

	protected void addWorklistToPatient(String departmentName, String operativeWorklist, String implantsAndProsthesisByInventory,  
			String implantName, String manufacturerName, String otherDetails, 
			String suppliesAndInstrumentsByInventory, String supplyNames, String supplyotherDetails,
			String equipmentByInventory, String equipmentName, String serialNumber, String notes) throws Exception {
		String moduleId = "";		
		String worklistArea = "";
		moduleId = getModulesBycaseId(departmentName);
		getFormByName();
		List<Object>physiciandetails = getPhysicianNameIDFromPhysicianName(this.mapWebServiceResponses.get(IWebServiceResponseKeys.sessionUserName).toString());
		String staffID = physiciandetails.get(1).toString(); 
		String userFullName = physiciandetails.get(0).toString();		
		worklistArea = String.valueOf(getWorklistArea(departmentName));

		String patientId = (String) this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId);
		String caseSummaryId = (String) this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID);
		int worklistId = getWorklistTemplatesForCase(operativeWorklist, caseSummaryId, worklistArea);

		getWorklistCaseDetailInformation(caseSummaryId, patientId, moduleId); 		

		JSONObject formUsageDetails = getFormUsagebyByFormOwner(caseSummaryId, moduleId, this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString());		

		Object lockObject = jsonUtils.getJsonFileAsObject("reqTemplates/lockPatient.json");
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "CaseSummaryId", caseSummaryId);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "ModuleId", moduleId);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "RecordLockTypeId", 2);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "ObjectId", worklistArea);

		lockWorklistrecord(lockObject.toString());		

		updateFormUsagebyByFormOwner(""+formUsageDetails.getInt("formUsageId"), caseSummaryId, moduleId, this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString(), staffID, userFullName).asString();		

		Response worklistCaseSummaryResponse = mapWorklistToPatient(caseSummaryId, worklistArea, moduleId, worklistId);
		JSONObject worklistCaseSummaryObject = new JSONObject(worklistCaseSummaryResponse.asString());

		Gson gson = new Gson();
		// Prepare the inner payload for implants
		JsonObject worklistObj = new JsonObject();
		JsonArray worklistArry = new JsonArray();

		String implantContent = new String(Files.readAllBytes(Paths.get("reqTemplates\\WorklistImplantNSupplies.json")), StandardCharsets.UTF_8);
		JsonObject implantjsonObject = gson.fromJson(implantContent, JsonObject.class);
		if((implantName != null && !implantName.isEmpty()) && !(implantName.equalsIgnoreCase("BLANK"))) {
			implantjsonObject = getImplantsObject(implantjsonObject, implantsAndProsthesisByInventory, implantName, manufacturerName,otherDetails);
			worklistArry.add(implantjsonObject.get("Questions").getAsJsonArray().get(0).getAsJsonObject());
		}

		// Prepare the inner payload for Supplies
		String supplyContent = new String(Files.readAllBytes(Paths.get("reqTemplates\\WorklistSupplies.json")), StandardCharsets.UTF_8);
		JsonObject supplyjsonObject = gson.fromJson(supplyContent, JsonObject.class);
		if(supplyNames != null && !supplyNames.isEmpty() && !supplyNames.equalsIgnoreCase("BLANK")) {
			supplyjsonObject = getSuppliesObject(supplyjsonObject, suppliesAndInstrumentsByInventory, supplyNames, supplyotherDetails);
			worklistArry.add(supplyjsonObject.get("Questions").getAsJsonArray().get(0).getAsJsonObject());
		}

		// Prepare the inner payload for Equipment
		String equipmentContent = new String(Files.readAllBytes(Paths.get("reqTemplates\\WorklistEquipment.json")), StandardCharsets.UTF_8);
		JsonObject equipmentjsonObject = gson.fromJson(equipmentContent, JsonObject.class);
		if((equipmentName != null && !equipmentName.isEmpty()) && !(equipmentName.equalsIgnoreCase("BLANK"))) {
			equipmentjsonObject = getEquipmentObject(equipmentjsonObject, equipmentByInventory, equipmentName, serialNumber, notes);
			worklistArry.add(equipmentjsonObject.get("Questions").getAsJsonArray().get(0).getAsJsonObject());
		}

		worklistObj.add("Questions", worklistArry);
		String encodeImplantSupplyData = ReusableUtils.encodeString2Base64(worklistObj.toString());
		JSONObject updateWorklistObj = new JSONObject();		

		updateWorklistObj.put("encodedWorklist", encodeImplantSupplyData);
		updateWorklistObj.put("percentageCompleted", 100);

		updateWorklistObj.put("worklistArea", Integer.parseInt(worklistArea));
		updateWorklistObj.put("patientId", Integer.parseInt(patientId));
		updateWorklistObj.put("lastUpdateDt", worklistCaseSummaryObject.getString("lastUpdateDt"));
		updateWorklistObj.put("isWorklistEncoded", true);
		updateWorklistObj.put("worklistObject", JSONObject.NULL);
		updateWorklistObj.put("moduleId", Integer.parseInt(moduleId));
		updateWorklistObj.put("reviewedBy", JSONObject.NULL);
		updateWorklistObj.put("reviewedDate", JSONObject.NULL);
		updateWorklistObj.put("caseSummaryId", Integer.parseInt(caseSummaryId));		
		updateWorklist(updateWorklistObj.toString());
		unlockWorklistRecord(lockObject.toString());
	}
	
	protected void mapImplantToPatient(String preferenceCardName, String implantsAndProsthesisByInventory) throws Exception{
		String moduleId = getModulesBycaseId("Operative");
		getFormByName();
		List<Object>physiciandetails = getPhysicianNameIDFromPhysicianName(this.mapWebServiceResponses.get(IWebServiceResponseKeys.sessionUserName).toString());
		String staffID = physiciandetails.get(1).toString(); 
		String userFullName = physiciandetails.get(0).toString();
		Gson gson = new Gson();
		// Prepare the inner payload for implants
		JsonObject implantObj = new JsonObject();
		JsonArray implantArry = new JsonArray();
		String patientId = (String) this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId);
		String caseSummaryId = (String) this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID);
		Object lockObject = jsonUtils.getJsonFileAsObject("reqTemplates/lockPatient.json");
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "CaseSummaryId", caseSummaryId);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "ModuleId", moduleId);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "RecordLockTypeId", 2);
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "ObjectId", 4);
		JSONObject formUsageDetails = getFormUsagebyByFormOwner(caseSummaryId, moduleId, this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString());
		lockWorklistrecord(lockObject.toString());
		updateFormUsagebyByFormOwner(""+formUsageDetails.getInt("formUsageId"), caseSummaryId, moduleId, this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseFormId).toString(), staffID, userFullName).asString();
		//get implant details from preference card
		String prefCardData = getImplantsFromPreferenceCard(preferenceCardName);
		JSONObject prefCardObj = new JSONObject(prefCardData);
		JSONArray implantDetailsAry = prefCardObj.getJSONArray("implantProstheses");
		
		String implantContent = new String(Files.readAllBytes(Paths.get("reqTemplates\\WorklistImplantNSupplies.json")), StandardCharsets.UTF_8);
		JsonObject implantjsonObject = gson.fromJson(implantContent, JsonObject.class);
		String implantName = "", manufacturerName = "", otherDetails = "", searchInv = "";;
		int i = 0;
		for(Object obj: implantDetailsAry) {
			JSONObject impObj = new JSONObject(obj.toString());
			String impName = ReusableUtils.decodeBase642String(impObj.getString("implantName"));
			String manufactr = ReusableUtils.decodeBase642String(impObj.getString("manufacturerName"));
			String lotNum = ReusableUtils.decodeBase642String(impObj.getString("lotNum"));
			String serialNum = ReusableUtils.decodeBase642String(impObj.getString("serialNum"));
			String referenceNum = ReusableUtils.decodeBase642String(impObj.getString("referenceNum"));
			String size = ReusableUtils.decodeBase642String(impObj.getString("size"));
			String quantity = impObj.get("quantity").toString();
			String expiration = ReusableUtils.decodeBase642String(impObj.getString("expiration"));
			
			if(i==0) {
				implantName = impName;
				manufacturerName = manufactr;
				otherDetails = quantity+","+size+","+lotNum+","+serialNum+","+expiration+","+referenceNum;
				searchInv = "Y";
			}else {
			implantName = implantName +","+impName;
			manufacturerName = manufacturerName +","+manufactr;
			otherDetails = otherDetails +";"+otherDetails;
			searchInv = searchInv +","+searchInv;
			}
			i++;
		}
		implantjsonObject = getImplantsObject(implantjsonObject, implantsAndProsthesisByInventory, implantName, manufacturerName, otherDetails);
		implantArry.add(implantjsonObject.get("Questions").getAsJsonArray().get(0).getAsJsonObject());


		implantObj.add("Questions", implantArry);
		String encodeImplantSupplyData = ReusableUtils.encodeString2Base64(implantObj.toString());
		JSONObject updateWorklistObj = new JSONObject();		

		updateWorklistObj.put("encodedWorklist", encodeImplantSupplyData);
		updateWorklistObj.put("percentageCompleted", 100);

		updateWorklistObj.put("worklistArea", 4);
		updateWorklistObj.put("patientId", Integer.parseInt(patientId));
		updateWorklistObj.put("lastUpdateDt", ReusableUtils.getDate("yyyy-MM-dd")+"T09:48:33.3779413-04:00");
		updateWorklistObj.put("isWorklistEncoded", true);
		updateWorklistObj.put("worklistObject", JSONObject.NULL);
		updateWorklistObj.put("moduleId", Integer.parseInt(moduleId));
		updateWorklistObj.put("reviewedBy", JSONObject.NULL);
		updateWorklistObj.put("reviewedDate", JSONObject.NULL);
		updateWorklistObj.put("caseSummaryId", Integer.parseInt(caseSummaryId));		
		
		
		updateWorklist(updateWorklistObj.toString());
		lockObject = jsonUtils.updateObjectJsonXpath(lockObject.toString(), "lockReRequested", false);
		unlockWorklistRecord(lockObject.toString());
	}


	protected Response getpatientObjfromName(String patientsearchstring, String fullName) throws Exception {
		String relURL = "/PatientData/Gemini/SearchToken";
		JSONObject patientreqobj = new JSONObject();
		patientreqobj.put("pageCount",0);
		patientreqobj.put("fetchImages",true);
		patientreqobj.put("searchString", patientsearchstring);

		Response response = null;
		response = runWebServiceRequest("application/json",patientreqobj.toString(), relURL, Method.POST);
		JSONArray searcharry = new JSONArray(response.asString());
		JSONObject patientobj = jsonUtils.getJSONObjectFromJSONArray(searcharry, "fullName", fullName);
		patientobj.put("adtLockedFieldList", new org.json.JSONArray());
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.createjustaPatientResp, patientobj);
		return response;
	}




	protected Map<String, String> getWorklistTemplates() {
		Map<String, String> worklistTemplateNames = new HashMap<>();
		worklistTemplateNames.put("Case Details", "worklist_caseDetails");
		worklistTemplateNames.put("Cautery", "worklist_cautery");
		worklistTemplateNames.put("Closure and Dressing", "worklist_ClosureAndDressing");
		worklistTemplateNames.put("Equipment", "worklist_equipment");
		worklistTemplateNames.put("Existing Implants", "worklist_ExistingImplants");
		worklistTemplateNames.put("Hair Removed", "worklist_hairRemoved");
		worklistTemplateNames.put("Implants and Prosthesis", "worklist_ImplantsProsthesis");
		worklistTemplateNames.put("Irrigations", "worklist_Irrigation");
		worklistTemplateNames.put("Normothermia", "worklist_Normothermia");
		worklistTemplateNames.put("Patient Position", "worklist_PatientPosition");
		worklistTemplateNames.put("Prep", "worklist_Prep");
		worklistTemplateNames.put("Psychosocial Status", "worklist_PsychosocialStatus");
		worklistTemplateNames.put("Safety Strap", "worklist_SafetyStrap");
		worklistTemplateNames.put("Site Marking", "worklist_SiteMarking");
		worklistTemplateNames.put("Supplies and Instruments", "worklist_SuppliesAndInstruments");
		worklistTemplateNames.put("Tourniquet", "worklist_Tourniquet");
		worklistTemplateNames.put("Wound Class", "worklist_WoundClass");
		worklistTemplateNames.put("X-Ray", "worklist_XRay");
		return worklistTemplateNames;
	}

	protected JsonObject getEncodedQuestions(String worklistQuestionName) throws Exception {
		Map<String, String> worklistQuestions = getWorklistTemplates();
		String content = new String(Files.readAllBytes(Paths.get("reqTemplates/"+worklistQuestions.get(worklistQuestionName)+".json")), StandardCharsets.UTF_8);
		Gson gson = new Gson();
		JsonObject jsonObject = gson.fromJson(content, JsonObject.class);
		jsonObject.addProperty("QuestionType", Integer.valueOf(jsonObject.get("QuestionType").getAsInt()));
		jsonObject.addProperty("Response", 1); // jsonObject.remove("Response");
		jsonObject.addProperty("$IsCompleted", true);
		return jsonObject;
	}

	protected void updatePatientArrivalTime(String date, String time, String appointmentId) throws Exception {
		Response response = null;
		date = ReusableUtils.addDate(date, "yyyy-MM-dd");
		String relURL = "/AppointmentInformation/UpdateArrivalTime/" + appointmentId;
		response = runWebServiceRequest("application/json",date + "T"+time+":15.480Z", relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected void getCancelCaseTemplateDetails(String dictionaryItem, String cancelCaseTemplateName) throws Exception {
		JSONArray cancelCaseTemplates = getDictionaryItems(dictionaryItem);
		JSONObject cancelCaseTemplate = jsonUtils.getJSONObjectFromJSONArray(cancelCaseTemplates, "value", cancelCaseTemplateName);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.cancelCaseWorklistTemplate, cancelCaseTemplate);
	}

	protected void cancelPatient(String cancelCaseTemplateName) throws Exception {
		Response response = null;
		getCancelCaseTemplateDetails("154", cancelCaseTemplateName);
		JSONObject cancelCaseObject = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.cancelCaseWorklistTemplate).toString());
		String relURL = "/CaseSummary/Gemini/UpsertCaseStatus";
		JSONObject requestBody = new JSONObject();
		requestBody.put("caseSummaryId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID));
		requestBody.put("status", 1);
		requestBody.put("cancelCaseReason", cancelCaseTemplateName);
		requestBody.put("cancelCaseReasonId", cancelCaseObject.getInt("id"));
		requestBody.put("cancelDate",  ReusableUtils.addDate("Today", "yyyy-MM-dd") + "T21:09:20.139Z");

		response = runWebServiceRequest("application/json",requestBody.toString(), relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected LinkedHashMap<String, ArrayList<String>> getAllFacilityFeatures(String facility) throws Exception {
		String relURL = "Security/GetOrganizationAllFeatureStatesForConfiguration/"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId);
		// API to getAllFacilityFeatures
		Response res = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray arr = new JSONArray(res.asString());
		LinkedHashMap<String, ArrayList<String>> featureMapping = new LinkedHashMap<>();
		for (int i = 0; i < arr.length(); i++) {
			JSONObject childObj = (JSONObject) arr.getJSONObject(i);
			ArrayList<String> featureDetails = new ArrayList<>();
			featureDetails.add(childObj.get("featureTypeId").toString());
			if(childObj.get("extendedDescription")!=null) {
				featureDetails.add(childObj.get("extendedDescription").toString());	
			}else {
				featureDetails.add("");
			}

			featureMapping.put(childObj.getString("featureName"), featureDetails);
		}
		return featureMapping; 
	}

	protected void updateFacilitySecureFeature(LinkedHashMap<String, ArrayList<String>> featureMapping, String feature, boolean flag) throws Exception{
		String relURL = "Security/SetOrganizationFeature/"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId);
		Object obj = null;
		//		System.out.println(feature);
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/updateFacilitySecureFeature.json");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "featureTypeId", Integer.parseInt(featureMapping.get(feature).get(0)));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "featureName", feature);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "isEnabled",flag);
		String desc = featureMapping.get(feature).get(1);
		if(desc==null 
				|| desc.equals("null")) {
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "extendedDescription","");
		}else {
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "extendedDescription",desc);
		}
		//System.out.println(obj.toString());
		// API to updateFacilitySecureFeature
		Response res = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
		if(res.asString().equalsIgnoreCase("true")) {
			this.reporter.logSuccess(String.format("Facility feature->  %s configuration is successful", feature));
		}else {
			this.reporter.logSuccess(String.format("Facility feature->  %s configuration is Un-successful", feature));
		}

	}

	protected String getBooleanValueForConditions(String value) {
		if(value != null && !value.isEmpty()) {
			if(value.equalsIgnoreCase("Enable")) {
				return "true";
			}else if(value.equalsIgnoreCase("disable")) {
				return "false";
			}else if(value.equalsIgnoreCase("on")) {
				return "true";
			}else if(value.equalsIgnoreCase("off")) {
				return "false";
			}else if(value.equalsIgnoreCase("show")) {
				return "true";
			}else if(value.equalsIgnoreCase("hide")) {
				return "false";
			}else {
				return null;
			}
		}else {
			return null;	
		}

	}

	// Method was written to have a mapping between the label names and the deature names used in the payloads but not been used as we directly referred to API features names
	protected String getFeatureMappingValue(String feature) {
		String mappedFeature = null;
		if(feature.equalsIgnoreCase("Clinical Documentation Tracker")) {
			mappedFeature = "CDM Tracker";

		}else if(feature.equalsIgnoreCase("Combined Coding/Charge Entry")) {
			mappedFeature = "Combined Coding Charging";

		}else if(feature.equalsIgnoreCase("External Inventory - Depletion")) {
			mappedFeature = "Depletion Tracker";

		}else if(feature.equalsIgnoreCase("External Inventory - Resources")){
			mappedFeature = "External Inventory";

		}else if(feature.equalsIgnoreCase("State Reporting")){
			mappedFeature = "State Reporting";

		}else if(feature.equalsIgnoreCase("SIS Office")){
			mappedFeature = "SIS Office";

		}else if(feature.equalsIgnoreCase("Business App Settings")){
			mappedFeature = "Business App Settings";

		}else if(feature.equalsIgnoreCase("Case Types")){
			mappedFeature = "Hide DTU Appointment Type Linking Columns";

		}else if(feature.equalsIgnoreCase("SIS Charts")){
			mappedFeature = "SIS Charts";

		}else if(feature.equalsIgnoreCase("Clinical App Settings")){
			mappedFeature = "Hide Clinical Application Settings";

		}else if(feature.equalsIgnoreCase("SIS Anesthesia")){
			mappedFeature = "SIS Anesthesia";

		}else if(feature.equalsIgnoreCase("Clinical App Settings_Anesthesia")){
			mappedFeature = "Clinical App Settings";

		}else if(feature.equalsIgnoreCase("Case Requests")){
			mappedFeature = "Case Requests";

		}else if(feature.equalsIgnoreCase("Eligibility")){
			mappedFeature = "Eligibility";

		}else if(feature.equalsIgnoreCase("UDB Data Transfer")){
			mappedFeature = "UDB Data Pushing";

		}
		return mappedFeature;
	}

	protected boolean isWorklistPresent(String worklistType, String worklistName) throws Exception {
		if (getWorklistDetails(getWorklistArea(worklistType), worklistName)) {
			LOG.info("Worklist is present");
			return true;
		}
		return false;
	}

	protected boolean isPreferenceCardPresent(String preferenceCardName) {
		Response response = null;
		String relURL = "/PreferenceCardConfig/GetPreferenceCardConfigList";
		response = runWebServiceRequest("application/json","", relURL, Method.GET);

		JSONArray preferenceCardList = new JSONArray(response.asString());
		JSONObject preferenceCard = jsonUtils.getJSONObjectFromJSONArray(preferenceCardList, "preferenceCardName", preferenceCardName);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		if(preferenceCard != null) {
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.preferebceCardId, preferenceCard.get("preferenceCardId"));
			return true;
		}
		return false;
	}

	protected String getPeriodById(String periodId) throws Exception {
		org.json.JSONArray periods = new org.json.JSONArray(getAllPeriods().asString());
		for (int index = 0; index < periods.length(); index++) {
			JSONObject period = periods.getJSONObject(index);
			if (period.getInt("periodId") == Integer.valueOf(periodId)) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.period, period);
				return period.toString();
			}
		}
		return null;
	}

	protected String returnIcdDescFromICDCode(String ICDCode) throws Exception {
		String relURL = "/ICDCodeClassification/GetICDCodeClassifications";

		Response response = null;
		response = runWebServiceRequest("application/json","\""+ICDCode.toString()+"\"", relURL, Method.POST);
		JSONArray searcharry = new JSONArray(response.asString());
		return searcharry.getJSONObject(0).getString("icdCodeDescription");
	}

	protected JSONArray getEquipmentDetailsForPreferenceCard(String preferenceCardId) {
		Response response = null;
		String relURL = "/PreferenceCardConfig/GetAllPrefCardEquipment";
		JSONArray jsonArray = new JSONArray();
		jsonArray.put(preferenceCardId);
		response = runWebServiceRequest("application/json",jsonArray.toString(), relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		if(!(response.asString().equals("null"))) {
			JSONArray equipmentList = new JSONArray(response.asString());
			return equipmentList;
		}
		return null;
	}

	protected Object addPreferenceCardToPatient(Object caseSummaryRequestobj, String preferenceCardName) throws Exception {
		JSONArray casePreferenceCards = new JSONArray();

		boolean isPreferenceCardPresent = isPreferenceCardPresent(preferenceCardName);
		if(isPreferenceCardPresent) {
			JSONArray preferenceCardEquipmentDetails = getEquipmentDetailsForPreferenceCard(this.mapWebServiceResponses.get(IWebServiceResponseKeys.preferebceCardId).toString());
			if(preferenceCardEquipmentDetails != null) {
				JSONArray caseEquipments = new JSONArray();
				for(int i = 0; i < preferenceCardEquipmentDetails.length(); i++) {
					JSONObject caseEquipment = new JSONObject();
					JSONObject preferenceCardCaseEquipment = preferenceCardEquipmentDetails.getJSONObject(i);
					caseEquipment.put("equipmentId", 0);
					caseEquipment.put("caseSummaryId", 0);
					caseEquipment.put("equipmentName", preferenceCardCaseEquipment.getString("equipmentName"));
					caseEquipment.put("equipmentQtyUsed", "1");
					caseEquipment.put("externalIdentifier", JSONObject.NULL);
					caseEquipment.put("serialNumber", preferenceCardCaseEquipment.getString("serialNumber"));
					caseEquipment.put("notes", preferenceCardCaseEquipment.getString("notes"));
					caseEquipment.put("preferenceCardId", preferenceCardCaseEquipment.getInt("preferenceCardId"));
					caseEquipment.put("inventoryEquipmentId", 0);
					caseEquipments.put(caseEquipment);
				}
				caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "caseEquipments", caseEquipments);
			}

			JSONObject casePreferenceCard = new JSONObject();
			casePreferenceCard.put("caseSummaryId", 0);
			casePreferenceCard.put("preferenceCardId", Integer.valueOf(this.mapWebServiceResponses.get(IWebServiceResponseKeys.preferebceCardId).toString()));
			casePreferenceCard.put("preferenceCardName", preferenceCardName);
			casePreferenceCard.put("sortOrder", 0);
			casePreferenceCards.put(casePreferenceCard);
			caseSummaryRequestobj = jsonUtils.updateOneJsonElement(caseSummaryRequestobj.toString(), "casePreferenceCards", casePreferenceCards);
		} else {
			throw new RuntimeException(preferenceCardName + " Preference card is not present ");
		}
		return caseSummaryRequestobj;
	}

	protected Response saveContract(String insuranceContractName, String effectiveDate,
			String expirationDate, String contractType) throws Exception {
		String relURL = "InsuranceContract/SaveInsuranceContract";
		// API to create Insurance(Carrier)
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddContract.json");
		// Update insuranceCarrierName,planName and classification
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceContractName", insuranceContractName);		
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "effectiveDate", ReusableUtils.getDate(effectiveDate, "MM/dd/yyyy"));
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "expirationDate", ReusableUtils.getDate(expirationDate, "MM/dd/yyyy"));
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "contractType", getContractType(contractType));

		LOG.info(String.format("Object-> %s", obj));
		Response response = null;
		response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
		String insuranceContractID = jsonUtils.getValueFromJsonObject(response.asString(),IWebServiceResponseKeys.insuranceContractID);
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceContractID, insuranceContractID);
		return response;
	}

	protected int getContractType(String contractType) {
		if(contractType.equals("Grouper")) {
			return 1;
		}else if(contractType.equals("Contract Fee Schedule")) {
			return 2;
		}else if(contractType.equals("% of Billed Charges")) {
			return 3;
		}
		return 0;
	}

	protected Response SelectContractOptions(String contractType, String percentOfBilledCharge, String transactionCodeName,
			String writeOffGroupId, String writeOffReasonId) throws Exception {
		String relURL = "InsuranceContract/SaveInsuranceContractPostingOption";
		// API toUpdate %Billed
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddContractPostingOption.json");
		// Update insuranceCarrierName,planName and classification
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "insuranceContractId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceContractID).toString()));

		if(!contractType.equalsIgnoreCase("Grouper"))
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "percentOfBilledCharge", Integer.parseInt(percentOfBilledCharge));

		if(writeOffGroupId != null && ! writeOffGroupId.isEmpty() && !writeOffGroupId.equalsIgnoreCase("BLANK")) {// if writeOffGroupId is not requried
			List<Object> getWriteOffGroupdetails = getWriteOffGroupList(writeOffGroupId);		
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "writeOffGroupId", Integer.parseInt(getWriteOffGroupdetails.get(0).toString()));
		}
		if(writeOffReasonId != null && ! writeOffReasonId.isEmpty() && !writeOffReasonId.equalsIgnoreCase("BLANK")) {// if writeOffReasonId is not requried
			List<Object> getWriteOffReasondetails = getWriteOffReasonList(writeOffReasonId);
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "writeOffReasonId", Integer.parseInt(getWriteOffReasondetails.get(0).toString()));
		}
		if(transactionCodeName != null && ! transactionCodeName.isEmpty() && !transactionCodeName.equalsIgnoreCase("BLANK")) {// if transactionCodeName is not requried
			List<Object> getTransactionCodeListByType = getTransactionCodeListByType(transactionCodeName);		
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "transactionCodeId", Integer.parseInt(getTransactionCodeListByType.get(0).toString()));
		}
		LOG.info(String.format("Object-> %s", obj));		
		Response response = null;
		response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.PUT);
		return response;
	}

	protected void updateFeeGroupsForGrouperContract(String groupIndx, String reimbursement) throws Exception {
		int i=0;
		for (String grpIndx: groupIndx.split("[,]")) {
			if(grpIndx!=null && !grpIndx.equalsIgnoreCase("BLANK")) {
				String relURL = "InsuranceContract/SaveInsuranceContractFeeGroup";
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("insuranceContractId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceContractID).toString()));
				jsonObj.put("groupIdx", Integer.parseInt(grpIndx));
				jsonObj.put("reimbursement", Integer.parseInt(reimbursement.split("[,]")[i]));
				jsonObj.put("isSelected", true);
				jsonObj.put("insuranceContractFeeGroupId", i+1);
				runWebServiceRequest("application/json", jsonObj.toString(), relURL, Method.PUT);
				i++;
			}
		}
	}

	protected void selectProcedureDiscount(String discountName, int procedureIndex) throws Exception{
		getDiscountDetails(discountName);
		String relURL = "InsuranceContract/SaveInsuranceContractProcedure";
		// API to create saveMultipleProceduresForContracts
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("sortIndex", procedureIndex);
		jsonObj.put("discountId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.discountId).toString()));
		jsonObj.put("insuranceContractId", Integer.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceContractID).toString()));
		runWebServiceRequest("application/json", jsonObj.toString(), relURL, Method.PUT);

	}
	protected void saveMultipleProceduresForContracts(String procedure1, String procedure2, String procedure3, String procedure4, String procedure5, String addtionalProcedure) throws Exception{
		if(procedure1!=null && !procedure1.equals("") && !procedure1.equalsIgnoreCase("BLANK"))		
			selectProcedureDiscount(procedure1, 1);	

		if(procedure2!=null && !procedure2.equals("")&& !procedure2.equalsIgnoreCase("BLANK"))			
			selectProcedureDiscount(procedure2, 2);	

		if(procedure3!=null && !procedure3.equals("")&& !procedure3.equalsIgnoreCase("BLANK"))			
			selectProcedureDiscount(procedure3, 3);	

		if(procedure4!=null && !procedure4.equals("")&& !procedure4.equalsIgnoreCase("BLANK"))			
			selectProcedureDiscount(procedure4, 4);	

		if(procedure5!=null && !procedure5.equals("")&& !procedure5.equalsIgnoreCase("BLANK"))			
			selectProcedureDiscount(procedure5, 5);	

		if(addtionalProcedure!=null && !addtionalProcedure.equals("")&& !addtionalProcedure.equalsIgnoreCase("BLANK"))		
			selectProcedureDiscount(addtionalProcedure, 6);	
	}
	protected void signPatientDepartments(String departments) throws Exception {
		List<String> departmentList = Arrays.asList(departments.split(";"));
		for(int i = 0; i < departmentList.size(); i++) {
			signPatientDepartment(departmentList.get(i));
		}
	}
	protected void getCasePhysicianOrderId(String departmentName) throws Exception {
		getCaseDetailInformation(departmentName);
		String relURL = "/PhysicianOrdersDocumentation/Names/Case/"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString()+"/Module/" + this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString();
		Response response = runWebServiceRequest("application/json","", relURL, Method.GET);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		if(!(response.asString().equals("null"))) {
			JSONArray physicianOrderDetails = new JSONArray(response.asString());
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.casePhysicianOrderId, jsonUtils.getValueFromJsonObject(physicianOrderDetails.getJSONObject(0).toString(), "casePhysicianOrderId"));
		}
	}

	protected void createCasePhysicianOrderId(String departmentName) throws Exception {
		String relURL = "/PhysicianOrdersDocumentation/"+getModulesBycaseId(departmentName);
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/createOrderId.json");
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "caseSummaryId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID));
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "casePhysicianOrderId", 0);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "caseSummaryId", this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID));
		JSONArray caseModuleOrderMaps = new JSONArray();
		JSONObject caseModuleOrder = new JSONObject();
		caseModuleOrder.put("moduleId", Integer.valueOf(getModulesBycaseId(departmentName)));
		caseModuleOrder.put("orders", new JSONArray());
		caseModuleOrderMaps.put(caseModuleOrder);
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "caseModuleOrderMaps", caseModuleOrderMaps);
		Response response = runWebServiceRequest("application/json",obj.toString(), relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		this.mapWebServiceResponses.put(IWebServiceResponseKeys.casePhysicianOrderId, response.asString());
	}

	protected boolean isFeatureEnabled(String featureName) throws Exception {
		String relURL = "/Security/GetAllFeatureStatesForConfiguration";
		Response response = runWebServiceRequest("application/json","", relURL, Method.GET);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		JSONArray featureDetails = new JSONArray(response.asString());
		JSONObject requiredFeature = jsonUtils.getJSONObjectFromJSONArray(featureDetails, "featureName", featureName);
		return Boolean.valueOf(jsonUtils.getValueFromJsonObject(requiredFeature.toString(), "isEnabled"));
	}

	protected boolean getPhysicianOrdersDocumentation() throws Exception {
		String relURL = "/PhysicianOrdersDocumentation/Names/Case/" + this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();
		Response response = runWebServiceRequest("application/json","", relURL, Method.GET);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		JSONArray orderDetails = new JSONArray(response.asString());
		if(orderDetails.length() > 0) {
			return true;
		}
		return false;
	}

	protected void getPhysicianOrdersDocumentation(String departmentName) throws Exception {
		getCaseDetailInformation(departmentName);
		String relURL = "/PhysicianOrdersDocumentation/"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.casePhysicianOrderId).toString()+"/" + this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseModuleId).toString();
		Response response = runWebServiceRequest("application/json","", relURL, Method.GET);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected JSONObject getMedicationTemplate(String medicationTemplateName) throws Exception {
		JSONArray medicationTemplates = getMedicationTemplates();
		JSONObject medicationTemplate = jsonUtils.getJSONObjectFromJSONArray(medicationTemplates, "templateName", medicationTemplateName);
		return medicationTemplate;
	}

	protected JSONObject getMedicationOrder(String moduleId, String medicationTemplateName, int sortOrder) throws Exception {
		JSONObject medicationTemplate = getMedicationTemplate(medicationTemplateName);
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddMedicationTemplateToOrders.json");

		// Update InsuranceCarrier Details
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "casePhysicianOrderId", Integer.valueOf(this.mapWebServiceResponses.get(IWebServiceResponseKeys.casePhysicianOrderId).toString()));
		obj = jsonUtils.updateOneJsonElement(obj.toString(), "moduleId", Integer.valueOf(moduleId));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.medicationName", medicationTemplate.getString("medication"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.templateName", medicationTemplate.getString("templateName"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.templateId", medicationTemplate.getInt("medicationTemplateId"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.compoundMedicationTf", medicationTemplate.getBoolean("compoundTf"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.dispensableDrugId", medicationTemplate.getString("dispensableDrugId"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.defaultETCID", medicationTemplate.getString("defaultETCID"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "medicationOrder.defaultETCDesc", medicationTemplate.getString("defaultETCDesc"));
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "nursingOrderTf", true);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "sortOrder", sortOrder);
		return new JSONObject(obj.toString());
	}

	protected Response addMedicationToOrders(String medicationNames, String departmentName) throws Exception {
		String moduleId = getModulesBycaseId(departmentName);
		String relURL = "/PhysicianOrdersDocumentation/CaseBaseOrders/" + moduleId;
		JSONArray orderMedicationTemplates = new JSONArray();
		for (int i = 0; i < medicationNames.split("[;]").length; i++) {
			String medicationName = medicationNames.split("[;]")[i];
			orderMedicationTemplates.put(getMedicationOrder(moduleId, medicationName, i));
		}
		Response response = runWebServiceRequest("application/json",orderMedicationTemplates.toString(), relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return response;
	}

	public JSONArray getMedicationsAddedToDepartment(String department) throws Exception {
		String moduleId = getModulesBycaseId(department);
		String relURL = "/PhysicianOrdersDocumentation/"+this.mapWebServiceResponses.get(IWebServiceResponseKeys.casePhysicianOrderId)+"/"+moduleId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONObject medicationOrders = new JSONObject(response.asString());
		JSONArray caseModuleOrderMaps = medicationOrders.getJSONArray("caseModuleOrderMaps");
		JSONObject caseModuleOrders = jsonUtils.getJSONObjectFromJSONArray(caseModuleOrderMaps, "moduleId", Integer.valueOf(moduleId));
		JSONArray medications = caseModuleOrders.getJSONArray("orders");
		return medications;
	}

	public void administerMedicationsInOrders(String department) throws Exception {
		JSONArray medications = getMedicationsAddedToDepartment(department);
		for(int i = 0; i < medications.length(); i++) {
			String relURL = "/PhysicianOrdersDocumentation/MedicationAdministration";
			Object obj = null;
			Object medicationObject = jsonUtils.getJSONObjectFromJSONArray(medications.toString(), i);
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/AdministerMedications.json");
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "dateTime", ReusableUtils.addDate("Today", "yyyy-MM-dd")+"T14:16:31.301Z");		
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "caseBaseOrderId", Integer.valueOf(jsonUtils.getValueFromJsonObject(medicationObject.toString(), "caseBaseOrderId").toString()));		
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "date", ReusableUtils.addDate("Today", "MM-dd-yyyy"));
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "time", "19:46:31");
			Response response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);						
			if (response.getStatusCode() == 200) {
				LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
						response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			} else {
				LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
						response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
			}			
		}
	}


	protected Object updateSuppliesopenholdvalues(Object obj, String openkey, String openvalue, String holdkey, String holdvalue, String areaofcareid, String delimiter, int index) {
		try {

			JSONObject jsonObj = new JSONObject();
			jsonObj.put("areaOfCareId", Integer.parseInt(areaofcareid));
			jsonObj.put("open", "");
			jsonObj.put("hold", "");
			obj = jsonUtils.updateOneJsonElement(obj.toString(), openkey, "");
			obj = jsonUtils.updateOneJsonElement(obj.toString(), holdkey, "");
			if(openvalue!=null && !openvalue.split(delimiter)[index].isEmpty()) {
				openvalue = openvalue.split(delimiter)[index];

				if(openvalue.equalsIgnoreCase("blank")) {
					openvalue = "";
				}
				obj = jsonUtils.updateOneJsonElement(obj.toString(), openkey, openvalue);
				jsonObj.put("open", openvalue);
			}

			if(holdvalue!=null && !holdvalue.split(delimiter)[index].isEmpty()) {
				holdvalue = holdvalue.split(delimiter)[index];
				if(openvalue.equalsIgnoreCase("blank")) {
					openvalue = "";
				}
				obj = jsonUtils.updateOneJsonElement(obj.toString(), holdkey, holdvalue);

				jsonObj.put("hold", holdvalue);

			}
			obj = jsonUtils.updateJSONObjwithChildOfJSONArry(obj, "quantities", jsonObj);
		}catch(Exception e) {
		}
		return obj;

	}
	public JSONObject retrieveContracts(String contractName) {
		String relURL = "/InsuranceContract/GetInsuranceContractList";
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray arr = new JSONArray(response.asString());
		return jsonUtils.getJSONObjectFromJSONArray(arr, "insuranceContractName", contractName);
	}

	protected JsonObject getEquipmentObject(JsonObject jsonObject, String equipmentByInventory, String equipmentName, String serialNumber, String notes) throws Exception {
		String DefequipmentName = "";
		if(equipmentByInventory != null) {
			for(int i = 0; i < equipmentByInventory.split("[,]").length; i++) {
				JsonObject equipmentObj = new JsonObject(); 
				try {
					DefequipmentName = equipmentName.split("[,]")[i];
				}catch(Exception e) {}
				if(equipmentByInventory.split("[,]")[i].equalsIgnoreCase("Y")) {
					getEquipmentDetails(DefequipmentName);
					equipmentObj.addProperty("Equipment", 0);
					equipmentObj.addProperty("ExternalIdentifier",  ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.equipmentExternalItemId));
					equipmentObj.addProperty("isKeySearchEnabled", true);
					equipmentObj.addProperty("inventoryNumber", ""+this.mapWebServiceResponses.get(IWebServiceResponseKeys.equipmentId));		

				} else {
					equipmentObj.addProperty("externalIdentifier", "");
					equipmentObj.addProperty("inventoryNumber", "");
					equipmentObj.addProperty("isKeySearchEnabled", false);
				}
				equipmentObj.addProperty("EquipmentText", "");
				equipmentObj.addProperty("SerialNumber", serialNumber.split("[,]")[i]);
				equipmentObj.addProperty("sortOrder", i);
				equipmentObj.addProperty("Notes", notes.split("[,]")[i]);
				equipmentObj.addProperty("EquipmentName", DefequipmentName);
				//if(jsonObject.getAsJsonArray("Questions").get(0).getAsJsonObject().getAsJsonArray("EquipmentUsedList").size()<1) {
				//	
				//}else {
				//	
				//}
				jsonObject.getAsJsonArray("Questions").get(0).getAsJsonObject().getAsJsonArray("EquipmentUsedList").add(equipmentObj);
			}
		}
		return jsonObject;

	}

	public Object updatePatientEmergencyContactDetails(Object obj, String patientEmergencyContactDetails) throws Exception {
		if (patientEmergencyContactDetails != null && !patientEmergencyContactDetails.isEmpty() && !patientEmergencyContactDetails.equalsIgnoreCase("blank")) {
			String[] emergencyContactDetails = null;

			emergencyContactDetails = patientEmergencyContactDetails.split("[,]");
			JSONObject emergencyContactDetailsObject = new JSONObject();
			String emergencyFirstName = emergencyContactDetails[0];
			if (!emergencyFirstName.equalsIgnoreCase("blank"))
				emergencyContactDetailsObject.put("firstName", emergencyFirstName);
			else
				emergencyContactDetailsObject.put("firstName", JSONObject.NULL);

			String emergencyLastName = emergencyContactDetails[2];
			if (!emergencyLastName.equalsIgnoreCase("blank"))
				emergencyContactDetailsObject.put("lastName", emergencyLastName);
			else
				emergencyContactDetailsObject.put("lastName", JSONObject.NULL);

			String emergencyMiddleName = emergencyContactDetails[1];
			if (!emergencyMiddleName.equalsIgnoreCase("blank"))
				emergencyContactDetailsObject.put("middleInitial", emergencyMiddleName);
			else
				emergencyContactDetailsObject.put("middleInitial", JSONObject.NULL);

			String emergencyRelationship = emergencyContactDetails[3];
			if (!emergencyRelationship.equalsIgnoreCase("blank"))
				emergencyContactDetailsObject.put("relationship", emergencyRelationship);
			else
				emergencyContactDetailsObject.put("relationship", JSONObject.NULL);

			String emergencyPhoneNumber = emergencyContactDetails[4];
			if (!emergencyPhoneNumber.equalsIgnoreCase("blank"))
				emergencyContactDetailsObject.put("phoneHome", emergencyPhoneNumber);
			else
				emergencyContactDetailsObject.put("phoneHome", JSONObject.NULL);
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "emergencyContact", emergencyContactDetailsObject);

		}
		return obj;
	}

	public Object updatePatientPhoneDetails(Object obj, String patientPhoneDetails) throws Exception {
		if (patientPhoneDetails != null && !patientPhoneDetails.isEmpty()  && !patientPhoneDetails.equalsIgnoreCase("blank")) {
			String[] phoneDetails = null;
			phoneDetails = patientPhoneDetails.split("[,]");
			JSONObject phoneDetailsObject = new JSONObject();
			String primaryPhone = phoneDetails[0];
			if (!primaryPhone.equalsIgnoreCase("blank"))
				phoneDetailsObject.put("phoneNumber", primaryPhone);
			else
				phoneDetailsObject.put("phoneNumber", JSONObject.NULL);
			String primaryPhoneType = phoneDetails[1];
			if (!primaryPhoneType.equalsIgnoreCase("blank"))
				phoneDetailsObject.put("phoneType", primaryPhoneType);
			else
				phoneDetailsObject.put("phoneType", JSONObject.NULL);
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "mpiPatientPhone", phoneDetailsObject);
		}
		return obj;
	}

	public Object updatePatientAdditionalDetails(Object obj, String patientAdditionalDetails, String firstName, String lastName) throws Exception {
		if (patientAdditionalDetails != null && !patientAdditionalDetails.isEmpty() && !patientAdditionalDetails.equalsIgnoreCase("blank")) {
			String[] additionalDetails = null;
			additionalDetails = patientAdditionalDetails.split("[,]");
			String middleInitial = additionalDetails[1];

			if (!(middleInitial.equalsIgnoreCase("blank"))) {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullName", firstName + " " + middleInitial + ". " + lastName);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "middleInitial", middleInitial);
			} else {
				middleInitial = null;
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "middleInitial", null);
			}

			String alias = additionalDetails[2];
			if (!alias.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "alias", alias);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "alias", null);

			String ssn = additionalDetails[3];
			if (!ssn.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ssn", ssn);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ssn", null);

			String gender = additionalDetails[4];
			if (!gender.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "gender", gender);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "gender", null);

			String occupation = additionalDetails[5];
			if (!occupation.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "occupation", occupation);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "occupation", null);

			String dateOfBirth = additionalDetails[6];
			if (!dateOfBirth.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "dateOfBirth", dateOfBirth);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "dateOfBirth", null);

			String maritalStatus = additionalDetails[7];
			if (!maritalStatus.equalsIgnoreCase("blank")) {
				int maritalStatusId = getMaritalStatusId(maritalStatus);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "maritalStatus", maritalStatus);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "maritalStatusId", maritalStatusId);
			} else {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "maritalStatus", null);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "maritalStatusId", null);
			}

			String race = additionalDetails[8];
			if (!race.equalsIgnoreCase("blank")) {
				int raceId = getRaceId(race);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "race", race);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "raceId", raceId);
			} else {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "race", null);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "raceId", null);
			}

			String ethnicity = additionalDetails[9];
			if (!ethnicity.equalsIgnoreCase("blank")) {
				int ethnicityId = getEthnicityId(ethnicity);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ethnicity", ethnicity);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ethnicityId", ethnicityId);
			} else {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ethnicity", null);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "ethnicityId", null);
			}

			String language = additionalDetails[10];
			if (!language.equalsIgnoreCase("blank")) {
				int languageId = getLanguageId(language);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "patientLanguage", language);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "languageId", languageId);
			} else {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "patientLanguage", null);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "languageId", null);
			}

			String religion = additionalDetails[11];
			if (!religion.equalsIgnoreCase("blank")) {
				int religionId = getReligionId(religion);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "religion", religion);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "religionId", religionId);
				} else {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "religion", null);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "religionId", null);
			}

			String email = additionalDetails[12];
			if (!email.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "email", email);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "email", null);

			String title = additionalDetails[0];
			if (!title.equalsIgnoreCase("blank")) {
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "title", title);
				if(!(middleInitial == null))
					obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullNameWithTitle", firstName + ' ' + middleInitial + " " + lastName + ", " + title);
				else
					obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullNameWithTitle", firstName + " "  + lastName + ", " + title);
			} else {
				if(!(middleInitial == null))
					obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullNameWithTitle", firstName + " " + middleInitial + " " + lastName);
				else
					obj = jsonUtils.updateOneJsonElement(obj.toString(), "fullNameWithTitle", firstName + " " + lastName);
			}
		}
		return obj;
	}

	public Object updatePatientAddressDetails(Object obj, String patientAddressDetails) throws Exception  {
		if (patientAddressDetails != null && !patientAddressDetails.isEmpty() && !patientAddressDetails.equalsIgnoreCase("blank")) {
			String[] addressDetails = null;
			addressDetails = patientAddressDetails.split("[,]");
			JSONObject addressObject = new JSONObject();

			String addressLine1 = addressDetails[0];
			if (!addressLine1.equalsIgnoreCase("blank"))
				addressObject.put("line1", addressLine1);
			else
				addressObject.put("line1", JSONObject.NULL);

			String addressLine2 = addressDetails[1];
			if (!addressLine2.equalsIgnoreCase("blank"))
				addressObject.put("line2", addressLine2);
			else
				addressObject.put("line2", JSONObject.NULL);

			String addressType = addressDetails[2];
			if (!addressType.equalsIgnoreCase("blank"))
				addressObject.put("addressKindName", addressType);
			else
				addressObject.put("addressKindName", JSONObject.NULL);

			String city = addressDetails[3];
			if (!city.equalsIgnoreCase("blank"))
				addressObject.put("city", city);
			else
				addressObject.put("city", JSONObject.NULL);

			String state = addressDetails[4];
			if (!state.equalsIgnoreCase("blank"))
				addressObject.put("state", state);
			else
				addressObject.put("state", JSONObject.NULL);

			String county = addressDetails[5];
			if (!county.equalsIgnoreCase("blank"))
				addressObject.put("county", county);
			else
				addressObject.put("county", JSONObject.NULL);

			String country = addressDetails[6];
			if (!country.equalsIgnoreCase("blank"))
				addressObject.put("country", country);
			else
				addressObject.put("country", JSONObject.NULL);

			String zipCode = addressDetails[7];
			String extendedZipCode = addressDetails[8];
			if (!zipCode.equalsIgnoreCase("blank"))
				addressObject.put("zip", zipCode+""+extendedZipCode);
			else
				addressObject.put("zip", JSONObject.NULL);

			obj = jsonUtils.updateOneJsonElement(obj.toString(), "address", addressObject);
		}
		return obj;
	}

	public void updateCaseSummaryWithGuarantorAdditionalInformation(String guarantorAdditionalDetails) {
		String relURL = "/CaseSummaryComplex/Gemini/UpsertCaseSummary";
		if(guarantorAdditionalDetails != null && !guarantorAdditionalDetails.isEmpty() && !guarantorAdditionalDetails.equalsIgnoreCase("blank")) {
			JSONObject caseSummaryResponse = new JSONObject(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryResp).toString());
			JSONArray caseGuarantors = caseSummaryResponse.getJSONArray("caseGuarantor");
			JSONArray updatedCaseGuarantors = new JSONArray();
			for(int index = 0; index < caseGuarantors.length(); index++) {
				JSONObject caseGuarantor = caseGuarantors.getJSONObject(index);
				JSONObject patientGuarantor = caseGuarantor.getJSONObject("patientGuarantor");

				if(!(Integer.valueOf(patientGuarantor.get("patientId").toString()) == 0)) {
					String guarantorInformationMul = guarantorAdditionalDetails.split("[;]")[index];
					if(!guarantorInformationMul.equalsIgnoreCase("blank")) {
						String[] guarantorInformation = guarantorInformationMul.split("[,]");
						String guarantorGender = guarantorInformation[0];
						if (!guarantorGender.equalsIgnoreCase("blank"))
							patientGuarantor.put("gender", guarantorGender);
						else
							patientGuarantor.put("gender", JSONObject.NULL);

						String relationship = guarantorInformation[1];
						if (!relationship.equalsIgnoreCase("blank"))
							patientGuarantor.put("patientRelationship", relationship);
						else
							patientGuarantor.put("patientRelationship", JSONObject.NULL);

						String primaryPhone = guarantorInformation[2];
						if (!primaryPhone.equalsIgnoreCase("blank"))
							patientGuarantor.put("phoneNumber", primaryPhone);
						else
							patientGuarantor.put("phoneNumber", JSONObject.NULL);

						String address1 = guarantorInformation[3];
						if (!address1.equalsIgnoreCase("blank"))
							patientGuarantor.put("address1", address1);
						else
							patientGuarantor.put("address1", JSONObject.NULL);

						String address2 = guarantorInformation[4];
						if (!address2.equalsIgnoreCase("blank"))
							patientGuarantor.put("address2", address2);
						else
							patientGuarantor.put("address2", JSONObject.NULL);

						String city = guarantorInformation[5];
						if (city.equalsIgnoreCase("blank"))
							patientGuarantor.put("city", city);
						else
							patientGuarantor.put("city", JSONObject.NULL);

						String state = guarantorInformation[6];
						if (state.equalsIgnoreCase("blank"))
							patientGuarantor.put("state", state);
						else
							patientGuarantor.put("state", JSONObject.NULL);

						String zipCode = guarantorInformation[7];
						String extendedZipCode = guarantorInformation[8];
						if (!zipCode.equalsIgnoreCase("blank"))
							patientGuarantor.put("zip", zipCode+"-"+extendedZipCode);
						else
							patientGuarantor.put("zip", JSONObject.NULL);

						String dateToBeUpdated = guarantorInformation[9];
						if (!dateToBeUpdated.equalsIgnoreCase("blank"))
							patientGuarantor.put("dateOfBirth", dateToBeUpdated);
						else
							patientGuarantor.put("dateOfBirth", JSONObject.NULL);
					}

					caseGuarantor.put("patientGuarantor", patientGuarantor);
					updatedCaseGuarantors.put(caseGuarantor);
				} else {
					caseGuarantor.put("patientGuarantor", patientGuarantor);
					updatedCaseGuarantors.put(caseGuarantor);
				}
				caseSummaryResponse.put("caseGuarantor", updatedCaseGuarantors);
			}

			Response responseUpdatedCaseSummary = runWebServiceRequest("application/json", caseSummaryResponse.toString(), relURL,
					Method.POST);
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.caseSummaryResp, responseUpdatedCaseSummary.asString());

			if (responseUpdatedCaseSummary.getStatusCode() == 200) {
				LOG.info(String.format("Update Case Summary with guarantor additional details response-> %s", responseUpdatedCaseSummary.asString()));
				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + relURL, responseUpdatedCaseSummary.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			} else {
				LOG.error(String.format("%s - %s, URL - %s, Response - %d (%s)",
						IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
						this.baseURL + relURL, responseUpdatedCaseSummary.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
			}
		}
	}

	protected Response reqlockCasePatient() throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		JSONObject obj = new JSONObject();
		obj.put("CaseSummaryId", casesummaryId);
		obj.put("RecordLockTypeId", 15);
		String relURL = "Security/RecordLock/RequestLock";
		return runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
	}
	
	protected Response payerEligibilityReq() throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		int patientId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString());
		String relURL = "/Eligibility/PayerEligibility/send/"+casesummaryId+"/"+patientId+"/1";
		return runWebServiceRequest("application/json", "", relURL, Method.POST);
	}
	
	protected Response relreaseLockPatient() throws Exception {
        int casesummaryId = Integer
                   .parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
        JSONObject obj = new JSONObject();
        obj.put("CaseSummaryId", casesummaryId);
        obj.put("RecordLockTypeId", 15);
        String relURL = "Security/RecordLock/ReleaseLock";
        return runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
 }

	protected JSONObject getPhysicianOpNotesById(String opNotesId) throws Exception {
		String relURL = "/OpNoteDocumentation/" + opNotesId;
		Response physicianOpNotesResp = runWebServiceRequest("application/json", "", relURL, Method.GET);
		return new JSONObject(physicianOpNotesResp.asString());
	}

	protected void addOPNotesToPatient(String opNotes) throws Exception {		
		String relURL = "/OpNoteDocumentation/CreateFromTemplate/";
		String relURL1 = "/OpNoteDocumentation/";
		String caseSummaryId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString();		
		for(int i = 0; i < opNotes.split("[;]").length; i++ ) {   
			String opNote = opNotes.split(";")[i];
			getPhysicianOpNotesDetails(opNote);        	
			String opNoteId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.physicianOpNotesId).toString();
			Response response = runWebServiceRequest("application/json", caseSummaryId, relURL + opNoteId, Method.POST);

			JSONObject physicianOpNotes = getPhysicianOpNotesById(response.asString());
			JSONObject textObject = physicianOpNotes.getJSONObject("textObject");
			JSONObject variableObject = physicianOpNotes.getJSONObject("variableObject");

			Object obj = null;
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/opNotesUpdateRequest.json");

			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "opNoteId", response.asString());
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId", Integer.valueOf(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString()));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "opNoteName",physicianOpNotes.getString("opNoteName"));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "percentageCompleted", 100);
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "textObject.opNoteId", response.asString());
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "textObject.noteText", ReusableUtils.encodeString2Base64(textObject.getString("noteText")));
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "variableObject.opNoteId", response.asString());
			obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "variableObject.serializedVariables", ReusableUtils.encodeString2Base64(variableObject.get("serializedVariables").toString()));

			response = runWebServiceRequest("application/json", obj.toString(), relURL1, Method.PUT);
		}
	}
	
	protected void getRequestForInsuranceContractReviews() throws Exception {
		String relURL = "/InsuranceContract/GetInsuranceContractReviews/" + this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceContractID).toString();
		runWebServiceRequest("application/json","", relURL, Method.GET);
	}

	protected void getRequestForInsuranceContractReviewsFromFeeSchedule() throws Exception {
		String relURL = "/InsuranceContract/GetInsuranceContractReviewsFromFeeSchedule/" + this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceContractID).toString();
		runWebServiceRequest("application/json","", relURL, Method.GET);
	}
	
	protected int getMaritalStatusId(String maritalStatus) throws Exception {
		Map<String, Integer> maritalStatusIds = new HashMap<String, Integer>();
		maritalStatusIds.put("divorced", 1);
		maritalStatusIds.put("legally separated", 2);
		maritalStatusIds.put("life partner", 3);
		maritalStatusIds.put("married", 4);
		maritalStatusIds.put("single", 5);
		maritalStatusIds.put("unknown", 6);
		maritalStatusIds.put("widowed", 7);

		if(maritalStatusIds.containsKey(maritalStatus.toLowerCase())) {
			return maritalStatusIds.get(maritalStatus.toLowerCase());
		} else {
			throw new RuntimeException("Marital Status "+maritalStatus+" is invalid ");
		}
	}

	protected int getEthnicityId(String ethnicity) throws Exception {
		Map<String, Integer> ethnicityIds = new HashMap<String, Integer>();
		ethnicityIds.put("hispanic", 1);
		ethnicityIds.put("non-hispanic", 2);
		ethnicityIds.put("unknown", 3);

		if(ethnicityIds.containsKey(ethnicity.toLowerCase())) {
			return ethnicityIds.get(ethnicity.toLowerCase());
		} else {
			throw new RuntimeException("Ethnicity "+ethnicity+" is invalid ");
		}
	}

	protected int getRaceId(String race) {
		String relURL = "Dictionary/v2/151/All";
				Response dictionaryItemResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
					org.json.JSONArray array = new org.json.JSONArray(dictionaryItemResponse.asString());
			for (int i = 0; i < array.length(); i++) {
				JSONObject dictionaryItem = array.getJSONObject(i);
				if (dictionaryItem.getString("value").equalsIgnoreCase(race)) {
					return dictionaryItem.getInt("id");
				}
			}
		throw new RuntimeException("Race "+race+" is invalid ");
	}
	
	protected int getReligionId(String religion) {
		String relURL = "Dictionary/v2/160/All";
		Response dictionaryItemResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		org.json.JSONArray array = new org.json.JSONArray(dictionaryItemResponse.asString());
			for (int i = 0; i < array.length(); i++) {
				JSONObject dictionaryItem = array.getJSONObject(i);
				if (dictionaryItem.getString("value").equalsIgnoreCase(religion)) {
					return dictionaryItem.getInt("id");
				}
			}			
		throw new RuntimeException("Religion "+religion+" is invalid ");
	}

	protected int getLanguageId(String language) {
		String relURL = "Dictionary/v2/150/All";
		Response dictionaryItemResponse = runWebServiceRequest("application/json", "", relURL, Method.GET);
		org.json.JSONArray array = new org.json.JSONArray(dictionaryItemResponse.asString());
			for (int i = 0; i < array.length(); i++) {
				JSONObject dictionaryItem = array.getJSONObject(i);
				if (dictionaryItem.getString("value").equalsIgnoreCase(language)) {
					return dictionaryItem.getInt("id");
				}
			}
		throw new RuntimeException("Language"+language+" is invalid ");
	}

	protected void savePatientEmployer(Object object) {
		String relURL = "/PatientEmployer/SavePatientEmployer";
		Response response = runWebServiceRequest("application/json", object.toString(), relURL, Method.POST);
		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
	}

	protected void lockPatientrecord(String patientId) throws Exception{
		JSONObject recordLock = new JSONObject();
		recordLock.put("PatientId", Integer.valueOf(patientId));
		recordLock.put("RecordLockTypeId", 13);
		recordLock.put("ObjectId", Integer.valueOf(patientId));
		recordLock.put("ModuleId", 2030);
		String relURL = "Security/RecordLock/RequestLock";
		Response response = runWebServiceRequest("application/json", recordLock.toString(), relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}

		LOG.info(String.format("Lock Patient Record "));
	}

	protected void unlockPatientrecord(String patientId) throws Exception{
		JSONObject recordLock = new JSONObject();
		recordLock.put("PatientId", Integer.valueOf(patientId));
		recordLock.put("RecordLockTypeId", 13);
		recordLock.put("ObjectId", Integer.valueOf(patientId));
		recordLock.put("ModuleId", 2030);
		String relURL = "Security/RecordLock/ReleaseLock";
		Response response = runWebServiceRequest("application/json", recordLock.toString(), relURL, Method.POST);

		if (response.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					response.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		LOG.info(String.format("Unlock Patient Record "));
	}

	protected void updatePatientEmployerDetails(Object object, String patientEmployerDetails) throws Exception {
		
			Object obj = null;
			String[] employerDetails = patientEmployerDetails.split("[,]");
			String relURL  = "/PatientData/Gemini/CreatePatient/2030";

			object = this.mapWebServiceResponses.get(IWebServiceResponseKeys.createjustaPatientResp);
			obj = jsonUtils.getJsonFileAsObject("reqTemplates/patientEmployer.json");
			obj = jsonUtils.updateOneJsonElement(obj.toString(), "patientId", Integer.valueOf(jsonUtils.getValueFromJsonObject(object.toString(), "patientId")));

			String employerName =  employerDetails[0];
			if (!employerName.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "employerName", employerName);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "employerName", null);

			String address =  employerDetails[1];
			if (!address.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "address", address);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "address", null);

			String city =  employerDetails[2];
			if (!city.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "city", city);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "city", null);

			String state =  employerDetails[3];
			if (!state.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "state", state);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "state", null);

			String country =  employerDetails[4];
			if (!country.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "country", country);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "country", null);

			String zip =  employerDetails[5];
			if (!zip.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "zip", zip);
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "zip", null);

			String phoneNumber =  employerDetails[6];
			if (!phoneNumber.equalsIgnoreCase("blank"))
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "phoneNumber", Long.valueOf(phoneNumber));
			else
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "phoneNumber", null);

			savePatientEmployer(obj);

			object = jsonUtils.updateOneJsonElement(jsonUtils.returnJsonObjectFromString(object.toString()), "employer", jsonUtils.returnJsonObjectFromString(obj.toString()));

			lockPatientrecord(jsonUtils.getValueFromJsonObject(object.toString(), "patientId"));
			Response responseUpdatedPatientEmployer = runWebServiceRequest("application/json", object.toString(), relURL,
					Method.POST);
			unlockPatientrecord(jsonUtils.getValueFromJsonObject(object.toString(), "patientId"));
			this.mapWebServiceResponses.put(IWebServiceResponseKeys.createjustaPatientResp, responseUpdatedPatientEmployer.asString());
			if (responseUpdatedPatientEmployer.getStatusCode() == 200) {
				LOG.info(String.format("Update patient with employer details -> %s", responseUpdatedPatientEmployer.asString()));
				LOG.info(String.format("%s - %s, URL - %s, Response - %d (%s)", IWebServiceResponseKeys.LOGICAL_WS_NAME,
						ReusableUtils.getCallingMethodName(), this.baseURL + relURL, responseUpdatedPatientEmployer.getStatusCode(),
						IWebServiceResponseKeys.WS_STATUS_SUCCESS));
			} else {
				LOG.error(String.format("%s - %s, URL - %s, Response - %d (%s)",
						IWebServiceResponseKeys.LOGICAL_WS_NAME, ReusableUtils.getCallingMethodName(),
						this.baseURL + relURL, responseUpdatedPatientEmployer.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
			}
		}
	
	protected Object insertAreaOfCareinforamtion_Operative(String admitSourceValue,String procedureDt ) throws Exception {
		String relURL = "AreaCareInformation/InsertAreaCareInformation";
		procedureDt = ReusableUtils.addDate(procedureDt, "yyyy-MM-dd");
		// API to UpdateAreaCareInformation
		Object obj = null;
		obj = jsonUtils.getJsonFileAsObject("reqTemplates/insertAreaOfCareinforamtion_Operative.json");
	
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "caseSummaryId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "moduleId",
				1020);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "admissionTime",
				procedureDt + "T" + ReusableUtils.getDate("hh:mm") + ":00+05:30");
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "admitSourceValue",admitSourceValue);
		obj = jsonUtils.updateObjectJsonXpath(obj.toString(), "patientId",
				this.mapWebServiceResponses.get(IWebServiceResponseKeys.patientId).toString());

		Response insertAreaCareInformation_PreOP = runWebServiceRequest("application/json", obj.toString(), relURL,
				Method.POST);
		if (insertAreaCareInformation_PreOP.getStatusCode() == 200) {
			LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertAreaCareInformation_PreOP.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_SUCCESS));
		} else {
			LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL,
					insertAreaCareInformation_PreOP.getStatusCode(), IWebServiceResponseKeys.WS_STATUS_FAILURE));
		}
		return insertAreaCareInformation_PreOP;
	}
	

	protected Response requestLock(int moduleId) throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		
		JSONObject request = new JSONObject();
		String relURL = "Security/RecordLock/RequestLock";
		request.put("casesummaryId", casesummaryId);
		request.put("RecordLockTypeId", 16);
		request.put("moduleId", moduleId);
		LOG.info(String.format("requestLock"));
		return runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
	}
	
	protected Response requestLock(String departmentname) throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		
		JSONObject request = new JSONObject();
		String relURL = "Security/RecordLock/RequestLock";
		request.put("casesummaryId", casesummaryId);
		request.put("RecordLockTypeId", 16);
		int moduleid= Integer.parseInt(getModulesBycaseId(departmentname));
		request.put("moduleId", moduleid);
		LOG.info(String.format("requestLock"));
		return runWebServiceRequest("application/json", request.toString(), relURL, Method.POST);
	}
	
	protected Response releaseLockPatient(String departmentName) throws Exception {
		int casesummaryId = Integer
				.parseInt(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString());
		JSONObject obj = new JSONObject();
		obj.put("CaseSummaryId", casesummaryId);
		obj.put("RecordLockTypeId", 16);
		int moduleid= Integer.parseInt(getModulesBycaseId(departmentName));
		obj.put("moduleId", moduleid);
		String relURL = "Security/RecordLock/ReleaseLock";
		return runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
	}
	
	protected String getdischargedToLocationIdByvalue(String dischargetovalue) throws Exception {
		String relURL = "/Dictionary/v2/6/All";
		LOG.info(String.format(" getdischargedToLocationIdByvalue "));
		String dischargedToLocationId = null;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		JSONArray dischargedToLocationIdary = jsonUtils.returnJsonArrayFromString(response.asString());
		LOG.info(String.format("dischargedToLocationIdary - %s", dischargedToLocationIdary));
		JSONObject dischargedToLocationIdjson1 = jsonUtils.getJSONObjectFromJSONArray(dischargedToLocationIdary, "value", dischargetovalue);
		dischargedToLocationId = jsonUtils.getValueFromJsonObject(dischargedToLocationIdjson1.toString(), "id");
		LOG.info(String.format("dischargedToLocationId - %s", dischargedToLocationId));
		return dischargedToLocationId;

	}
	
	protected String getImplantsFromPreferenceCard(String preferenceCardName) throws Exception {
		isPreferenceCardPresent(preferenceCardName);
		String preferenceCardId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.preferebceCardId).toString();
		String relURL = "/PreferenceCardConfig/GetPreferenceCardConfigChildsList?preferenceCardId=" + preferenceCardId;
		Response response = runWebServiceRequest("application/json", "", relURL, Method.GET);
		return response.asString();
	}
}
