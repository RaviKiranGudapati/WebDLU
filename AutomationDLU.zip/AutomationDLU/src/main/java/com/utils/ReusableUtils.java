/**
 * @author DPradhan
 * The Class ReusableUtils.
 * This is Utility Class With Only Static Utility Methods With No Instance Members And Static Variables
 * Thread Safety Has Been Addressed
 * Last Updated - 10 Apr 2020
 */

package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;

import com.parser.json.JSONFileParser;

/**
 * The Class ReusableUtils.
 * This is Utility Class With Only Static Utility Methods With No Instance Members And Static Variables
 * Thread Safety Has Been Addressed
 */
public class ReusableUtils {
	private static final Logger LOG = Logger.getLogger(ReusableUtils.class);


	public static Properties getConfigPropertyObject(String sFile) {
		try {
			Properties prop = new Properties();			
			FileInputStream file = new FileInputStream(sFile);
			InputStreamReader inputFileStreamReader = new InputStreamReader(file, "UTF-8");
			prop.load(inputFileStreamReader);
			inputFileStreamReader.close();
			file.close();
			LOG.debug(String.format("Properties Object Being Returned = %s", prop));
			return prop;

		} catch (Exception e) {

			LOG.error(e);
			LOG.info(String.format("Error Encountered - %s", e.getMessage()));
			return null;
		}
	}


	/**
	 * Gets the config property.
	 *
	 * @param sFile    the s file
	 * @param sKeyName the s key name
	 * @return the config property
	 */
	public static String getConfigProperty(String sFile, String sKeyName) {
		try {
			Properties prop = ReusableUtils.getConfigPropertyObject(sFile);
			String sValue = prop.getProperty(sKeyName);
			LOG.debug(String.format("FileName = %s, keyName = %s, keyValue = %s", sFile, sKeyName, sValue));
			return sValue;
		} catch (Exception e) {

			LOG.error(e);
			LOG.info(String.format("Error Encountered - %s", e.getMessage()));
			return null;
		}
	}

	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public static String getDate(String format) {
		try {
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			String dt = sdf.format(cal.getTime());
			return dt;
		} catch (Exception e) {
			LOG.debug(e);
			return null;
		}
	}
	
	/**
	 * Gets the date.
	 *
	 * @return the date
	 */
	public static String getDate(String sValue, String format) {
		try {
			String dt = addDate(sValue, format);
			return dt;
		} catch (Exception e) {
			LOG.debug(e);
			return null;
		}
	}
	

	/**
	 * Adds the date.
	 *
	 * @param sValue the s value
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String addDate(String sValue) throws Exception {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String dt = sValue;

		if (sValue.trim().equalsIgnoreCase("Today")) {
			dt = sdf.format(cal.getTime());
		}

		if (sValue.trim().contains("Today_")) {
			String[] arrValues = sValue.split("_");
			int iDays = Integer.parseInt(arrValues[1]);
			cal.add(Calendar.DATE, iDays);
			dt = sdf.format(cal.getTime());
		}
		if (sValue.trim().contains("Today#")) {
			String[] arrValues = sValue.split("#");
			int iDays = Integer.parseInt(arrValues[1]);
			cal.add(Calendar.DATE, -iDays);
			dt = sdf.format(cal.getTime());
		}
		return dt;
	}
	
	
	/**
	 * File exists.
	 *
	 * @param sFileName the s file name
	 * @return true, if successful
	 */
	public static boolean fileExists(String sFileName) {
		try {
			File objFile = new File(sFileName);
			if (objFile.exists()) {
				return true;
			}
		}

		catch (Exception e) {
			LOG.error(e);

		}
		return false;
	}

	/**
	 * Make dir.
	 *
	 * @param sFileName the s file name
	 * @return true, if successful
	 */
	public static boolean makeDir(String sFileName) {
		try {
			if (!fileExists(sFileName)) {
				File objFile = new File(sFileName);
				objFile.mkdir();
				return true;
			}
		}

		catch (Exception e) {
			LOG.error(e);

		}
		return false;
	}

	/**
	 * Gets the localized key value.
	 *
	 * @param locale the locale
	 * @param sbaseName the sbase name
	 * @param sKey the s key
	 * @return the localized key value
	 */
	public static String getLocalizedKeyValue(Locale locale, String sbaseName, String sKey) {
		String keyValue = null;
		try {
			ResourceBundle resourceBundle = ResourceBundle.getBundle(sbaseName, locale);
			keyValue = resourceBundle.getString(sKey);
		} catch (Exception e) {
			LOG.error(e);
		}
		return keyValue;
	}

	/**
	 * Gets the response code.
	 *
	 * @param url the url
	 * @return the response code
	 * @throws MalformedURLException the malformed URL exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static int getResponseCode(String url) throws MalformedURLException, IOException {
		HttpURLConnection httpUrlConn = (HttpURLConnection) new URL(url).openConnection();
		httpUrlConn.setRequestMethod("HEAD");
		httpUrlConn.connect();
		int respCode = httpUrlConn.getResponseCode();
		return respCode;

	}

	/**
	 * Gets the Encoded String
	 * @param text2Encode the text to be encoded
	 * @return the encoded String
	 */
	public static String encodeString2Base64(String text2Encode) {
		String BasicBase64format = Base64.getEncoder().encodeToString(text2Encode.getBytes());
		LOG.info(String.format("Encoded String is - %s", BasicBase64format));
		return BasicBase64format;

	}

	/**
	 * Gets the Decoded String
	 * @param encodedString the text to be Decoded
	 * @return the Decoded String
	 */
	public static String decodeBase642String(String encodedString) {
		byte[] byteArray = Base64.getDecoder().decode(encodedString.getBytes());
		String decodedString = new String(byteArray);
		LOG.info(String.format("Decoded String is - %s", decodedString));
		return decodedString;

	}

	public static String generateRandomNumeric(int count) {
		return RandomStringUtils.randomNumeric(count);
	}
	
	public static String generateRandomAlphabet(int count) {
		return RandomStringUtils.randomAlphabetic(count);
	}
	
	public static String getCallingMethodName()
	{
		return Thread.currentThread().getStackTrace()[3].getMethodName();
	}
	
	/**
	 * Adds the date.
	 *
	 * @param sValue the s value
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String addDate(String sValue, String dateFormat) throws Exception {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		String dt = sValue;

		if (sValue.trim().equalsIgnoreCase("Today")) {
			dt = sdf.format(cal.getTime());
		}

		if (sValue.trim().contains("Today_")) {
			String[] arrValues = sValue.split("_");
			int iDays = Integer.parseInt(arrValues[1]);
			cal.add(Calendar.DATE, iDays);
			dt = sdf.format(cal.getTime());
		}
		if (sValue.trim().contains("Today#")) {
			String[] arrValues = sValue.split("#");
			int iDays = Integer.parseInt(arrValues[1]);
			cal.add(Calendar.DATE, -iDays);
			dt = sdf.format(cal.getTime());
		}
		return dt;
	}
	
	public static String[] splitStringBySeparator(String text, String separator) {
		if(text.contains(";")) {
			String[] textList = text.split("[;]");
			return textList;
		}
		return null;
	}
	
	public static String getValueFromArrayByIndex(JSONFileParser jsonFileParser, String[] array, int index) {
		if(array == null) {
			return "";
		} else if(index >= array.length) {
			index = array.length - 1;
		}
		String value = array[index]; 
		if(value.trim().startsWith("data.")) {
			value = jsonFileParser.getValueFromJsonObject(value);
		}
		return value;
	}
}