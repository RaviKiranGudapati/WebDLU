package com.config;

public interface ITestParamsConstants {

	String CONFIG_FILE = "ConfigFile.properties";

	/**** Configuration File Constant Parameters ****/
	String LOCATION_SEEDDATA_EXCEL = "locSeedDataExcel";
	String SEED_DATA_TYPE = "seedDataType";
	String COMMA_SEPARATED_DEPENDENT_SEED_DATA_TYPE = "seedDataTypeDependentCommaSeparated";
	String IF_TEST_DATA_JSON_FILE_TO_BE_CREATED = "ifTestDataJsonFileToCreatedFromExcelDataSheets";
	String LOCATION_TESTDATA_EXCEL = "locTestDataExcel";
	String LOCATION_TESTDATA_JSON = "locSeedDataJSON";
	String LOCATION_WEBSERVICE_TEMPLATES = "locWSTemplates";
	String GEMINI_WEBSERVICE_URL = "webserviceGeminiBaseURL";
	String EXTENT_TEST_VISIBILITY_MODE = "extentTestVisibilityMode";
	String SEEDDATA_EXECUTION_REPORT = "htmlReport";
	String EXTENT_CONFIG_FILE = "extentConfigFile";
	String COMMA_SEPARATED_SEEDDATA_SHEETS = "commaSeparatedSeedDataSheets";

}
