package com.seeddata;

import java.util.Map;

/**
 * @author DPradhan
 * The Class SeedData.
 */
public class SeedData {
	private String testCase = null;
	private int rowNumber = -1;
	Map<String, Map<String, String>> mapOperNameParamValueKVPair = null;

	/**
	 * Instantiates a new seed data.
	 *
	 * @param testCase the test case
	 * @param rowNumber the row number
	 * @param mapOperNameParamValueKVPair the map oper name param value KV pair
	 */
	public SeedData(String testCase, int rowNumber, Map<String, Map<String, String>> mapOperNameParamValueKVPair) {
		this.testCase = testCase;
		this.rowNumber = rowNumber;
		this.mapOperNameParamValueKVPair = mapOperNameParamValueKVPair;
	}

	/**
	 * Gets the test case.
	 *
	 * @return the test case
	 */
	public String getTestCase() {
		return this.testCase;
	}

	/**
	 * Gets the row number.
	 *
	 * @return the row number
	 */
	public int getRowNumber() {
		return this.rowNumber;
	}

	/**
	 * Gets the oper name param value KV pair.
	 *
	 * @return the oper name param value KV pair
	 */
	public Map<String, Map<String, String>> getOperNameParamValueKVPair() {
		return this.mapOperNameParamValueKVPair;
	}

	/**
	 * Sets the test case.
	 *
	 * @param testCase the new test case
	 */
	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}
	
	/**
	 * Sets the row number.
	 *
	 * @param rowNumber the new row number
	 */
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	/**
	 * Se oper name param value KV pair.
	 *
	 * @param mapOperNameParamValueKVPair the map oper name param value KV pair
	 */
	public void seOperNameParamValueKVPair(Map<String, Map<String, String>> mapOperNameParamValueKVPair) {
		this.mapOperNameParamValueKVPair = mapOperNameParamValueKVPair;
	}

	@Override
	public int hashCode() {
		return this.testCase.length() + this.rowNumber;
	}

	@Override
	public boolean equals(Object obj) {
		if ((obj instanceof SeedData) && ((SeedData) obj).testCase.equalsIgnoreCase(this.testCase)
				&& ((SeedData) obj).rowNumber == this.rowNumber) {
			return true;
		} else {
			return false;
		}
	}

}
