package com.seeddata;

import java.util.List;

public interface ISeedDataProcessor {
	
	String seedDataTypeLongTerm = "SD";
	String seedDataTypeShortTerm = "JIT";
	String testCaseColName = "TestCase";	
	String tesCasesFilterColName = "SeedDataType";
	
	
	public List<SeedData> getAllSeedData(String seedDataType);		
	public List<SeedData> getAllSeedData(String sheetName, String seedDataType);	
	public List<SeedData> getAllSeedData(String[] exclusiveSheetNames,  String seedDataType);
	

}
