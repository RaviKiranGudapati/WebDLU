/**
 * @author DPradhan
 */

package com.seeddata;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.parser.excel.ExcelParser;
import com.parser.excel.SISTestDataExcelParser;

/**
 * The Class WebServiceSeedDataProcessor.
 */
public class WebServiceSeedDataProcessor implements ISeedDataProcessor {

	private ExcelParser excelParser = null;
	private SISTestDataExcelParser sisTestDataExcelParser = null;
	private static final Logger LOG = Logger.getLogger(WebServiceSeedDataProcessor.class);

	public WebServiceSeedDataProcessor(String excelFilePath, String jsonFilePath) throws Exception {
		this.excelParser = new ExcelParser(excelFilePath, jsonFilePath);
		this.sisTestDataExcelParser = new SISTestDataExcelParser(excelFilePath);
	}

	/**
	 * Gets the all seed data.
	 *
	 * @param seedDataType the seed data type
	 * @return the all seed data
	 */
	public List<SeedData> getAllSeedData(String seedDataType) {

		List<SeedData> listSeedData = new ArrayList<SeedData>();
		// get all sheets
		List<String> listSheets = this.excelParser.getAllSheets();
		for (String sheetName : listSheets) {

			List<SeedData> listSheetWiseSeedData = this.getAllSeedData(sheetName, seedDataType);
			for (SeedData sd : listSheetWiseSeedData) {
				listSeedData.add(sd);
			}
		}

		return listSeedData;
	}

	/**
	 * Gets the all seed data.
	 *
	 * @param sheetName    the sheet name
	 * @param seedDataType the seed data type
	 * @return the all seed data
	 */
	public List<SeedData> getAllSeedData(String sheetName, String seedDataType) {
		List<SeedData> listSeedData = new ArrayList<SeedData>();
		// validate data type
		/*** This validation is removed, as we may have other type to handle those in special way
		if (!(seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeLongTerm)
				|| seedDataType.equalsIgnoreCase(ISeedDataProcessor.seedDataTypeShortTerm))) {
			throw new RuntimeException(String.format(
					"The Input Parameter - %s Is Not Valid. The Allowed Parameters Should Be One Among - %s, %s ",
					seedDataType, ISeedDataProcessor.seedDataTypeLongTerm, ISeedDataProcessor.seedDataTypeShortTerm));
		}
		***/

		// get All Columns after a column defined in 2nd parameter - SeedDataType
		List<String> colNames = this.excelParser.getAllColNames(sheetName, ISeedDataProcessor.tesCasesFilterColName);
		LOG.debug(String.format("Column Names To Be Parsed Are %s", colNames));

		// get all test cases for which data to be seeded
		// get test case row numbers
		Set<Integer> testCaseRowNums = this.sisTestDataExcelParser.getTestCaseRowNumbers(sheetName,
				ISeedDataProcessor.tesCasesFilterColName, seedDataType);

		LOG.debug(String.format("Rows Selected From Sheet - %s, Are - %s", sheetName, testCaseRowNums));
		// get those test cases
		for (int testCaseRowNum : testCaseRowNums) {
			// get test
			String testCase = this.excelParser.getCellData(sheetName, ISeedDataProcessor.testCaseColName,
					testCaseRowNum);
			LOG.debug(String.format("Test Case Selected - %s, At Row Number - %d ", testCase, testCaseRowNum));

			// get UsedRange
			List<Integer> usedRangeRowNums = this.excelParser.getUsedRangeRowNumbers(sheetName,
					ISeedDataProcessor.testCaseColName, testCase);
			LOG.debug(String.format("Used Range Of Rows For Test Case - %s", usedRangeRowNums));
			for (int usedRangeRowNum : usedRangeRowNums) {
				if (this.sisTestDataExcelParser.isRowSeededOrJIT(sheetName, ISeedDataProcessor.tesCasesFilterColName,
						seedDataType, usedRangeRowNum)) {
					Map<String, Map<String, String>> mapColSubColDataPair = new LinkedHashMap<String, Map<String, String>>();
					// for each column header
					for (String colName : colNames) {

						// Empty Columns Will Be Ignored
						if (!this.excelParser.isColumnEmpty(sheetName, colName, usedRangeRowNum)) {
							Map<String, String> mapSubColDataPair = new LinkedHashMap<String, String>();
							// get spannedcolumnNumbers
							List<Integer> listSpannedColNums = this.excelParser.getMergedColNumbers(sheetName, colName);
							LOG.debug(String.format("Spanned Column Numbers For Column - %s - %s", colName,
									listSpannedColNums));
							// for each sub column
							for (int colNum : listSpannedColNums) {
								// get sub column Name
								String subColName = this.excelParser.getCellData(sheetName, colNum, 2);
								LOG.debug(String.format("Column - %s Has Sub Column - %s At column Number - %d",
										colName, subColName, colNum));

								String testColData = this.excelParser.getCellData(sheetName,
										ISeedDataProcessor.testCaseColName, testCase, colName, subColName,
										usedRangeRowNum);
								LOG.debug(String.format(
										"Text At row number - %d, for %s at colName - %s, subColName - %s = %s",
										usedRangeRowNum, testCase, colName, subColName, testColData));
								// get subcol Name and subcol data into keypair
								mapSubColDataPair.put(subColName, testColData);
								LOG.debug(String.format(
										"map for subColName - %s and testColData - %s Was Added To Map - %s ",
										subColName, testColData, "mapSubColDataPair"));

							}

							mapColSubColDataPair.put(colName, mapSubColDataPair);
							LOG.debug(String.format("map for colName - %s and map - %s Was Added To Map - %s ", colName,
									"mapSubColDataPair", "mapColSubColDataPair"));
						}
					}
					SeedData sd = new SeedData(testCase, usedRangeRowNum, mapColSubColDataPair);
					LOG.debug(String.format("Seed Data Was Created With Information - %s ", sd));
					listSeedData.add(sd);
					LOG.debug(String.format("Seed Data Was Added To List - %s", "listSeedData"));
				}
			}

		}

		return listSeedData;

	}

	/**
	 * Gets the all seed data.
	 *
	 * @param exclusiveSheetNames the exclusive sheet names
	 * @param seedDataType        the seed data type
	 * @return the all seed data
	 */
	public List<SeedData> getAllSeedData(String[] exclusiveSheetNames, String seedDataType) {
		List<SeedData> listSeedData = new ArrayList<SeedData>();
		// ignore sheet names
		List<String> listSheets = this.excelParser.getAllSheets(exclusiveSheetNames);

		for (String sheetName : listSheets) {

			List<SeedData> listSheetWiseSeedData = this.getAllSeedData(sheetName, seedDataType);
			for (SeedData sd : listSheetWiseSeedData) {
				listSeedData.add(sd);
			}
		}

		return listSeedData;
	}

}
