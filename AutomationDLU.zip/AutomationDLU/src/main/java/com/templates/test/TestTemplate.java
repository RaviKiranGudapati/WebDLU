/**
 * 22/07/2020, Debasish, Updated method - getSeedData being used for dataprovider to read seeddatatype available in comma separated format in test configuration file. SeedDataType can be in format - SDToBeAdded,JIT
 */
/**
 * @author DPradhan
 */
package com.templates.test;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.xml.XmlTest;

import com.config.ITestParamsConstants;
import com.parser.excel.SISTestDataExcelParser;
import com.parser.textfile.PropertiesFileParser;
import com.report.ExtentReporter;
import com.report.ExtentReporter.ExtentTestVisibilityMode;
import com.report.IReporter;
import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import com.seeddata.WebServiceSeedDataProcessor;
import com.utils.JsonUtils;
import com.utils.ReusableUtils;

public abstract class TestTemplate {

	private static final Logger LOG = Logger.getLogger(TestTemplate.class);
	private static IReporter testReport = null;
	private String excelSeedDataFilePath = null;
	private String seedDataType = null;
	private String seedDataTypeDependentCommaSeparated = null;
	private String commaSeparatedSeedDataSheets = null;
	private String ifTestDataJsonFileToBeCreatedFromExcelDataSheets = null;
	private String excelTestDataFilePath = null;
	private String jsonTestDataFilePath = null;
	private PropertiesFileParser prop = null;
	private String geminiWebServiceBaseURL = null;

	protected String getExcelSeedDataFilePath() {
		return this.excelSeedDataFilePath;
	}

	protected String getSeedDataType() {
		return this.seedDataType;
	}

	protected String getSeedDataTypeDependentCommaSeparated() {
		return this.seedDataTypeDependentCommaSeparated;
	}

	protected String getCommaSeparatedSeedDataSheets() {
		return this.commaSeparatedSeedDataSheets;
	}

	protected String ifTestDataJSONFileToBeCreated() {
		return this.ifTestDataJsonFileToBeCreatedFromExcelDataSheets;
	}

	protected String getExcelTestDataFilePath() {
		return this.excelTestDataFilePath;
	}

	protected String getJsonTestDataFilePath() {
		return this.jsonTestDataFilePath;
	}

	protected PropertiesFileParser getPropertiesFileParser() {
		return this.prop;
	}

	protected IReporter getTestReporter() {
		return TestTemplate.testReport;
	}

	protected String getGeminiWebServiceBaseURL() {
		return this.geminiWebServiceBaseURL;
	}

	/**
	 * Gets the suite parameter.
	 *
	 * @param testContext the test context
	 * @param parameter   the parameter
	 * @return the suite parameter
	 */
	protected String getSuiteParameter(ITestContext testContext, String parameter) {
		String propertyFile = testContext.getSuite().getParameter("CONFIG_FILE") == null
				? ITestParamsConstants.CONFIG_FILE
				: testContext.getCurrentXmlTest().getParameter("CONFIG_FILE");
		String parameterVal = testContext.getSuite().getParameter(parameter) == null
				? ReusableUtils.getConfigProperty(propertyFile, parameter)
				: testContext.getCurrentXmlTest().getSuite().getParameter(parameter).trim();
		LOG.info(String.format("Suite Execution Input Parameter = %s, Value = %s", parameter, parameterVal));
		return parameterVal;
	}

	/**
	 * get parameter from either test context or framework configuration file where
	 * test context parameter overrides framework configuration parameter
	 * 
	 * @param testContext
	 * @param parameter
	 * @return
	 */
	protected String getTestParameter(ITestContext testContext, String parameter) {
		String parameterVal = testContext.getCurrentXmlTest().getParameter(parameter) == null
				? this.prop.getConfigProperty(parameter)
				: testContext.getCurrentXmlTest().getParameter(parameter).trim();
		LOG.info(String.format("Test Execution Input Parameter = %s, Value = %s", parameter, parameterVal));
		return parameterVal;
	}

	@BeforeSuite
	protected void beforeSuite(ITestContext testContext, XmlTest xmlTest) throws Exception {
		LOG.info(String.format("Suite To Be Executed Next -  %s", testContext.getSuite().getName()));

		// Test Report
		String filePath = this.getSuiteParameter(testContext, ITestParamsConstants.SEEDDATA_EXECUTION_REPORT);
		String extentConfigFile = this.getSuiteParameter(testContext, ITestParamsConstants.EXTENT_CONFIG_FILE);
		String extentTestVisibilityMode = this.getSuiteParameter(testContext,
				ITestParamsConstants.EXTENT_TEST_VISIBILITY_MODE);
		TestTemplate.testReport = new ExtentReporter(filePath, extentConfigFile, false, false,
				ExtentTestVisibilityMode.valueOf(extentTestVisibilityMode));

		this.excelSeedDataFilePath = this.getSuiteParameter(testContext, ITestParamsConstants.LOCATION_SEEDDATA_EXCEL);
		this.commaSeparatedSeedDataSheets = this.getSuiteParameter(testContext,
				ITestParamsConstants.COMMA_SEPARATED_SEEDDATA_SHEETS);
		this.excelTestDataFilePath = this.getSuiteParameter(testContext, ITestParamsConstants.LOCATION_TESTDATA_EXCEL);
		this.jsonTestDataFilePath = this.getSuiteParameter(testContext, ITestParamsConstants.LOCATION_TESTDATA_JSON);

		// JSON File Creation At Suite Level Before Running Any Test
		this.ifTestDataJsonFileToBeCreatedFromExcelDataSheets = this.getSuiteParameter(testContext,
				ITestParamsConstants.IF_TEST_DATA_JSON_FILE_TO_BE_CREATED);

		if (this.ifTestDataJsonFileToBeCreatedFromExcelDataSheets.equalsIgnoreCase("Yes")) {

			SISTestDataExcelParser testDataExcelParser = new SISTestDataExcelParser(this.excelTestDataFilePath,
					this.commaSeparatedSeedDataSheets.split(","));
			JSONObject jo = testDataExcelParser.convertToJSONObjectWithExcludedFiles();
			new JsonUtils().writeJSONObjectToFile(jo, this.jsonTestDataFilePath);
		}

	}

	@AfterSuite
	protected void afterSuite(ITestContext testContext) {
		LOG.info(String.format("Suite - %s , Completed", testContext.getSuite().getName()));
		TestTemplate.testReport.updateTestCaseStatus();
	}

	/**
	 * Configuration/Initialization before running each test
	 * 
	 * @param testContext
	 */
	@BeforeTest
	protected void beforeTest(ITestContext testContext) {
		LOG.info(String.format("Thread - %d, Executes Next Test - %s ", Thread.currentThread().getId(),
				testContext.getCurrentXmlTest().getName()));

		// Test Parameters
		String propertiesFilePath = testContext.getCurrentXmlTest().getParameter("CONFIG_FILE") == null
				? ITestParamsConstants.CONFIG_FILE
				: testContext.getCurrentXmlTest().getParameter("CONFIG_FILE");
		this.prop = new PropertiesFileParser(propertiesFilePath);
		this.seedDataType = this.getTestParameter(testContext, ITestParamsConstants.SEED_DATA_TYPE);
		this.seedDataTypeDependentCommaSeparated = this.getTestParameter(testContext,
				ITestParamsConstants.COMMA_SEPARATED_DEPENDENT_SEED_DATA_TYPE);
		this.geminiWebServiceBaseURL = this.getTestParameter(testContext, ITestParamsConstants.GEMINI_WEBSERVICE_URL);

		// Test Initialization
		if (((ExtentReporter) TestTemplate.testReport)
				.getExtentTestVisibilityMode() == ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
			TestTemplate.testReport
					.createTestNgXMLTestTag(String.format("%s", testContext.getCurrentXmlTest().getName()));

		}
	}

	/**
	 * Configuration/Initialization after running each test
	 * 
	 * @param testContext
	 */
	@AfterTest
	protected void afterTest(ITestContext testContext) {
		LOG.info(String.format("Test - %s , Completed", testContext.getCurrentXmlTest().getName()));
		TestTemplate.testReport.updateTestCaseStatus();
	}

	/**
	 * Configuration/Initialization before running each test case Driver is
	 * initialized before running each test method
	 * 
	 * @param testContext
	 * @param m
	 * @throws URISyntaxException
	 */
	/*
	 * @BeforeMethod protected void beforeMethod(ITestContext testContext, Method m)
	 * throws URISyntaxException {
	 * 
	 * LOG.info(String.format("Thread - %d , Executes Next Test Method - %s",
	 * Thread.currentThread().getId(), m.getName()));
	 * 
	 * if (TestTemplate.testReport instanceof ExtentReporter) { if
	 * (((ExtentReporter) TestTemplate.testReport) .getExtentTestVisibilityMode() ==
	 * ExtentTestVisibilityMode.TestNGTestTagAsTestsAtLeft) {
	 * TestTemplate.testReport.initTestCase(String.format("%s", m.getName())); }
	 * else if (((ExtentReporter) TestTemplate.testReport)
	 * .getExtentTestVisibilityMode() ==
	 * ExtentTestVisibilityMode.TestNGTestMethodsAsTestAtLeft) {
	 * TestTemplate.testReport .initTestCase(String.format("%s-%s",
	 * testContext.getCurrentXmlTest().getName(), m.getName())); } }
	 * TestTemplate.testReport.logInfo(String.
	 * format("Thread - %d , Executes Next Test Method - %s",
	 * Thread.currentThread().getId(), m.getName()));
	 * 
	 * }
	 */

	/**
	 * Configuration/Initialization after running each test case webdriver is killed
	 * after each test case execution
	 * 
	 * @param testContext
	 * @param testResult
	 * @param m
	 * @throws Exception
	 */

	/*
	 * @AfterMethod protected void afterMethod(ITestContext testContext, ITestResult
	 * testResult, Method m) throws Exception {
	 * LOG.info(String.format("Thread - %d , Completes Executing Test Method - %s",
	 * Thread.currentThread().getId(), m.getName()));
	 * TestTemplate.testReport.logInfo(String.
	 * format("Thread - %d , Completes Executing Test Method - %s",
	 * Thread.currentThread().getId(), m.getName()));
	 * TestTemplate.testReport.updateTestCaseStatus();
	 * 
	 * }
	 * 
	 */
	@DataProvider(name = "dpSeedData", parallel = true)
	protected Object[][] getSeedData() throws Exception {
		List<SeedData> listSeedData = new ArrayList<SeedData>();
		ISeedDataProcessor seedDataParser = new WebServiceSeedDataProcessor(this.getExcelSeedDataFilePath(),
				this.getJsonTestDataFilePath());
		String commaSeparatedSeedDataSheets = this.getCommaSeparatedSeedDataSheets();
		for (String sheetName : commaSeparatedSeedDataSheets.split(",")) {
			// Webservice with empty parameter values/columns with no value in excel sheet
			// column are not processed.
			for (String seedDataTypeToBeProcessed : this.getSeedDataType().split(",")) {
				for (SeedData sd : seedDataParser.getAllSeedData(sheetName, seedDataTypeToBeProcessed)) {
					listSeedData.add(sd);
				}
			}
		}
		Object[][] seedDataObjs = new Object[listSeedData.size()][];
		for (int cnt = 0; cnt < listSeedData.size(); cnt++) {
			seedDataObjs[cnt] = new Object[] { listSeedData.get(cnt) };
		}

		return seedDataObjs;
	}

	@DataProvider(name = "dpCustomDependentSeedDataInSequential")
	protected Object[][] getCustomSeedDataInSequential() throws Exception {
		List<SeedData> listSeedData = new ArrayList<SeedData>();
		ISeedDataProcessor seedDataParser = new WebServiceSeedDataProcessor(this.getExcelSeedDataFilePath(),
				this.getJsonTestDataFilePath());
		String commaSeparatedSeedDataSheets = this.getCommaSeparatedSeedDataSheets();
		for (String sheetName : commaSeparatedSeedDataSheets.split(",")) {
			// Webservice with empty parameter values/columns with no value in excel sheet
			// column are not processed.
			for (String customSeedDataType : this.getSeedDataTypeDependentCommaSeparated().split(",")) {
				for (SeedData sd : seedDataParser.getAllSeedData(sheetName, customSeedDataType)) {
					listSeedData.add(sd);
				}
			}
		}
		Object[][] seedDataObjs = new Object[listSeedData.size()][];
		for (int cnt = 0; cnt < listSeedData.size(); cnt++) {
			seedDataObjs[cnt] = new Object[] { listSeedData.get(cnt) };
		}

		return seedDataObjs;
	}
}
