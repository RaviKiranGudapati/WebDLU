package com.client.webservice;

/***********Revision History
 * 01/09/2020 Narasimha : Added a new Key areaOfCareInformationId for getAreaCareInformationsbyCase with departmentname method
 * 07/22/2020: Bhagya Raj/Narasimha: Added new key equipmentExternalItemId for equipment mapping
 * 07/08/2020: Abhishek/Bhagy: Added - Added new keys insuranceContractID,insuranceContractPostingID and discountId
 * 1. 07/07/2020, Bhavani, Changes - added new key - casePhysicianOrderId
 *
 */

public interface IWebServiceResponseKeys {

	/******Logging Purpose Constants******/

	String LOGICAL_WS_NAME = "Logical WS Name";
	String WS_STATUS_SUCCESS = "SUCCESSFUL";
	String WS_STATUS_FAILURE = "FAILURE";

	/**********************************/
	String keyToken = "token";
	String keyOrgId = "orgId";
	String insuranceCarrierId = "insuranceCarrierId";
	String insurancePlanSaveDetails = "insurancePlanSaveDetails";
	String insurancePlanId = "insurancePlanId";
	String createjustaPatientResp = "createjustaPatientResp";
	String patientId = "patinetId";
	String patientFirstName = "patientFirstName";
	String patientLastName = "patientLastName";
	String guarantorFirstName = "guarantorfirstName";
	String guarantorLastName = "guarantorLastName";
	String patientGuarantorId = "patientGuarantorId";
	String guarantorDob = "guarantorDob";
	String guarantorCountry = "guarantorCountry";
	String caseSummaryResp = "caseSummaryResp";
	String caseItemId = "caseItemId";
	String caseModuleId = "caseModuleId";
	String caseFormId = "formId";
	String caseFormUsageId = "caseFormUsageId";
	String caseFormName = "formName";
	String staffId = "staffId";
	String staffFullName = "staffFullName";
	String staffRoleId = "staffRoleId";
	String caseSummaryID = "caseSummaryID";
	String caseStartTime = "caseStartTime";
	String caseAppointmentId = "caseAppointmentId";	
	String casesToCodeResponse = "casesToCodeResponse";
	String chargeEntryResponse = "chargeEntryResponse";
	String chargeDetailsRespFromChargeEntry = "chargeDetailsRespFromChargeEntry";
	String allPeriods = "allPeriods";
	String period = "period"; 
	String batch = "batch"; 
	String worklistId = "worklistId";
	String dictionaryId = "dictionaryId";
	String dictionaryName = "dictionaryName";
	String dictionaryItemId = "dictionaryItemId";
	String casePackId = "casePackId";
	String casePackName = "casePackName";
	String physicianOrderId = "physicianOrderId";
	String physicianOpNotesId = "physicianOpNotesId";
	String consentsId = "consentsId";
	String dischargeInstrConfigurationId = "dischargeInstrConfigurationId";
	String physicianfullname = "physicianfullname";
	String physicianStaffId = "physicianStaffId";
	String opNoteId = "opNoteId";
	String implantId = "implantId";
	String supplyId = "supplyId";
	String equipmentId = "equipmentId";
	String feeScheduleId = "feeScheduleId";
	String personId = "personId";
	String usrId = "usrId";
	String profileLevelId = "profileLevelId";
	String profileAccessLevelName = "profileAccessLevelName";
	String roleId = "roleId";
	String roleName = "roleName";
	String businessfacilityId = "businessfacilityId";
	String insuranceClaimOfficeid = "insuranceClaimOfficeid";
	String sessionUserName = "sessionUserName";
	String ImplantExternalIdentifier = "ImplantExternalIdentifier";
	String ManufacturerExternalIdentifier = "ManufacturerExternalIdentifier";
	String patientsearchstr = "patientsearchstr";
	String appointmentType = "appointmentType";
	String cancelCaseWorklistTemplate = "cancelCaseWorklistTemplate";
	String preferebceCardId = "preferebceCardId";
	String insuranceContractID = "insuranceContractId";
	String insuranceContractPostingID = "insuranceContractPostingID";
	String discountId = "discountId";
	String casePhysicianOrderId = "casePhysicianOrderId";
	String equipmentExternalItemId = "equipmentExternalItemId";
	
	String primaryInsuranceId = "primaryInsuranceId";
	String secondaryInsuranceId = "secondaryInsuranceId";
	String tertiaryInsuranceId = "tertiaryInsuranceId";
	String areaOfCareInformationId = "areaOfCareInformationId";
}