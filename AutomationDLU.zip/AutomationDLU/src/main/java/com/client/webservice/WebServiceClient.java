/***********Revision History
 * 02/09/2020: Bhagy/Vandana: Added mapImplantToPatient to map preference card related implants to patient cases
 * 01/09/2020: Narasimha/Bhagy: Updated new Functional fields to handle Discharge_To_Value and Admit Source value During discharge hence Updated dischargePatient to handle Discharge to value and Admit source in PreOperative
 * 20/08/2020: Sujatha: Added updatePatientEmployerDetails() method for adding employer to patient and additional fields in updatePatientAdditionalDetails() method and added multiple physician for multiple cptCodes in updateCaseSumryObjWithMultipleCPTCodes() method and Added payerCode in updateStateReportInsurance() method. 
 * 11/08/2020: Bhagya Raj: Added method calls getRequestForInsuranceContractReviews(), getRequestForInsuranceContractReviewsFromFeeSchedule(); after creating contracts to work for populating charge
 * 10/08/2020 Bhavani : Added createPhysicianOpNotes, addOPNotesToPatient methods to handle OP Notes functionality
 * 04/08/2020 Bhagya/Vandana : Added getConsentDetails method in addConsent to handle existing consent values.
 * 31/07/2020 Bhagya Raj: updated addConsent method to add multiple statements for consents
 * 21/07/2020: Bhavani : Updated patientOperations to add additional details to patient such as patient address, patient emergency contact information, patient address,
 * 						 guarantor additional details such as gender, relationship, phone, address1, address2, city, state, zip, extended zip
 *                       insurance aditional details such as middle initial, title, date of birth, address1 , address2, group name, group number, city, state, zip, extended zip, country, phone number etc
 * 17/07/2020: Debasish : dischargePatient method was updated to take procedureDt. Exceptions were thrown from methods.
 * 16/07: Bhagy/Nidhi: Updated the full name to inculde the Mi in full name for search string firstName+" M. "+lastName
 * 15/07: Bhagy/Nidhi: Removed the unnecessary step patientsearchstr = "Pfnamegem"; which is failing while creating second case
 * 11/07: Bhagy/Narasimha: Updated the insurance to map the contract and quipment mapping to patients
 * 09/07: Saikiran: Updated discharge patient variable from userID to dischargeByUserName in method dischargePatient under patientOperations
 * 09/07: Bhavani: Updated patientOperations method to handle signing of the departments
 * 07/09/2020: Abhishek/Bhagy: Added - Added new switch case to handle addition of contracts (createInsuranceContract)
 * 07/07/2020, Bhavani, Changes - Updated medication creation to use search string for searching medications createMedication
 * 								   - Updated pre-operative worklist details addition addWorklistToPatient
 *
 */

package com.client.webservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.report.IReporter;
import com.seeddata.SeedData;
import com.utils.DbUtils;
import com.utils.ReUsableWebserviceUtils;
import com.utils.ReusableUtils;

import io.restassured.http.Method;
import io.restassured.response.Response;

public class WebServiceClient extends ReUsableWebserviceUtils {
	private static final Logger LOG = Logger.getLogger(WebServiceClient.class);

	public WebServiceClient(String baseURL) {
		super(baseURL, new HashMap<String, Object>());
	}

	public WebServiceClient(String baseURL, IReporter reporter) {
		super(baseURL, new HashMap<String, Object>(), reporter);

	}

	public void callWebService(SeedData sd) throws Exception {

		// get All Web Service References and corrosponding parameters/values pair in
		// Map form

		Map<String, Map<String, String>> wsNameAttrValPair = sd.getOperNameParamValueKVPair();
		// Key of wsNameAttrValPair contains web Service Key Word, Value Contains Map of
		// various parameters and its values

		// Iterate through each WebService Keyword and its attributes and Values Pair ,
		// In Sequence.
		// Iterator is ordered as per order in Excel Sheet, as implemented using Linked
		// Hash Map
		for (Entry<String, Map<String, String>> entryWsNameAttrValPair : wsNameAttrValPair.entrySet()) {
			// get webservice key word
			String webServiceReference = entryWsNameAttrValPair.getKey();

			// get webservice parmeters and values
			Map<String, String> subColNameValKP = entryWsNameAttrValPair.getValue();

			// Perform webservice call based on current webservice, coming in sequence
			switch (webServiceReference) {

			case "Room Details":
				// call Create Room Webservice
				this.createNewRoom(subColNameValKP.get("facility"), subColNameValKP.get("roomName"));
				break;

			case "InsuranceCreation":
				// call Create Insurance Webservice
				this.createInsurance(subColNameValKP.get("facility"), subColNameValKP.get("insuranceName"),
						subColNameValKP.get("planName"), subColNameValKP.get("insuranceClassification"),
						subColNameValKP.get("officeName"), subColNameValKP.get("line1"), subColNameValKP.get("city"),
						subColNameValKP.get("contactName"), subColNameValKP.get("phone"), subColNameValKP.get("zip"),
						subColNameValKP.get("extendedZip"), subColNameValKP.get("state"),
						Boolean.parseBoolean(subColNameValKP.get("generateTrue")), subColNameValKP.get("contractName"));
				break;

			case "PatientCreation":
				// call Create Patient webservice
				this.patientOperations(subColNameValKP.get("UserName"),subColNameValKP.get("Password"),subColNameValKP.get("facility"),subColNameValKP.get("patientsearchstr"), subColNameValKP.get("firstName"),
						subColNameValKP.get("lastName"), subColNameValKP.get("procedureDt"),
						subColNameValKP.get("physicianUser"), subColNameValKP.get("roomName"),
						subColNameValKP.get("startTime"), subColNameValKP.get("endTime"),
						subColNameValKP.get("appointmentType"), subColNameValKP.get("preferenceCardName"), subColNameValKP.get("cptCode"),
						subColNameValKP.get("lterality"),subColNameValKP.get("preOpDiagnosisCode"), subColNameValKP.get("guarantorFirstName"),
						subColNameValKP.get("guarantorLastName"), subColNameValKP.get("guarantorDateOfBirth"),
						subColNameValKP.get("guarantorCountry"), subColNameValKP.get("guarantorIsActive"),
						subColNameValKP.get("primaryGuarantor"), subColNameValKP.get("secondaryGuarantor"),
						subColNameValKP.get("Carriername"), subColNameValKP.get("RelationshiptoSubscriber"),
						subColNameValKP.get("InsurancefirstName"), subColNameValKP.get("InsurancelastName"),
						subColNameValKP.get("gender"), subColNameValKP.get("Subscriberid"),
						subColNameValKP.get("PreOPmedicationtemplates"),subColNameValKP.get("OPmedicationtemplates"),subColNameValKP.get("Recovmedicationtemplates"),
						subColNameValKP.get("WorklistWithDepartment"), subColNameValKP.get("ImplantsAndProsthesisByInventory"),	
						subColNameValKP.get("ImplantName"),	subColNameValKP.get("ManufacturerName"), subColNameValKP.get("OtherDetails"),
						subColNameValKP.get("SuppliesAndInstruments"),subColNameValKP.get("SupplyNames"),subColNameValKP.get("OtherSuppliesDetails"),
						subColNameValKP.get("equipmentByInventory"),subColNameValKP.get("equipmentName"),subColNameValKP.get("equipmentserialNumber"), subColNameValKP.get("equipmentnotes"),
						subColNameValKP.get("opNotes"), subColNameValKP.get("ArrivalTime"), subColNameValKP.get("CancelCase"), subColNameValKP.get("signInDepartment"),
						subColNameValKP.get("DischargeByUserName"), subColNameValKP.get("preoperativedetails"), subColNameValKP.get("DiagnosisCode"),
						subColNameValKP.get("Units"), subColNameValKP.get("PeriodName"),
						subColNameValKP.get("BatchName"), subColNameValKP.get("Amounts"),
						subColNameValKP.get("patientAddressDetails"), subColNameValKP.get("patientAdditionalDetails"), subColNameValKP.get("patientPhoneDetails"), subColNameValKP.get("patientEmergencyContactDetails"), subColNameValKP.get("patientEmployerDetails"), subColNameValKP.get("guarantorAdditionalDetails"), subColNameValKP.get("insuranceAdditionalDetails"));
				break;

			case "PeriodBatchCreation":
				// call Create Period Batch
				this.createPeriodBatch(subColNameValKP.get("userName"), subColNameValKP.get("password"),
						subColNameValKP.get("facility"), subColNameValKP.get("periodName"),
						subColNameValKP.get("periodBeginDate"), subColNameValKP.get("periodEndDate"),
						Boolean.parseBoolean(subColNameValKP.get("isActive")), subColNameValKP.get("batchName"));
				break;

			case "WorklistAddition":
				this.createWorklist(subColNameValKP.get("facility"), subColNameValKP.get("worklistType"),
						subColNameValKP.get("worklistName"), subColNameValKP.get("generalFlag"),
						subColNameValKP.get("painFlag"), subColNameValKP.get("giFlag"), subColNameValKP.get("eyeFlag"),
						subColNameValKP.get("laserFlag"), subColNameValKP.get("questions"));	
				break;

			case "ConsentsCreation":
				// call Create worklist
				this.createConsents(subColNameValKP.get("facility"), subColNameValKP.get("consentName"),
						subColNameValKP.get("generalFlag"), subColNameValKP.get("painFlag"),
						subColNameValKP.get("giFlag"), subColNameValKP.get("eyeFlag"), subColNameValKP.get("laserFlag"),
						subColNameValKP.get("physicianScheduleFlag"), subColNameValKP.get("procdeureScheduleFlag"),
						subColNameValKP.get("diagnosisScheduleFlag"), subColNameValKP.get("consentStatementText"), subColNameValKP.get("consentSigneeDetails"));

				break;
			case "FeeScheduleCreation":
				// call Create Fee Schedule
				this.insertFeeSchedule(subColNameValKP.get("Username"), subColNameValKP.get("Password"),
						subColNameValKP.get("Facility"), subColNameValKP.get("CPTCode"), subColNameValKP.get("Amount"), subColNameValKP.get("BillableStatus"));
				break;
			case "MedicationCreation":
				this.createMedication(subColNameValKP.get("Username"), subColNameValKP.get("Password"), subColNameValKP.get("Facility"), subColNameValKP.get("Medication"), subColNameValKP.get("searchString"),
						subColNameValKP.get("FullMedication"), subColNameValKP.get("Department"), subColNameValKP.get("Speciality"), subColNameValKP.get("TemplateName"),
						subColNameValKP.get("TotalUnits"), subColNameValKP.get("BolusUnit"), subColNameValKP.get("BolusDose"), subColNameValKP.get("DispensableDrug"),
						subColNameValKP.get("RouteDesc"), subColNameValKP.get("MedicationStrength"), subColNameValKP.get("MedicationStrengthUnit"), subColNameValKP.get("isTitrated"));
				break;

			case "createPhysicianOrders":
				// call createPhysicianOrders
				this.createPhysicianOrders(subColNameValKP.get("userName"), subColNameValKP.get("password"),
						subColNameValKP.get("facility"), subColNameValKP.get("Ordername"),
						subColNameValKP.get("Physician"), subColNameValKP.get("Department"),
						subColNameValKP.get("DepartmentOrderstext"));

				break;

			case "createPhysicianOpNotes":
				// call createPhysicianOpNotes
				this.createPhysicianOpNotes(subColNameValKP.get("userName"), subColNameValKP.get("password"),
						subColNameValKP.get("facility"), subColNameValKP.get("Ordername"),
						subColNameValKP.get("Physicianname"), subColNameValKP.get("Opnotetext"));
				break;

			case "createDictionaryItem":
				this.createDictionaryItem(subColNameValKP.get("userName"), subColNameValKP.get("password"),
						subColNameValKP.get("facility"), subColNameValKP.get("Dictionaryname"),
						subColNameValKP.get("DictionaryitemName"), subColNameValKP.get("value"));
				break;
			case "createPreferenceCards":
				this.createPreferenceCards(subColNameValKP.get("facility"), subColNameValKP.get("preferenceCardNames"), 
						subColNameValKP.get("caseSpecialtiy"), subColNameValKP.get("appointmentTypeValue"), subColNameValKP.get("physician"), 
						subColNameValKP.get("anesthesiaTypeValue"), subColNameValKP.get("physicianOrders"), subColNameValKP.get("opNotes"),
						subColNameValKP.get("consents"), subColNameValKP.get("dischargeInstructions"), 
						subColNameValKP.get("preAdmissionQxWorklists"), subColNameValKP.get("preAdmissionInstructionsWorklists"), 
						subColNameValKP.get("preOperativeWorklists"), subColNameValKP.get("operativeWorklists"),
						subColNameValKP.get("phase1Worklists"), subColNameValKP.get("phase2Worklists"),	subColNameValKP.get("phase3Worklists"), 
						subColNameValKP.get("recoveryWorklist"),subColNameValKP.get("postoperativeQXWorklists"), subColNameValKP.get("implantNames"), subColNameValKP.get("manfacturerNames"), 
						subColNameValKP.get("size"), subColNameValKP.get("lotNum"), subColNameValKP.get("serialNum"),
						subColNameValKP.get("expiration"), subColNameValKP.get("referenceNum"), subColNameValKP.get("quantity"), 
						subColNameValKP.get("implantnotes"), subColNameValKP.get("supplyName"), subColNameValKP.get("prOpen"), subColNameValKP.get("prHold"), 
						subColNameValKP.get("orOpen"), subColNameValKP.get("orHold"), subColNameValKP.get("p1Open"), 
						subColNameValKP.get("p1Hold"), subColNameValKP.get("p2Open"), subColNameValKP.get("p2Hold"), subColNameValKP.get("p3Open"), 
						subColNameValKP.get("p3Hold"), subColNameValKP.get("supplyNotes"), subColNameValKP.get("equipmentNames"), 
						subColNameValKP.get("serialNumbers"), subColNameValKP.get("equipmentNotes"), subColNameValKP.get("cptCodes"));
				break;

			case "updateStateReportEthnicity":
				this.updateStateReportEthnicity(subColNameValKP.get("facility"), subColNameValKP.get("stateCode"));
				break;

			case "updateStateReportInsurance":
				this.updateStateReportInsurance(subColNameValKP.get("facility"), subColNameValKP.get("payerCode"), subColNameValKP.get("stateCode"));
				break;

			case "updateStateReportLanguage":
				this.updateStateReportLanguage(subColNameValKP.get("facility"), subColNameValKP.get("stateCode"));
				break;

			case "updateStateReportPhysician":
				this.updateStateReportPhysician(subColNameValKP.get("facility"), subColNameValKP.get("stateCode"));
				break;

			case "updateStateReportRace":
				this.updateStateReportRace(subColNameValKP.get("facility"), subColNameValKP.get("stateCode"));
				break;

			case "createNewuser":
				this.createUsers(subColNameValKP.get("userName"), subColNameValKP.get("password"),subColNameValKP.get("facility"),
						subColNameValKP.get("firstName"), subColNameValKP.get("middleInitial"),subColNameValKP.get("lastName"),
						subColNameValKP.get("businessfacility"), subColNameValKP.get("profileName"),subColNameValKP.get("roleName"));
				break;
			case "addPaymentTransaction":
				this.addPaymentTransaction(subColNameValKP.get("writeOffGroupCode"), subColNameValKP.get("WriteOffReasonCode"),
						subColNameValKP.get("amount"), subColNameValKP.get("transactionCodeName"));
				break;

			case "addNewWriteoffTransaction":
				this.addNewWriteoffTransaction(subColNameValKP.get("writeOffGroupCode"), subColNameValKP.get("WriteOffReasonCode"), subColNameValKP.get("amount"), subColNameValKP.get("transactionCodeName"));
				break;

			case "addNewDebitTransaction":
				this.addNewDebitTransaction(subColNameValKP.get("amount"));
				break;
			case "addNewTransactionCode":
				this.createNewTransactionCodes(subColNameValKP.get("userName"), subColNameValKP.get("password"),subColNameValKP.get("facility"),
						subColNameValKP.get("transactionCodeName") , subColNameValKP.get("transactiontype"));
				break;
			case "createNewDiscounts":
				this.createDiscounts(subColNameValKP.get("userName"), subColNameValKP.get("password"),subColNameValKP.get("facility"),
						subColNameValKP.get("discountName"), subColNameValKP.get("writeOffGroupCode"), subColNameValKP.get("WriteOffReasonCode"),
						subColNameValKP.get("transactionCodeName"), subColNameValKP.get("discountpercent"));
				break;

			case "executeQuery":
				this.executeQuery(subColNameValKP.get("queryFileNames"));
				break;

			case "UpdateFacilityFeatureMapping":
				this.updateOrganizationFeatures(subColNameValKP.get("UserName"),subColNameValKP.get("Password"),subColNameValKP.get("facility"),subColNameValKP.get("Clinical Documentation Tracker"),
						subColNameValKP.get("Combined Coding/Charge Entry"),subColNameValKP.get("External Inventory - Depletion"),subColNameValKP.get("External Inventory - Resources"),subColNameValKP.get("State Reporting"),
						subColNameValKP.get("SIS Office"), subColNameValKP.get("Business App Settings"),subColNameValKP.get("Case Types"), subColNameValKP.get("SIS Charts"),
						subColNameValKP.get("Clinical App Settings"), subColNameValKP.get("SIS Anesthesia"),subColNameValKP.get("Clinical App Settings_Anesthesia"), subColNameValKP.get("Case Requests"),
						subColNameValKP.get("Eligibility"), subColNameValKP.get("UDB Data Transfer"));
				break;

			case "createInsuranceContract":
				this.createInsuranceContract(subColNameValKP.get("username"), subColNameValKP.get("password"), subColNameValKP.get("facility"), subColNameValKP.get("insuranceContractName"), subColNameValKP.get("effectiveDate"), subColNameValKP.get("expirationDate"), subColNameValKP.get("contractType"), 
						subColNameValKP.get("percentOfBilledCharge"), subColNameValKP.get("transactionCodeName"),subColNameValKP.get("writeOffGroupId"), subColNameValKP.get("writeOffReasonId"),
						subColNameValKP.get("procedure1"), subColNameValKP.get("procedure2"), subColNameValKP.get("procedure3"), subColNameValKP.get("procedure4"), subColNameValKP.get("procedure5"), subColNameValKP.get("addtionalProcedure"), subColNameValKP.get("groupIndx"), subColNameValKP.get("reimbursement"));
				break;
			}	
		}
	}

	public void createNewRoom(String facility, String roomName1) throws Exception {
		try {
			createSession(facility);
			for (int i = 0; i < roomName1.split("[;]").length; i++) {
				String roomName = roomName1.split("[;]")[i];
				String relURL = "/RoomType/Add";
				// API1 to put room type
				Object obj = null;
				obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddRoomType.json");
				int roomTypeId = Integer.parseInt(ReusableUtils.generateRandomNumeric(9));
				String roomTypeDesc = "RTyp " + roomName;
				// LOG.info(String.format("roomTypeId-> "+roomTypeId);
				// Update roomTypeId
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "roomTypeId", roomTypeId);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "roomTypeDesc", roomTypeDesc);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "quickCode", roomTypeDesc);
				LOG.info(String.format("Object-> %s", obj));
				Response response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);
				if (response.getStatusCode() == 200) {
					LOG.info(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
							IWebServiceResponseKeys.WS_STATUS_SUCCESS));
				} else {
					LOG.error(String.format("URL - %s, Response - %d (%s)", this.baseURL + relURL, response.getStatusCode(),
							IWebServiceResponseKeys.WS_STATUS_FAILURE));
				}

				// API2 to put add room
				relURL = "/Room/Add";
				obj = jsonUtils.getJsonFileAsObject("reqTemplates/AddRoom.json");
				int roomId = Integer.parseInt(ReusableUtils.generateRandomNumeric(9));
				// update roomTypeId
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "roomTypeId", roomTypeId);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "roomId", roomId);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "organizationId",
						Integer.parseInt((String) this.mapWebServiceResponses.get(IWebServiceResponseKeys.keyOrgId)));
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "name", roomName);
				obj = jsonUtils.updateOneJsonElement(obj.toString(), "quickCode", roomName);
				LOG.info(String.format("Object-> %s", obj.toString()));
				response = runWebServiceRequest("application/json", obj.toString(), relURL, Method.POST);

				this.reporter.logSuccess(String.format("Room creation is successful for Room Name: %s and for facility %s", roomName, facility));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Room creation is un-successful for Room Name: %s and for facility %s", roomName1, facility));
				this.reporter.logException(e);
			}
			throw e;

		}
	}

	public void createInsurance(String facility, String insuranceName, String planName, String insuranceClassification,
			String officeName, String line1, String city, String contactName, String phone, String zip,
			String extendedZip, String State, boolean generateTrue, String contractName) throws Exception {
		try {

			// perform webservice call

			String insuranceName_mul = insuranceName;
			String planName_mul = planName;
			String insuranceClassification_mul = insuranceClassification;
			String officeName_mul = officeName;
			String line1_mul = line1;
			String city_mul = city;
			String contactName_mul = contactName;
			String phone_mul = phone;
			String zip_mul = zip;
			String extendedZip_mul = extendedZip;
			String State_mul = State;
			String contracts_mul = contractName;

			for (int i = 0; i < insuranceName_mul.split("[;]").length; i++) {
				insuranceName = insuranceName_mul.split("[;]")[i];
				try {
					planName = planName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					insuranceClassification = insuranceClassification_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					officeName = officeName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					line1 = line1_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					city = city_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					contactName = contactName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					phone = phone_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					zip = zip_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					extendedZip = extendedZip_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					State = State_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					contractName = contracts_mul.split("[;]")[i];
				} catch (Exception e) {
				}

				// getsession for User and map Organization
				createSession(facility);
				// API call to create Insurance(carrier)
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceCarrierId, null);
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.insurancePlanId, null);
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.insuranceClaimOfficeid, null);
				Response response = saveInsuranceCarrier(insuranceName, planName, insuranceClassification);
				if ( (response == null) || response.getStatusCode() == 200) {

					if (this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceClaimOfficeid) == null) {
						String insuranceCarrierId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.insuranceCarrierId).toString();

						// API call to create InsuranceClaimOffice
						response = insertInsuranceClaimOffice(insuranceCarrierId, officeName, line1, city, contactName,
								phone, zip, extendedZip, State);
						String insurancePlanId = null;
						if(this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.insurancePlanId)
								&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.insurancePlanId)!=null) {
							insurancePlanId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.insurancePlanId).toString();
						}

						if (response.getStatusCode() == 200 || (response == null)) {
							// API call to create InsuranceClaimOffice
							response = saveInsurancePlan(insuranceCarrierId, insurancePlanId, planName,
									insuranceClassification, officeName, line1, city, contactName, phone, zip, extendedZip,
									State, generateTrue, contractName);
							updateInsuranceClaimOffice(insuranceCarrierId, officeName, line1, city, contactName, phone, zip, extendedZip, State);
							insurancePlanId = null;
							if(this.mapWebServiceResponses.containsKey(IWebServiceResponseKeys.insurancePlanId)
									&& this.mapWebServiceResponses.get(IWebServiceResponseKeys.insurancePlanId)!=null) {
								insurancePlanId = this.mapWebServiceResponses.get(IWebServiceResponseKeys.insurancePlanId).toString();
							}
							saveInsurancePlan(insuranceCarrierId, insurancePlanId, planName,
									insuranceClassification, officeName, line1, city, contactName, phone, zip, extendedZip,
									State, generateTrue, contractName);
						} 
					} 
				}
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("Insurance creation is successful for Insurance Name: %s and for facility: %s", insuranceName, facility));
				}
			}
		} catch (Exception e) {
			LOG.error(e);			
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Insurance creation is un-successful"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void patientOperations(String userID, String password, String facility, String patientsearchstr,String firstName, String lastName, String procedureDt,
			String physicianUser, String roomName, String startTime, String endTime, String appointmentType, String preferenceCardName,
			String cptCode, String lterality, String preOpDiagnosisCode, String guarantorFirstName, String guarantorLastName,
			String guarantorDateOfBirth, String guarantorCountry, String guarantorIsActive, String primaryGuarantor,
			String secondaryGuarantor, String Carriername, String RelationshiptoSubscriber, String InsurancefirstName,
			String InsurancelastName, String gender, String Subscriberid,String PreOPmedicationtemplates,String OPmedicationtemplates,String Recovmedicationtemplates, 
			String worklistWithDepartment, String implantsAndProsthesisByInventory, String implantName, String manufacturerName, String otherDetails,
			String suppliesAndInstrumentsByInventory, String supplyNames,String OtherSuppliesDetails, 
			String equipmentByInventory, String equipmentName, String equipmentserialNumber, String equipmentnotes, String opNotes,
			String arrivalTime, String cancelCaseTemplate, String signInDepartment, String dischargeByUserName,String preoperationdetails,
			String diagnosisCode, String units, String PeriodName, String BatchName, String amount,
			String patientAddressDetails, String patientAdditionalDetails, String patientPhoneDetails, String patientEmergencyContactDetails, String patientEmployerDetails, String guarantorAdditionalDetails, String insuranceAdditionalDetails) throws Exception  {
		try {
			// Create the session for the facility
			JSONObject casesToCodeResponse = new JSONObject();
			createSession(userID, password,facility);
			if(patientsearchstr != null && !patientsearchstr.isEmpty()) {
				//				System.out.println("patientsearchstr"+patientsearchstr);
				getpatientObjfromName(patientsearchstr,firstName+" M. "+lastName);
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.patientsearchstr, true);
			}else {
				// Create the patient
				createjustApatient(firstName, lastName, procedureDt, patientAddressDetails, patientAdditionalDetails, patientPhoneDetails, patientEmergencyContactDetails, patientEmployerDetails);
			}
			// Map a case summary for the patinet created
			createCaseSummary(physicianUser, roomName, startTime, endTime, appointmentType, preferenceCardName, cptCode, lterality, preOpDiagnosisCode, procedureDt,
					guarantorFirstName, guarantorLastName, guarantorDateOfBirth, guarantorAdditionalDetails, guarantorCountry, guarantorIsActive,
					primaryGuarantor, secondaryGuarantor, Carriername, RelationshiptoSubscriber, InsurancefirstName,
					InsurancelastName, gender, Subscriberid, insuranceAdditionalDetails);

			if(patientAddressDetails != null && !patientAddressDetails.equalsIgnoreCase("blank") && !patientAddressDetails.isEmpty()) {
				reqlockCasePatient();
				payerEligibilityReq();
				relreaseLockPatient();
			}
			if(worklistWithDepartment != null && !worklistWithDepartment.isEmpty()) {
				String[] worklists = worklistWithDepartment.split("[|]");
				for(int i = 0; i < worklists.length; i++) {
					String departmentName = worklists[i].split("\\;")[0];
					String worklistName = worklists[i].split("\\;")[1];
					addWorklistToPatient(departmentName, worklistName, implantsAndProsthesisByInventory.split("\\;")[i], implantName.split("\\;")[i],
							manufacturerName.split("\\;")[i], otherDetails.split("\\;")[i], 
							suppliesAndInstrumentsByInventory.split("\\;")[i], supplyNames.split("\\;")[i], OtherSuppliesDetails.split("\\;")[i],
							equipmentByInventory.split("\\;")[i], equipmentName.split("\\;")[i], equipmentserialNumber.split("\\;")[i],  equipmentnotes.split("\\;")[i]);
				}
			}else {
				if(preferenceCardName!=null && !preferenceCardName.isEmpty() && !preferenceCardName.equalsIgnoreCase("BLANK")
						&& implantsAndProsthesisByInventory!=null && !implantsAndProsthesisByInventory.isEmpty() && !implantsAndProsthesisByInventory.equalsIgnoreCase("BLANK")) {
					mapImplantToPatient(preferenceCardName, implantsAndProsthesisByInventory);
				}	
			}

			if (PreOPmedicationtemplates != null && !PreOPmedicationtemplates.isEmpty()) {
				addMedication(userID,PreOPmedicationtemplates, "Pre-Operative");
			}
			if (OPmedicationtemplates != null && !OPmedicationtemplates.isEmpty()) {
				addMedication(userID,OPmedicationtemplates, "Operative");
			}
			if (Recovmedicationtemplates != null && !Recovmedicationtemplates.isEmpty()) {
				addMedication(userID,Recovmedicationtemplates, "Recovery");
			}

			if (dischargeByUserName != null && !dischargeByUserName.isEmpty()) {
				// Performs patient discharge through recovery department
				dischargePatient(dischargeByUserName, procedureDt, preoperationdetails);
			}
			// sign the department which splitted by [;]
			if(signInDepartment != null && !signInDepartment.isEmpty()) {
				signPatientDepartments(signInDepartment);
			}

			if (opNotes != null && !opNotes.isEmpty() && !(opNotes.equalsIgnoreCase("BLANK"))) {
				addOPNotesToPatient(opNotes);
			}

			// Perform cases to code
			if (diagnosisCode != null && !diagnosisCode.isEmpty()) {
				casesToCodeResponse = performPatientCasesToCode(diagnosisCode);
			}
			// Perform Charge Entry
			if (PeriodName != null && !PeriodName.isEmpty()) {
				performPatientChargeEntry(casesToCodeResponse, PeriodName, BatchName, amount);
			}

			if(arrivalTime != null && !arrivalTime.isEmpty()) {
				updatePatientArrivalTime(arrivalTime.split("[,]")[0], arrivalTime.split("[,]")[1], this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseAppointmentId).toString());
				updateCaseStatus(this.mapWebServiceResponses.get(IWebServiceResponseKeys.caseSummaryID).toString(), "2");
				UpsertCaseSummaryInfoForArrival();
			}

			if(cancelCaseTemplate != null && !cancelCaseTemplate.isEmpty()) {
				cancelPatient(cancelCaseTemplate);
			}

			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Patient operation is successful for firstName: %s",firstName));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Patient operation is un-success for firstName: %s",firstName));
				this.reporter.logException(e);
			}
			throw e;

		}
	}

	public void createPeriodBatch(String userName, String password, String facility, String periodName,
			String periodBeginDate, String periodEndDate, boolean isActive, String batchName) throws Exception {
		try {
			if (periodName != null && !periodName.isEmpty()) {
				// Create the session for the facility
				createSession(userName, password, facility);
				String periodId = createPeriod(userName, periodName, periodBeginDate, periodEndDate, isActive);
				if (batchName != null && !batchName.isEmpty()) {
					createBatch(userName, periodId, batchName);
				}
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Period and batch creation is successfull with periodName-> %s", periodName));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Period and batch creation is un-success with periodName-> %s",periodName));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createWorklist(String facility, String worklistType, String worklistName, String generalFlag,
			String painFlag, String giFlag, String eyeFlag, String laserFlag, String questions) throws Exception {
		try {
			// Create the session for the facility
			createSession(facility);	
			String worklistsCreated = "";
			if(worklistType!=null && !worklistType.isEmpty()) {
				for (int i = 0; i < worklistType.split("[;]").length; i++) {
					String ques = null;
					try {
						ques = questions.split(";")[i];
					}catch(Exception e) {
						ques = "";
					}
					if (this.reporter != null) {
						this.reporter.logSuccess( facility+"->"+  worklistType+"->"+  worklistName+"->"+  generalFlag+"->"+
								painFlag+"->"+  giFlag+"->"+  eyeFlag+"->"+  laserFlag+"->"+  questions);
					}
					String worklistId = "";

					worklistId = addWorklistTemplate(worklistType.split("[;]")[i], worklistName.split("[;]")[i],
							Boolean.parseBoolean(generalFlag.split("[;]")[i]),
							Boolean.parseBoolean(painFlag.split("[;]")[i]), Boolean.parseBoolean(giFlag.split("[;]")[i]),
							Boolean.parseBoolean(eyeFlag.split("[;]")[i]), Boolean.parseBoolean(laserFlag.split("[;]")[i]),
							ques);

					if (worklistId != null && !worklistId.isEmpty()) {
						if(worklistsCreated.isEmpty()) {
							worklistsCreated = worklistId;
						}else {
							worklistsCreated = worklistsCreated +";"+worklistId;	
						}
					}
					if (this.reporter != null) {
						this.reporter.logSuccess(String.format("Worklist creation is successfull with %s -> %s", worklistType.split("[;]")[i], worklistName.split("[;]")[i]));
					}
				}
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.worklistId, worklistsCreated);	
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Worklist creation is un-success"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createConsents(String facility, String consentName, String generalFlag, String painFlag, String giFlag,
			String eyeFlag, String laserFlag, String physicianScheduleFlag, String procdeureScheduleFlag,
			String diagnosisScheduleFlag, String consentStatementText, String signeeDetails) throws Exception {
		try {
			// Create the session for the facility
			createSession(facility);
			for (int i = 0; i < consentName.split("[;]").length; i++) {
				this.mapWebServiceResponses.put(IWebServiceResponseKeys.consentsId, null);
				getConsentDetails(consentName.split("[;]")[i]); 
				if(this.mapWebServiceResponses.get(IWebServiceResponseKeys.consentsId) != null) {
					if (this.reporter != null) {
						this.reporter.logSuccess(String.format("Consent is already present with id %s using the existing one", this.mapWebServiceResponses.get(IWebServiceResponseKeys.consentsId)));
					}
				}			
				else {
					addConsent(consentName.split("[;]")[i], Boolean.parseBoolean(generalFlag.split("[;]")[i]),
							Boolean.parseBoolean(painFlag.split("[;]")[i]), Boolean.parseBoolean(giFlag.split("[;]")[i]),
							Boolean.parseBoolean(eyeFlag.split("[;]")[i]), Boolean.parseBoolean(laserFlag.split("[;]")[i]),
							Boolean.parseBoolean(physicianScheduleFlag.split("[;]")[i]),
							Boolean.parseBoolean(procdeureScheduleFlag.split("[;]")[i]),
							Boolean.parseBoolean(diagnosisScheduleFlag.split("[;]")[i]),
							consentStatementText.split("[;]")[i], signeeDetails.split("[;]")[i]);
					if (this.reporter != null) {
						this.reporter.logSuccess(String.format("Consent creation is successfull with Consent Name -> %s", consentName.split("[;]")[i]));
					}
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Consent creation is un-success"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void insertFeeSchedule(String username, String password, String facility, String cptCode, String amount, String billableStatus) throws Exception {
		try {
			// Create a token with given facility
			createSession(username, password,facility);
			//Get FeeScehdule and perform Add only if the feeschedule doesn't exists
			JSONArray array = getAllFeeSchedules();


			if(cptCode!=null && !cptCode.isEmpty()) {
				String bilableState = "Billable";
				for (int i = 0; i < cptCode.split("[|]").length; i++) {
					boolean flag = false;
					for (int j = 0; j < array.length(); j++) {
						try {
							String cptCodeFromArryay = array.getJSONObject(j).getJSONObject("cptProcedure").getString("cptCode");
							if(cptCode.split("[|]")[i].equals(cptCodeFromArryay)) {
								flag = true;
								break;
							}
						}catch(Exception e) {}
					}
					if(!flag) {
						try {
							if(!billableStatus.split("[|]")[i].isEmpty())
								bilableState = billableStatus.split("[|]")[i];
						} catch (Exception e) {
						}
						insertFeeScheduleRecord(cptCode.split("[|]")[i], (int) Math.round(Double.valueOf(amount.split("[|]")[i])), bilableState);
						if (this.reporter != null) {
							this.reporter.logSuccess(String.format("FeeSchedule creation is successfull with CPTCode -> %s", cptCode.split("[|]")[i]));
						}
					}else {
						if (this.reporter != null) {
							this.reporter.logSuccess(String.format("FeeSchedule -> %s already exists", cptCode));
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("FeeSchedule creation is un-success"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createMedication(String Username, String Password, String Facility, String Medication, String searchString, String fullMedication, String department, String speciality,
			String templateName, String totalUnits, String bolusUnit, String bolusDose, String dispensableDrug, String routeDesc, String medicationStrength, String	medicationStrengthUnit,
			String isTitrated) throws Exception {

		try {
			createSession(Facility);

			LOG.info("" + Username + " " + Password + " " + Facility + " " + Medication + " " + fullMedication + " " + department + " " + speciality + " " +
					templateName + " " + totalUnits + " " + bolusUnit + " " + bolusDose + " " + dispensableDrug + " " + routeDesc + " " + isTitrated);

			createMedicationTemplate(Medication, fullMedication, searchString, department, speciality, templateName,
					totalUnits, bolusUnit, bolusDose, dispensableDrug, routeDesc, isTitrated);
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Medication creation is successfull with Medication Desc -> %s", Medication));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Medication creation is un-success"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createPreferenceCards(String facility, String preferenceCardNames, String caseSpecialtiy, String appointmentTypeValue,
			String physician, String anesthesiaTypeValue, String physicianOrders, String opNotes, String consents, String dischargeInstructions,
			String preAdmissionQxWorklists, String preAdmissionInstructionsWorklists, String preOperativeWorklists, String operativeWorklists,
			String phase1Worklists, String phase2Worklists, String phase3Worklists, String recoveryWorklist, String postoperativeQXWorklists, String implantNames, String manfacturerNames, String size, String lotNum,
			String serialNum, String expiration, String referenceNum, String quantity, String implantnotes,
			String supplyName, String prOpen, String prHold, String orOpen, String orHold,
			String p1Open, String p1Hold, String p2Open, String p2Hold, String p3Open, String p3Hold, String supplyNotes,
			String equipmentNames, String serialNumbers, String equipmentNotes, String cptCodes) throws Exception {
		try {
			// Create the session for the facility
			createSession(facility);
			for (int i = 0; i < preferenceCardNames.split("[;]").length; i++) {
				addPreferenceCard(preferenceCardNames.split("[;]")[i], caseSpecialtiy.split("[;]")[i], appointmentTypeValue.split("[;]")[i], physician.split("[;]")[i],
						anesthesiaTypeValue.split("[;]")[i], physicianOrders.split("[;]")[i], opNotes.split("[;]")[i], consents.split("[;]")[i], dischargeInstructions.split("[;]")[i],
						preAdmissionQxWorklists.split("[;]")[i], preAdmissionInstructionsWorklists.split("[;]")[i], preOperativeWorklists.split("[;]")[i], operativeWorklists.split("[;]")[i],
						phase1Worklists.split("[;]")[i], phase2Worklists.split("[;]")[i], phase3Worklists.split("[;]")[i], recoveryWorklist.split("[;]")[i],postoperativeQXWorklists.split("[;]")[i],
						implantNames.split("[;]")[i], manfacturerNames.split("[;]")[i],size.split("[;]")[i],lotNum.split("[;]")[i],serialNum.split("[;]")[i],expiration.split("[;]")[i],
						referenceNum.split("[;]")[i],quantity.split("[;]")[i],implantnotes.split("[;]")[i],
						supplyName.split("[;]")[i], prOpen.split("[;]")[i], prHold.split("[;]")[i], orOpen.split("[;]")[i], orHold.split("[;]")[i], p1Open.split("[;]")[i],
						p1Hold.split("[;]")[i], p2Open.split("[;]")[i], p2Hold.split("[;]")[i], p3Open.split("[;]")[i], p3Hold.split("[;]")[i], supplyNotes.split("[;]")[i],
						equipmentNames.split("[;]")[i], serialNumbers.split("[;]")[i], equipmentNotes.split("[;]")[i],cptCodes.split("[;]")[i]);

				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("Preference card creation is successfull with Preference Card Name -> %s",
							preferenceCardNames.split("[;]")[i]));
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Preference Card creation is un-success"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createPhysicianOpNotes(String userName, String password, String facility, String OpNoteName,
			String physicianname, String Opnotetext) throws Exception {
		try {
			String OpNoteName_mul = OpNoteName;
			String physicianname_mul = physicianname;
			String Opnotetext_mul = Opnotetext;
			for (int i = 0; i < OpNoteName_mul.split("[;]").length; i++) {
				OpNoteName = OpNoteName_mul.split("[;]")[i];
				try {
					physicianname = physicianname_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					Opnotetext = Opnotetext_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				if (OpNoteName != null && !OpNoteName.isEmpty() && !(OpNoteName.equalsIgnoreCase("BLANK"))) {
					createSession(userName, password, facility);
					boolean isOpNotesPresent = getPhysicianOpNotesDetails(OpNoteName);
					if(!(isOpNotesPresent)) {
						OpNoteConfigurationAdd(OpNoteName);
						updateOpNoteConfiguration(OpNoteName, physicianname, Opnotetext);
					} else {
						if (this.reporter != null) {
							this.reporter.logInfo(String.format("OPNotes is already present with " + OpNoteName + ", using the existing one."));
						}
					}
				}
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("Physician Opnote creation is successfull with OpNoteName-> %s", OpNoteName));
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Physician Opnote creation is successfull with OpNoteName-> %s", OpNoteName));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createDiscounts(String userName, String password, String facility, String discountName,
			String writeOffGroupCode, String WriteOffReasonCode, String transactionCodeName, String discountpercent) throws Exception {
		try {
			String discountName_mul = discountName;
			String writeOffGroupCode_mul = writeOffGroupCode;
			String WriteOffReasonCode_mul = WriteOffReasonCode;
			String transactionCodeName_mul = transactionCodeName;
			String discountpercent_mul = discountpercent;

			if(this.token == null) {
				createSession(userName, password, facility);
			}

			for (int i = 0; i < discountName_mul.split("[;]").length; i++) {
				discountName = discountName_mul.split("[;]")[i];
				try {
					writeOffGroupCode = writeOffGroupCode_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					WriteOffReasonCode = WriteOffReasonCode_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					transactionCodeName = transactionCodeName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					discountpercent = discountpercent_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				if (discountName != null && !discountName.isEmpty()) {
					createSaveSourceOfRevenue(discountName, writeOffGroupCode, WriteOffReasonCode, transactionCodeName,
							discountpercent);
				}
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format("Discount creation is successfull with Name-> %s",
							discountName));
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Discount creation is successfull with OpNoteName-> %s", discountName));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createDictionaryItem(String userName, String password, String facility, String Dictionaryname,
			String DictionaryitemName, String value) throws Exception {
		try {
			String DictionaryitemName_mul = DictionaryitemName;
			String Dictionaryname_mul = Dictionaryname;
			String value_mul = value;

			for (int i = 0; i < DictionaryitemName_mul.split("[;]").length; i++) {
				DictionaryitemName = DictionaryitemName_mul.split("[;]")[i];
				try {
					Dictionaryname = Dictionaryname_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					value = value_mul.split("[;]")[i];
				} catch (Exception e) {
				}

				if (DictionaryitemName != null && !DictionaryitemName.isEmpty()) {
					createSession(userName, password, facility);
					boolean showInClinicalTf = Boolean.valueOf(value);
					createDictionary(Dictionaryname, DictionaryitemName, showInClinicalTf);
				}
				if (this.reporter != null) {
					this.reporter.logSuccess(String.format(
							"Dictionary Item creation is successfull with DictionaryitemName-> %s wunder dictionary ->%s",
							DictionaryitemName, Dictionaryname));
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format(
						"Dictionary Item creation is successfull with DictionaryitemName-> %s wunder dictionary ->%s",
						DictionaryitemName, Dictionaryname));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createPhysicianOrders(String userName, String password, String facility, String Ordername,
			String Physician, String Department, String DepartmentOrderstext) throws Exception {
		try {
			// perform createphysicianorders

			String Ordername_mul = Ordername;
			String planName_mul = Physician;
			String Department_mul = Department;
			String DepartmentOrderstext_mul = DepartmentOrderstext;

			for (int i = 0; i < Ordername_mul.split("[;]").length; i++) {
				Ordername = Ordername_mul.split("[;]")[i];
				try {
					Physician = planName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					Department = Department_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					DepartmentOrderstext = DepartmentOrderstext_mul.split("[;]")[i];
				} catch (Exception e) {
				}

				if (Ordername != null && !Ordername.isEmpty()) {
					createSession(userName, password, facility);
					addNewOrder(Ordername);
					UpdatePhysicians(Physician);
					if (Department != null && !Department.isEmpty()) {
						for (int l = 0; l < DepartmentOrderstext.split("[,]").length; l++) {
							UpdateBaseOrder(Department, DepartmentOrderstext.split("[,]")[l]);
						}
					}
				}
				if (this.reporter != null) {
					this.reporter.logSuccess(
							String.format("Physician Orders creation is successfull with Ordername-> %s", Ordername));
				}

			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Physician Orders creation is un-success with Ordername-> %s", Ordername));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void updateStateReportEthnicity(String facility, String stateCode) throws Exception {
		try {
			if (stateCode != null && !stateCode.isEmpty()) {
				// Create the session for the facility
				createSession(facility);
				updateStateReportEthnicity(stateCode);
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully updated the state codes to State reports for Ethnicity"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while updating the state codes to State reports for Ethnicity"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void updateStateReportInsurance(String facility, String payerCode, String stateCode) throws Exception {
		try {
			if (stateCode != null && !stateCode.isEmpty()) {
				// Create the session for the facility
				createSession(facility);
				updateStateReportInsurance(payerCode, stateCode);
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully updated the state codes to State reports for Insurance"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while updating the state codes to State reports for Insurance"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void updateStateReportLanguage(String facility, String stateCode) throws Exception {
		try {
			if (stateCode != null && !stateCode.isEmpty()) {
				// Create the session for the facility
				createSession(facility);
				updateStateReportLanguage(stateCode);
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully updated the state codes to State reports for Language"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while updating the state codes to State reports for Language"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void updateStateReportPhysician(String facility, String stateCode) throws Exception {
		try {
			if (stateCode != null && !stateCode.isEmpty()) {
				// Create the session for the facility
				createSession(facility);
				updateStateReportPhysician(stateCode);
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully updated the state codes to State reports for Physician"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while updating the state codes to State reports for Physician"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void updateStateReportRace(String facility, String stateCode) throws Exception {
		try {
			if (stateCode != null && !stateCode.isEmpty()) {
				// Create the session for the facility
				createSession(facility);
				updateStateReportRace(stateCode);
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully updated the state codes to State reports for Race"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while updating the state codes to State reports for Race"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createUsers(String userName, String password, String facility, String firstName,
			String middleInitial, String lastName,  String businessfacility, String profileName, String roleName) throws Exception {
		try {
			//perform create Users

			String firstName_mul = firstName;
			String middleInitial_mul = middleInitial;
			String lastName_mul = lastName;
			String businessfacility_mul = businessfacility;
			String profileName_mul = profileName;
			String roleName_mul = roleName;

			for (int i = 0; i < firstName_mul.split("[;]").length; i++) {
				firstName = firstName_mul.split("[;]")[i];
				try {
					middleInitial = middleInitial_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					lastName = lastName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					businessfacility = businessfacility_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					profileName = profileName_mul.split("[;]")[i];
				} catch (Exception e) {
				}
				try {
					roleName = roleName_mul.split("[;]")[i];
				} catch (Exception e) {
				}

				if (firstName != null && !firstName.isEmpty()) {
					createSession(userName, password, facility);
					CreateNewUser(firstName, middleInitial, lastName);
					if (businessfacility != null && !businessfacility.isEmpty()) {
						for (int j = 0; j < businessfacility.split("[,]").length; j++) {
							if (profileName != null && !profileName.isEmpty()) {
								for (int k = 0; k < profileName.split("[,]").length; k++) {
									for (int l = 0; l < roleName.split("[,]").length; l++) {
										SetUserOrganizationAssignment(businessfacility.split("[,]")[j], profileName.split("[,]")[k], roleName.split("[,]")[l]);
									}
								}
							}
							StaffUpsert(businessfacility.split("[,]")[j]);
						}
					}
					if (this.reporter != null) {
						this.reporter.logSuccess(
								String.format("create Users creation is successfull with firstName-> %s, lastName->%s", firstName,lastName));
					}
				}
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("create Users creation is successfull with firstName-> %s, lastName->%s", firstName,lastName));
				this.reporter.logException(e);
			}
			throw e;
		}
	}


	public Map<String, String> getWorklistTemplates() {
		Map<String, String> worklistTemplateNames = new HashMap<>();
		worklistTemplateNames.put("Case Details", "worklist_caseDetails");
		worklistTemplateNames.put("Cautery", "worklist_cautery");
		worklistTemplateNames.put("Closure and Dressing", "worklist_ClosureAndDressing");
		worklistTemplateNames.put("Equipment", "worklist_equipment");
		worklistTemplateNames.put("Existing Implants", "worklist_ExistingImplants");
		worklistTemplateNames.put("Hair Removed", "worklist_hairRemoved");
		worklistTemplateNames.put("Implants and Prosthesis", "worklist_ImplantsProsthesis");
		worklistTemplateNames.put("Irrigations", "worklist_Irrigation");
		worklistTemplateNames.put("Normothermia", "worklist_Normothermia");
		worklistTemplateNames.put("Patient Position", "worklist_PatientPosition");
		worklistTemplateNames.put("Prep", "worklist_Prep");
		worklistTemplateNames.put("Psychosocial Status", "worklist_PsychosocialStatus");
		worklistTemplateNames.put("Safety Strap", "worklist_SafetyStrap");
		worklistTemplateNames.put("Site Marking", "worklist_SiteMarking");
		worklistTemplateNames.put("Supplies and Instruments", "worklist_SuppliesAndInstruments");
		worklistTemplateNames.put("Tourniquet", "worklist_Tourniquet");
		worklistTemplateNames.put("Wound Class", "worklist_WoundClass");
		worklistTemplateNames.put("X-Ray", "worklist_XRay");
		return worklistTemplateNames;
	}


	public void createNewTransactionCodes(String userName, String password, String facility, String transactionCodeName,String transactiontype) throws Exception {
		try {
			String transactionCodeName_mul = transactionCodeName;
			String transactiontype_mul = transactiontype;

			if (transactionCodeName != null && !transactionCodeName.isEmpty()) {
				for(int i=0; i<transactionCodeName_mul.split("[;]").length;i++) {
					transactionCodeName = transactionCodeName_mul.split("[;]")[i];
					try {
						transactiontype = transactiontype_mul.split("[;]")[i];
					} catch (Exception e) {
					}
					// Create the session for the facility
					createSession(userName, password, facility);
					createNewTransactionCode(transactionCodeName, transactiontype);
				}
			}
			if (this.reporter != null) {
				this.reporter.logSuccess(String.format("Successfully created New Transaction Code"));
			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Failed while createing New Transaction Code"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void executeQuery(String fileNames) throws Exception {
		if(fileNames!=null && !fileNames.isEmpty()) {
			for (int i = 0; i < fileNames.split("[;]").length; i++) {
				try{  
					DbUtils util = new DbUtils();
					util.connectDatabase("SIS72QCGEMAUTO2", "Charts-Master", "Charts", "Charts");//This needs to be moved to xml config file

					boolean flag = util.executeSqlFile("sqlQueries/"+fileNames.split("[;]")[i]+".sql");
					if(flag) {
						this.reporter.logSuccess(String.format("Query execution is successful"));
					}else {
						this.reporter.logSuccess(String.format("Query execution is Un-successful"));
					}
					util.closeConnection();
				}catch(Exception e){
					LOG.error(e);
					if (this.reporter != null) {
						this.reporter.logFailure(String.format("Exception occured while running the query"));
						this.reporter.logException(e);
					}
					throw e;
				}
			}
		}
	}

	public void updateOrganizationFeatures(String userID, String password, String facility, String ClinicalDocumentationTracker, String CombinedCodingChargeEntry, String ExternalInventoryDepletion, String ExternalInventoryResources, String StateReporting, String SISOffice, 
			String 	BusinessAppSettings, String CaseTypes, String SISCharts, String ClinicalAppSettings, String SISAnesthesia, String ClinicalAppSettings_Anesthesia, String CaseRequests, String Eligibility, String UDBDataTransfer) throws Exception {
		try {
			try {
				if(userID!=null && !userID.isEmpty()) {
					createSession(userID, password, facility);
				}else {
					createSession(facility);
				}
			} catch (Exception e) {
				createSession(facility);
			}

			//Enabling Facility Configuration Upgrade feature

			LinkedHashMap<String, ArrayList<String>> featureMapping = getAllFacilityFeatures(facility);
			String  ClinicalDocumentationTracker_bol = getBooleanValueForConditions(ClinicalDocumentationTracker);
			if( ClinicalDocumentationTracker_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "CDM Tracker", Boolean.parseBoolean(ClinicalDocumentationTracker_bol));
			}

			String  CombinedCodingChargeEntry_bol = getBooleanValueForConditions(CombinedCodingChargeEntry);
			if( CombinedCodingChargeEntry_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Combined Coding Charging", Boolean.parseBoolean(CombinedCodingChargeEntry_bol));
			}

			String  ExternalInventoryDepletion_bol = getBooleanValueForConditions(ExternalInventoryDepletion);
			if( ExternalInventoryDepletion_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Depletion Tracker", Boolean.parseBoolean(ExternalInventoryDepletion_bol));
			}

			String ExternalInventoryResources_bol = getBooleanValueForConditions(ExternalInventoryResources);
			if( ExternalInventoryResources_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "External Inventory", Boolean.parseBoolean(ExternalInventoryResources_bol));
			}

			String  StateReporting_bol = getBooleanValueForConditions(StateReporting);
			if( StateReporting_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "State Reporting", Boolean.parseBoolean(StateReporting_bol));
			}

			String  SISOffice_bol = getBooleanValueForConditions(SISOffice);
			if( SISOffice_bol!= null) {
				updateFacilitySecureFeature(featureMapping,"SIS Office", Boolean.parseBoolean(SISOffice_bol));
			}

			String  BusinessAppSettings_bol = getBooleanValueForConditions(BusinessAppSettings);
			if( BusinessAppSettings_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Business App Settings", Boolean.parseBoolean(BusinessAppSettings_bol));
			}

			String  CaseTypes_bol = getBooleanValueForConditions(CaseTypes);
			if( CaseTypes_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Case Types", Boolean.parseBoolean(CaseTypes_bol));
			}

			String  SISCharts_bol = getBooleanValueForConditions(SISCharts);
			if( SISCharts_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "SIS Charts", Boolean.parseBoolean(SISCharts_bol));
			}

			String  ClinicalAppSettings_bol = getBooleanValueForConditions(ClinicalAppSettings);
			if( ClinicalAppSettings_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Clinical Application Settings", !Boolean.parseBoolean(ClinicalAppSettings_bol));
			}

			String  SISAnesthesia_bol = getBooleanValueForConditions(SISAnesthesia);
			if( SISAnesthesia_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "SIS Anesthesia", Boolean.parseBoolean(SISAnesthesia_bol));
			}

			String  ClinicalAppSettings_Anesthesia_bol = getBooleanValueForConditions(ClinicalAppSettings_Anesthesia);
			if( ClinicalAppSettings_Anesthesia_bol!= null) {
				updateFacilitySecureFeature(featureMapping,"Clinical App Settings", Boolean.parseBoolean(ClinicalAppSettings_Anesthesia_bol));
			}

			String  CaseRequests_bol = getBooleanValueForConditions(CaseRequests);
			if( CaseRequests_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Case Requests", Boolean.parseBoolean(CaseRequests_bol));
			}

			String  Eligibility_bol = getBooleanValueForConditions(Eligibility);
			if( Eligibility_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "Eligibility", Boolean.parseBoolean(Eligibility_bol));
			}

			String  UDBDataTransfer_bol = getBooleanValueForConditions(UDBDataTransfer);
			if( UDBDataTransfer_bol!= null) {
				updateFacilitySecureFeature(featureMapping, "UDB Data Pushing", Boolean.parseBoolean(UDBDataTransfer_bol));
			}

		}catch(Exception e){
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Exception occured while executing updateFacilitySecureFeature"));
				this.reporter.logException(e);
			}
			throw e;
		}
	}

	public void createInsuranceContract(String username, String password, String facility, String insuranceContractName, String effectiveDate,
			String expirationDate, String contractType, String percentOfBilledCharge, String transactionCodeName,
			String writeOffGroupId, String writeOffReasonId, String procedure1, String procedure2, String procedure3, String procedure4, String procedure5, String addtionalProcedure, String groupIndx, String reimbursement) throws Exception {
		try {
			createSession(username, password, facility);
			String insuranceContractName_mul = insuranceContractName;

			for (int i = 0; i < insuranceContractName_mul.split("[;]").length; i++) {
				insuranceContractName = insuranceContractName_mul.split("[;]")[i];
				if (insuranceContractName != null && !insuranceContractName.isEmpty()) {

					//					add only if the contract Name doesn't exists
					JSONObject obj = retrieveContracts(insuranceContractName);
					if(obj==null || obj.equals(null)) {
						// Create Contract Header
						saveContract(insuranceContractName, effectiveDate.split("[;]")[i], expirationDate.split("[;]")[i], contractType.split("[;]")[i]);
						// UpdateContractOptions
						SelectContractOptions(contractType.split("[;]")[i], percentOfBilledCharge.split("[;]")[i], transactionCodeName.split("[;]")[i], writeOffGroupId.split("[;]")[i], writeOffReasonId.split("[;]")[i]);

						// Update Fee groups
						if(contractType.split("[;]")[i]!=null && contractType.split("[;]")[i].equalsIgnoreCase("Grouper"))
							updateFeeGroupsForGrouperContract(groupIndx.split("[;]")[i], reimbursement.split("[;]")[i]);
						//Save Multiple procedures for contracts
						saveMultipleProceduresForContracts(procedure1.split("[;]")[i], procedure2.split("[;]")[i], procedure3.split("[;]")[i], procedure4.split("[;]")[i], procedure5.split("[;]")[i], addtionalProcedure.split("[;]")[i]);
						if (this.reporter != null) {
							this.reporter.logSuccess(String.format("Contract creation is successfull with ContractName-> %s", insuranceContractName));
						}
						getRequestForInsuranceContractReviews();
						getRequestForInsuranceContractReviewsFromFeeSchedule();

					}else {
						int contrType = getContractType(contractType.split("[;]")[i]);
						String contrName = obj.getString("insuranceContractName");
						Object contrTypeRes = obj.get("contractType");
						if(contrName.equals(insuranceContractName)
								&& contrTypeRes==null || Integer.parseInt(contrTypeRes.toString())==contrType) {
							if (this.reporter != null) {
								this.reporter.logSuccess(String.format("Contract with Contract Name-> %s and contract Type-> %s already exists", insuranceContractName, contractType.split("[;]")[i]));
							}
						}else {
							if (this.reporter != null) {
								this.reporter.logFailure(String.format("Contract with Contract Name-> %s already exists but with different contract Type", insuranceContractName));
							}
						}
					}
				}

			}
		} catch (Exception e) {
			LOG.error(e);
			if (this.reporter != null) {
				this.reporter.logFailure(String.format("Exception occured while Adding contract: "+insuranceContractName));
				this.reporter.logException(e);
			}
			throw e;
		}

	}
	
}