package com.unittest;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.testng.annotations.Test;

import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import com.seeddata.WebServiceSeedDataProcessor;
import com.templates.test.TestTemplate;

public class TestSeedData extends TestTemplate {

	@Test(enabled = true)
	public void testGetAllSeedData() throws Exception {
		ISeedDataProcessor seedDataParser = new WebServiceSeedDataProcessor(this.getExcelSeedDataFilePath(),
				this.getJsonTestDataFilePath());
		String commaSeparatedSeedDataSheets = this.getCommaSeparatedSeedDataSheets();

		for (String sheetName : commaSeparatedSeedDataSheets.split(",")) {
			List<SeedData> listSeedData = seedDataParser.getAllSeedData(sheetName,
					ISeedDataProcessor.seedDataTypeLongTerm);
			for (SeedData sd : listSeedData) {
				String testCase = sd.getTestCase();
				int rowNum = sd.getRowNumber();
				String colName = null;

				Map<String, Map<String, String>> wsNameattrValPair = sd.getOperNameParamValueKVPair();
				for (Entry<String, Map<String, String>> entry : wsNameattrValPair.entrySet()) {
					colName = entry.getKey();
					Map<String, String> subColNameValKP = entry.getValue();
					for (Entry<String, String> entrySubColVal : subColNameValKP.entrySet()) {
						String subColName = entrySubColVal.getKey();
						String subColVal = entrySubColVal.getValue();
						System.out.println(String.format(
								"Test Case = %s, rowNumber = %d, colName = %s, subColName = %s, subColVal = %s",
								testCase, rowNum, colName, subColName, subColVal));
					}
				}
			}
		}
	}

}
