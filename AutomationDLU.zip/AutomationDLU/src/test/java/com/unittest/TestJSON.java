package com.unittest;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import com.config.ITestParamsConstants;
import com.parser.excel.SISTestDataExcelParser;
import com.parser.json.JSONFileParser;
import com.utils.JsonUtils;
import com.utils.ReusableUtils;

public class TestJSON {

	private static final Logger LOG = Logger.getLogger(TestJSON.class);
	private String jsonFile = ReusableUtils.getConfigProperty(ITestParamsConstants.CONFIG_FILE,
			ITestParamsConstants.LOCATION_TESTDATA_JSON);

	@Test(enabled = true)
	public void convertExcelToJson() throws Exception {
		SISTestDataExcelParser testDataParser = new SISTestDataExcelParser(
				ReusableUtils.getConfigProperty(ITestParamsConstants.CONFIG_FILE,
						ITestParamsConstants.LOCATION_SEEDDATA_EXCEL),
				ReusableUtils.getConfigProperty(ITestParamsConstants.CONFIG_FILE,
						ITestParamsConstants.COMMA_SEPARATED_SEEDDATA_SHEETS).split(","));

		JSONObject jo = testDataParser.convertToJSONObjectWithExcludedFiles();
		new JsonUtils().writeJSONObjectToFile(jo, this.jsonFile);
	}

	@Test(enabled = true, dependsOnMethods = { "convertExcelToJson" })
	public void getAllDataFromJsonFile() {
		JSONFileParser jsonFileParser = new JSONFileParser(ReusableUtils
				.getConfigProperty(ITestParamsConstants.CONFIG_FILE, ITestParamsConstants.LOCATION_TESTDATA_JSON));
		JSONObject jsonObj = jsonFileParser.getJSONObject();
		int totalTc = 1;
		for (Entry<String, JSONArray> entry : ((Map<String, JSONArray>) jsonObj).entrySet()) {

			LOG.debug(String.format("Test No. - %d \nTest Case = %s", totalTc++, entry.getKey()));
			LOG.debug("----------JSONArray-----------------");

			JSONArray ja = entry.getValue();
			int cnt = 1;
			for (Object obj : ja) {

				LOG.debug(String.format("----------JSONArray Set - %d -----------------", cnt++));
				Map<String, String> map = (Map<String, String>) obj;
				for (Entry<String, String> entry2 : map.entrySet()) {
					LOG.debug(String.format("Key = %s", entry2.getKey()));
					LOG.debug(String.format("Value = %s", entry2.getValue()));
				}
			}

		}

	}

	@Test(enabled = true, dependsOnMethods = { "getAllDataFromJsonFile" })
	public void getTestDataFromJsonFile() {
		JSONFileParser jsonFileParser = new JSONFileParser(this.jsonFile);
		JSONObject jsonObj = jsonFileParser.getJSONObject();

		JSONArray objJsonArray = (JSONArray) jsonObj.get("gem_fmbftr_sc1831");
		System.out.println(objJsonArray);
		for (Object jsonObject : objJsonArray) {
			Map<String, String> map = (Map<String, String>) jsonObject;
			for (Entry<String, String> entry : map.entrySet()) {
				System.out.println(String.format("Key = %s", entry.getKey()));
				System.out.println(String.format("Key = %s", entry.getValue()));
			}
		}

	}

	@Test(enabled = true, dependsOnMethods = { "getTestDataFromJsonFile" })
	public void testJsonParser() throws Exception {
		JsonUtils jsonUtilsObj = new JsonUtils();
		JSONObject jsonObj = (JSONObject) jsonUtilsObj.getJsonFileAsObject(this.jsonFile);
		String testCase = "pn_sg_sc53", key = "Date";

		JSONArray jsonArrayObj = jsonUtilsObj.getJSONArray(jsonObj, testCase);
		String keyVal = jsonUtilsObj.getValueFromJSONArray(jsonArrayObj, key, 1);
		System.out.println(String.format("Test Case = %s, Key = %s, Value = %s", testCase, key, keyVal));

	}

	@Test(enabled = true, dependsOnMethods = { "testJsonParser" })
	public void testJSONFileParser() {
		JSONFileParser jsonFileParser = new JSONFileParser(this.jsonFile);
		System.out.println(jsonFileParser.getValueFromJsonObject("data.gem_fmbftr_sc1831[1].Username1"));

		System.out.println(jsonFileParser.getValueFromJsonObject("data.gem_fmbftr_sc1831[num].Username1"));
	}

}
