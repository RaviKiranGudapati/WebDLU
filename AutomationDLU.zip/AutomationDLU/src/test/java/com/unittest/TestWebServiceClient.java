/* 01/09/2020 Narasimha : Updated Discharge patient related method to add up Admitsource and Dischargetovalue
 * 20/08/2020 Sujatha : Added new test cases to add employer details to patient and add multiple physicians with multiple cptCodes in patient creation.
 * 05/08/2020 Bhagya/Vandana : Updated unit test for adding signee toggle value for consents.
 * 04/08/2020 Bhavani : Updated unit test to handle existing consents.
 * 31/07/2020 Bhagya Raj: updated consents Unit test to add multiple statements for consents
 * 29/07/2020 Bhagya Raj: updated contracts Unit test to verify for dynamic and static dates
 * 21/07/2020 Bhavani - Added new test cases to add additional details to patient
 * 17/07/2020 Debasish, Changes - Added handling for exception returned.
 * 11/07/2020 Bhagy/Narasimha: Added new unit tests for contracts to insurance mapping and worklist to patient mapping  
 * 09/07/2020 Bhagy: Added new contracts Unit test 
 * 09/07/2020 - Updated first method testworklist with new parameter values to verify functionality in DLU
 */
package com.unittest;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Test;

import com.client.webservice.WebServiceClient;
import com.utils.ReusableUtils;

public class TestWebServiceClient {

	WebServiceClient wsClient = new WebServiceClient("https://qcauto4.amkaicloud.com/Gemini-QB140-Service/api");
	@Test(priority = 1)
	public void testCreateSession() {
	}
	@Test(priority = 1)
	public void testworklist() throws Exception {
		String rand =  RandomStringUtils.randomAlphabetic(6);
		String worklist = "Seed"+rand;
		String worklist2 = "Seed"+rand;
		wsClient.createWorklist( "Gem_Org001", "Operative", worklist,"true;true", "true;true", "true;true", "true;true", "true;true", "Equipment");
		wsClient.createWorklist( "Gem_Org004", "Operative", worklist,"true;true", "true;true", "true;true", "true;true", "true;true", "Implants and Prosthesis");

	}
	@Test(priority = 2)
	public void testCreateRoom() throws Exception {
		String rand =  "Room"+RandomStringUtils.randomNumeric(4);
		wsClient.createNewRoom("Gem_Org004", rand);
	}

	@Test(priority = 3)
	public void testCreatePatientwithMultipleInsurances() throws Exception {

		//while (int i <= 21)

		String userId = "gem_user4";
		String password = "Test#123";
		String orgName = "gem_Org004";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;


		String roomName1 = "Room"+RandomStringUtils.randomNumeric(4);
		/*wsClient.patientOperations(userId, password, orgName, firstName, lastName, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", "N_RoomNo_10",
				"01:00", "02:00", "Gem_General3", "29540", "right",
				"", "", "", "", "", "", "",
				"ACarrier1936_1;BCarrier1936_2;CCarrier1936_3", "Self;Employee;Spouse", "Fname1;Fname2;Fname3",
				"Lname1;Lname2;Lname3", "Male;Male;Female", "SUB15555;SUB455236;SUB25485485", 
				"", "", "", "", "", "");
		 */
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.createNewRoom(orgName, roomName1);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"01:00", "02:00", "Gem_General4", "","29540", "right","",

				"", "", "", "", "", "", "",	
				"", "","", "", "", "",
				"", "", "", "", "", "",
				"", "", "", "", "", 
				"", "", "", "",//equipment
				"", "", "", "",
				userId, "",  "", "", "", "","", "", "", "", "", "", "","");



		wsClient.patientOperations(userId, password, orgName, "pfname",firstName, lastName, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", roomName1,
				"03:00", "02:00", "Gem_General4", "","29540", "right", "",

				"", "", "", "", "", "", "",	
				"", "","", "", "", "",
				"", "", "", "", "", "",
				"", "", "", "", "",
				"", "", "", "",//equipment
				"", "", "", "",
				userId, "", "", "", "", "","", "", "", "", "", "", "","");


	}

	@Test(priority = 4)
	public void testCreatePatientwithMultipleGuarantors() throws Exception {
		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "Gem_Org003";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		String guarantorfName1 = "Guarpfname" + rand;
		String guarantorlName1 = "Guarplname" + rand;
		String guarantorfName2 = "Guarsfname" + rand;
		String guarantorlName2 = "Guarslname" + rand;


		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", "N_RoomNo_11",
				"01:00", "02:00", "Gem_General3", "","29540", "right","",
				guarantorfName1+";"+guarantorfName2, guarantorlName1+";"+guarantorlName2, "01/01/1980", "USA", "true", guarantorfName1, guarantorfName2,
				"", "", "", "", "", "", "",
				"", "", "", "", "", "", "", 
				"", "", "", "",//equipment
				"", "", "", "",
				"", "", "",  "","", "", "", "", "", "", "", "", "","", "", "", "");



		String firstName2 = "pfname" + rand;
		String lastName2 = "plname" + rand;
		wsClient.patientOperations(userId, password, orgName, "",firstName2, lastName2, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", "N_RoomNo_11",
				"01:00", "02:00", "Gem_General3", "","29540", "right","",
				guarantorfName1, guarantorlName1, "01/01/1980", "USA", "true", "Self", guarantorfName1,
				"", "", "", "", "", "", "",
				"", "", "", "", "", "", "", "", "", "", "", 
				"", "", "", "",//equipment
				"", "", "", "","", "", "", "", "", "", "", "", "","", "", "","");


	}
	
	@Test(priority = 5)
	public void testCreatePatientwithMultipleGuarantorsandInsurances() throws Exception {
		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "Gem_Org003";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		String guarantorfName1 = "Guarpfname" + rand;
		String guarantorlName1 = "Guarplname" + rand;
		String guarantorfName2 = "Guarsfname" + rand;
		String guarantorlName2 = "Guarslname" + rand;


		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", "N_RoomNo_10",
				"01:00", "02:00", "Gem_General3", "","29540", "right","",
				guarantorfName1+";"+guarantorfName2, guarantorlName1+";"+guarantorlName2, "01/01/1980", "USA", "true", guarantorfName1, guarantorfName2,
				"ACarrier1936_1;BCarrier1936_2;CCarrier1936_3", "Unknown;Employee;Spouse", "Fname1;Fname2;Fname3",
				"Lname1;Lname2;Lname3", "Male;Male;Female", "SUB15555;SUB455236;SUB25485485",
				"", "", "", "", "", "", "", "", "", "", "", "",
				"", "", "", "",//equipment
				"", "", "", "","", "", "", "", "", "", "", "", "","", "", "","");

	}
	
	@Test(priority = 6)
	public void testInsurance() {
	}

	@Test(priority = 7)
	public void testCasesToCode() throws Exception {
		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "Gem_Org003";
		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;

		System.out.println("testCasesToCode---------------------->firstname::"+firstName);
		System.out.println("testCasesToCode----------------------> lastName::"+lastName);
		wsClient.patientOperations(userId,password,orgName, "",firstName,lastName,ReusableUtils.getDate("MM/dd/yyyy"),
				"Gem_user10", "N_RoomNo_6",
				"01:30", "04:00",
				"Gem_General3", "","29835",
				"Right", "","", "","",
				"", "",
				"", "",
				"", "",
				"", "",
				"", "",
				"", "", "", "", "", "", "", "", "",
				"", "", "", 
				"", "", "", "",//equipment
				"", "", "","",
				"Gem_User3", "", "H44.001",
				"1","",
				"", "", "", "", "", "","","");
	}

	@Test(priority = 8)
	public void testChargeEntry() throws Exception {
		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "Gem_Org003";
		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;

		String guarantorfName1 = "Guarpfname" + rand;
		String guarantorlName1 = "Guarplname" + rand;
		String guarantorfName2 = "Guarsfname" + rand;
		String guarantorlName2 = "Guarslname" + rand;

		System.out.println("testChargeEntry---------------------->firstname::"+firstName);
		System.out.println("testChargeEntry----------------------> lastName::"+lastName);

		wsClient.patientOperations(userId, password, orgName,"", firstName, lastName, ReusableUtils.getDate("MM/dd/yyyy"), "Gem_User10", "N_RoomNo_20",
				"01:00", "02:00", "Gem_General3", "","29540", "right","",
				guarantorfName1+";"+guarantorfName2, guarantorlName1+";"+guarantorlName2, "01/01/1980", "USA", "true", guarantorfName1, guarantorfName2,
				"ACarrier1936_1;BCarrier1936_2;CCarrier1936_3", "Unknown;Employee;Spouse", "Fname1;Fname2;Fname3",
				"Lname1;Lname2;Lname3", "Male;Male;Female", "SUB15555;SUB455236;SUB25485485", 
				"", "", "", "", "", "",
				"", "", "", "", "", 
				"", "", "", "",//equipment
				"", "", "", "",
				"Gem_User3", "", "H44.001","1", "A_2018","batch_10", "800", "", "", "", "","","", "");

		try {
			//			wsClient.addPaymentTransaction("CO", "1", "200;100", "PTcode1941");
			//			wsClient.addNewWriteoffTransaction("CO", "1", "100;100", "PTcode1941");
			//			wsClient.addNewDebitTransaction("100;400");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 9)
	public void testPatientDischarge() throws Exception {
		

		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "gem_Org003";
		
		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfnamedischarge" + rand;
		String lastName = "plname" + rand;
		String roomName1 = "Room"+RandomStringUtils.randomNumeric(4);
		
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", "N_RoomNo_11",
				"01:00", "02:00", "Gem_General3", "","22802", "right","",

				"", "", "", "", "", "", "",	
				"", "","", "", "", "",
				"", "", "", "", "", "",
				"", "", "", "", "", 
				"", "", "", "",//equipment
				"", "", "", "",
				"Recovery;gem_user3;Discharged/transferred to Court/Law Enforcement", "4; Transfer from a Hospital","", "", "", "","", "", "", "", "", "", "","");
	}


	@Test(priority = 10)
	public void testcreatePhysicianOrders() {
		String ordername1 = "NEWorder"+RandomStringUtils.randomAlphanumeric(5);
		String ordername2 = "NEWorder"+RandomStringUtils.randomAlphanumeric(5);
		try {
			wsClient.createPhysicianOrders("Gem_User3","Test#123","Gem_Org003",ordername1+";"+ordername2,"Gem_User10,Gem_User11;Gem_User10,Gem_User11","Recovery;Operative","Recverytext;OperativeText");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority = 11)
	public void testcreatePhysicianOpNotes() {
		String OPnotename1 = "NEWorder"+RandomStringUtils.randomAlphanumeric(5);
		String OPnotename2 = "NEWorder"+RandomStringUtils.randomAlphanumeric(5);
		try {
			wsClient.createPhysicianOpNotes("Gem_User3","Test#123","Gem_Org003",OPnotename1+";"+OPnotename2,"Gem_User10,Gem_User11;Gem_User11,Gem_User10","Patient has been diagnoised;Patient has been diagnoised");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(priority = 12)
	public void testcreateDiscounts() {
		String Discountname1 = "NEWDiscount"+RandomStringUtils.randomAlphanumeric(7);
		String Discountname2 = "NEWDiscount"+RandomStringUtils.randomAlphanumeric(7);
		try {
			wsClient.createDiscounts("Gem_User3","Test#123","Gem_Org003", Discountname1+";"+Discountname2, "CO;PR", "3;10", "TCode1;TCode3", "10.00;20.00");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(priority = 13)
	public void testcreateDictionaryItem() {
		String Dictname1 = "NEWDictionary"+RandomStringUtils.randomAlphanumeric(7);
		String Dictname2 = "NEWDictionary"+RandomStringUtils.randomAlphanumeric(7);
		try {
			wsClient.createDictionaryItem("Gem_User3","Test#123","Gem_Org003", "Cancelled Reason;Cancelled Reason", Dictname1+";"+Dictname2,"true;false");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test(priority=14)
	public void testusercreation() throws Exception {
		String fname1 = "FNEWUser"+RandomStringUtils.randomAlphanumeric(7);
		String lname1 = "LNEWUser"+RandomStringUtils.randomAlphanumeric(7);
		wsClient.createUsers("Gem_User3","Test#123","Gem_Org003", fname1, "m", lname1, "Gem_Org003,Gem_Org004", "Administrator", "Physician");

	}

	@Test(priority=15)
	public void createNewTransactionCode() throws Exception {
		String transactionCodeName = "NewTransctest"+RandomStringUtils.randomAlphanumeric(5);
		String transactionCodeName1 = "NewTransctest"+RandomStringUtils.randomAlphanumeric(5);
		wsClient.createNewTransactionCodes("Gem_User3","Test#123","Gem_Org003",transactionCodeName+";"+transactionCodeName1, "Payment;Write-Off");

	}

	@Test(priority = 16)
	public void testCreatePatientwithNoGuarantorsAndInsurances() throws Exception {
		String userId = "gem_user22";
		String password = "Test#123";
		String orgName = "Gem_OrgCDM1";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		String appointmentType = "Gem_OrgCDM1_1";
		String roomName = "CDM1_RoomNo_1";

		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today#3", "Gem_User10", roomName,
				"01:00", "02:00", appointmentType, "","29540", "right","",
				"", "", "", "", "", "", "",
				"", "", "",
				"", "", "",
				"", "", "", "", "", "", "", "", "", "", "",
				"", "", "", "", "",//equipment
				"", "", "", "","", "", "", "", "", "", "", "", "", "","", "", "");
	}

	@Test(priority = 17)
	public void testCreatePatientWithArrivalTime() throws Exception {
		String userId = "gem_user22";
		String password = "Test#123";
		String orgName = "Gem_OrgCDM1";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		String appointmentType = "Gem_OrgCDM1_1";
		String roomName = "CDM1_RoomNo_1";

		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today#3", "Gem_User10", roomName,
				"01:00", "02:00", appointmentType, "","29540", "right","",
				"", "", "", "", "", "", "",
				"", "", "",
				"", "", "",
				"", "", "", "", "", "", "", "", "", "", "",
				"Today#3,10:00", "", "",
				"", "", "", "", "", "",//equipment
				"", "", "", "", "", "", "", "", "", "","", "","");
	}

	@Test(priority = 18)
	public void testCancelCase() throws Exception {
		String userId = "gem_user22";
		String password = "Test#123";
		String orgName = "Gem_OrgCDM1";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		String appointmentType = "Gem_OrgCDM1_1";
		String roomName = "CDM1_RoomNo_1";

		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today#3", "Gem_User10", roomName,
				"01:00", "02:00", appointmentType, "","29540", "right","",
				"", "", "", "", "", "", "",
				"", "", "",
				"", "", "",
				"", "", "", "", "", "", "", "", "", "", "",
				"", "", "", "", "",//equipment
				"", "", "Cancel Reason1", "","", "", "", "", "", "","", "", "","", "", "", "" );
	}

	@Test(priority = 19)
	public void testInsertingAlreadyExistingData() throws Exception {
		String userId = "gem_user21";
		String password = "Test#123";
		String orgName = "Gem_Org021";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String rand1 =  RandomStringUtils.randomAlphabetic(6);
		String rand2 =  RandomStringUtils.randomAlphabetic(6);

		/*

		// Insruance name and insurance plan name were already present
		wsClient.createInsurance("Gem_Org021", "Carrier1876_1", "sdf", "Champus",
				"VBIT", "10 street asd", "New City", "John", "1451256325", "14580",
				"1457", "NY", true);

		// Insruance name is present and insurance plan name is not present
		wsClient.createInsurance("Gem_Org021", "Carrier1876_1", "sdf" + rand, "Champus",
				"VBIT", "10 street asd", "New City", "John", "1451256325", "14580",
				"1457", "NY", true);
		 */

		// Insurance name and insurance plan name both are not present
		/*wsClient.createInsurance("Gem_Org001", "Carrier1876_1" + rand1, "sdf" + rand1, "Champus",
				"VBIT", "10 street asd", "New City", "John", "1451256325", "14580",
				"1457", "NY", true, "tests");
		 */
		wsClient.createInsurance("Gem_Org001", "Carrier1876_1" + rand1+";Carrier1876_1" + rand2, "sdf" + rand1+";sdf" + rand2, "Champus;Champus",
				"VBIT", "10 street asd", "New City", "John", "1451256325", "14580",
				"1457", "NY", true, "fefe;tests,Test1");

		// Insruance name is not present and insurance plan name is present
		/*wsClient.createInsurance("Gem_Org001", "Carrier1876_1" + rand2, "sdf", "Champus",
				"VBIT", "10 street asd", "New City", "John", "1451256325", "14580",
				"1457", "NY", true,"");*/

	}

	@Test(priority = 20)
	public void addContract() throws Exception {
		wsClient.createInsuranceContract("Gem_user1", "Test#123", "Gem_Org001", "Test111;Test112;Test113", "07/26/2020;Today#30;Today#1", "Today_1;08/10/2020;Today_20", "Contract Fee Schedule;% of Billed Charges;Grouper", "100;99;98", 
				"Tcode2;Tcode1;Tcode2", "CO;OA;CR", "2;4;3", "Disc19731;Disc19732;Disc19733", "Disc19732;Disc19733;Disc19731", 
				"Disc19733;Disc19731;Disc19732", "Disc19731;Disc19732;Disc19733", "Disc19732;Disc19733;Disc19731", 
				"Disc19733;Disc19731;Disc19732", "BLANK;BLANK;1,2", "BLANK;BLANK;10,20");
	}

	@Test(priority = 21)
	public void testworklist2PatientMapping() throws Exception {
		String userId = "gem_user3";
		String password = "Test#123";
		String orgName = "Gem_Org003";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		// Mapping of worklist with implants, equipment and supplies

		String roomName1 = "N_RoomNo_1";
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"01:00", "02:00", "Gem_General3", "","29540", "right","",

				"", "", "", "", "", "", "",	
				"", "","", "", "", "",
				"", "", "", 
				"Operative;ImpAndPros_fmgcs_sc1706", "Y,N,Y", "LENS AC *S122,test,LENS AC *S122","JOHNSON & JOHNSON,Test,JOHNSON & JOHNSON", "1,1,1,1,1,1;2,2,2,2,2,2;3,3,3,3,3,3", 
				"Y,N", "BLANK", "5,6,7;1,2,3", 
				"Y,Y,N", "BLANK", "Equipment1,Equipment2,Equipment3", "1231,2312,23423", "",//equipment
				"", "", "", "",
				userId, "", "", "", "","", "", "","", "", "","", "");
	}

    @Test(priority = 22)
    public void testAddAdditionalDetailsToPatient() throws Exception {
        String userId = "gem_user4";
        String password = "Test#123";
        String orgName = "Gem_Org004";

        String rand =  RandomStringUtils.randomAlphabetic(6);
        String firstName = "pfname" + rand;
        String lastName = "plname" + rand;
        // Mapping of worklist with implants, equipment and supplies

        String roomName1 = "Org4Room_5";
        System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
        System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
        wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
                "01:00", "02:00", "Gem_General4", "","29540", "right","",

                "", "", "", "", "", "", "",
                "Carrier2192_1",
                "Spouse",
                "Jhon",
                "David",
                "Male",
                "ABC13456",
                "", "", "",
                "", "", "","", "",
                "", "", "",
                "", "", "", "",//equipment
				"", "", "", "",
                userId, "", "", "", "", "","",
                "3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
                "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
                "8790458507,Home",
                "Emer_Fname,a,Emer_Lname,Brother,2525361489",
                "", "",
                "");
    }

    @Test(priority = 23)
    public void testAddAdditionalDetailsToPatientGuarantor() throws Exception {
        String userId = "gem_user4";
        String password = "Test#123";
        String orgName = "Gem_Org004";

        String rand =  RandomStringUtils.randomAlphabetic(6);
        String firstName = "pfname2192" + rand;
        String lastName = "plname2192" + rand;
        // Mapping of worklist with implants, equipment and supplies

        String roomName1 = "Gem1507_1";
        System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
        System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
        wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
                "01:00", "02:00", "Gem_General4", "","29540", "right","",
                "John", "Fred", "05/05/2002", "United States", "true", "Fred", "",
                "","","", "", "", "",
                "", "", "",
                "", "", "","", "",
                "", "", "",
                "", "", "", "",//equipment
				"", "", "", "",
                userId, "", "", "", "", "","",
                "",
                "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
                "", "", "",
                "Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981", "");
	}

    @Test(priority = 24)
    public void testAddAdditionalDetailsToPatientMultipleGuarantors() throws Exception {
        String userId = "gem_user4";
        String password = "Test#123";
        String orgName = "Gem_Org004";

        String rand =  RandomStringUtils.randomAlphabetic(6);
        String firstName = "pfname" + rand;
        String lastName = "plname" + rand;
        // Mapping of worklist with implants, equipment and supplies

        String roomName1 = "Org4Room_5";
        System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
        System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
        wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
                "01:00", "02:00", "Gem_General4", "","29540", "right","",
                "John;Fred", "Nhoj;Derf", "11/11/1981;11/11/1982", "United States;United States", "true;true",
                "John", "Fred",
                "Carrier2192_1",
                "Spouse",
                "Jhon",
                "David",
                "Male",
                "ABC13456",
                "", "", "",
                "", "", "","", "",
                "", "", "",
                "", "", "", "", "",//equipment
				"", "", "", "",
                userId, "", "", "", "","",
                "3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
                "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
                "8790458507,Home",
                "Emer_Fname,a,Emer_Lname,Brother,2525361489", "",
                "Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981;Male,Spouse,8888888888,BLANK,BLANK,Anbani,AK,BLANK,BLANK,11/11/1981",
                "");
    }

    @Test(priority = 25)
	public void testAddAdditionalDetailsToPatientSingleInsurance() throws Exception {
		String userId = "gem_user4";
		String password = "Test#123";
		String orgName = "Gem_Org004";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		// Mapping of worklist with implants, equipment and supplies

		String roomName1 = "Org4Room_5";
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"01:00", "02:00", "Gem_General4", "","29540", "right","",

				"", "", "", "", "", "", "",
				"Carrier2192_1",
				"Spouse",
				"Jhon",
				"David",
				"Male",
				"ABC13456",
				"", "", "",
				"", "", "","", "",
				"", "", "",
				"", "", "", "", "",//equipment
				"", "", "", "",
				userId, "", "", "", "","",
				"3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
				"Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
				"8790458507,Home",
				"Emer_Fname,a,Emer_Lname,Brother,2525361489", "",
				"Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981",
				"M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group Name Group999,1245,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK");
	}

	@Test(priority = 26)
	public void testAddAdditionalDetailsToPatientMultipleInsurances() throws Exception {
		String userId = "gem_user4";
		String password = "Test#123";
		String orgName = "Gem_Org004";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		// Mapping of worklist with implants, equipment and supplies

		String roomName1 = "Org4Room_5";
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"01:00", "02:00", "Gem_General4", "","29540", "right","",

				"", "", "", "", "", "", "",
				"Carrier2192_1;Carrier2192_2;Carrier2192_3",
				"Spouse;Spouse;Spouse",
				"Jhon;Fred;Fred1",
				"David;Jimmy;Jimmy1",
				"Male;Male;Male",
				"ABC13456;ABD7897;DEF9876",
				"", "", "",
				"", "", "","", "",
				"", "", "",
				"", "", "", "", "",//equipment
				"", "", "", "",
				userId, "", "", "", "","",
				"3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
				"Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
				"8790458507,Home",
				"Emer_Fname,a,Emer_Lname,Brother,2525361489", "",
				"Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981",
				"M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group Name Group999,1245,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group456,7865,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,1234566543;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group324,6789,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,2345677891");
	}

    @Test(priority = 27)
    public void testAddAllAdditionalDetailsToPatient() throws Exception {
        String userId = "gem_user4";
        String password = "Test#123";
        String orgName = "Gem_Org004";

        String rand =  RandomStringUtils.randomAlphabetic(6);
        String firstName = "pfname" + rand;
        String lastName = "plname" + rand;
        // Mapping of worklist with implants, equipment and supplies

        String roomName1 = "Org4Room_5";
        System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
        System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
        wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
                "01:00", "02:00", "Gem_General4", "","29540", "right","",
                "John;Fred", "Nhoj;Derf", "11/11/1981;11/11/1982", "United States;United States", "true;true",
                "Fred", "John",
                "Carrier2192_1;Carrier2192_2;Carrier2192_3",
                "Spouse;Spouse;Spouse",
                "Jhon;Fred;Fred1",
                "David;Jimmy;Jimmy1",
                "Male;Male;Male",
                "ABC13456;ABD7897;DEF9876",
                "", "", "",
                "", "", "","", "",
                "", "", "",
                "", "", "", "", "",//equipment
				"", "", "", "",
                userId, "", "", "", "","",
                "3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
                "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
                "8790458507,Home",
                "Emer_Fname,a,Emer_Lname,Brother,2525361489", "",
                "Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981;BLANK",
                "M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group Name Group999,1245,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group456,7865,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,1234566543;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group324,6789,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,2345677891");
    }

    @Test(priority = 28)
    public void testAddAllDetailsToPatient() throws Exception {
        String userId = "gem_user4";
        String password = "Test#123";
        String orgName = "Gem_Org004";

        String rand =  RandomStringUtils.randomAlphabetic(6);
        String firstName = "pfname" + rand;
        String lastName = "plname" + rand;
        // Mapping of worklist with implants, equipment and supplies

        String roomName1 = "Org4Room_5";
        System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
        System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
        wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
                "01:00", "02:00", "Gem_General4", "","29540", "right","",
                "John;Fred", "Nhoj;Derf", "11/11/1981;11/11/1982", "United States;United States", "true;true",
                "Fred", "John",
                "Carrier2192_1;Carrier2192_2;Carrier2192_3",
                "Spouse;Spouse;Spouse",
                "Jhon;Fred;Fred1",
                "David;Jimmy;Jimmy1",
                "Male;Male;Male",
                "ABC13456;ABD7897;DEF9876",
                "", "", "",
                "", "", "","", "",
                "", "", "",
                "", "", "", "", "",//equipment
				"", "", "", "",
                userId, "", "", "", "","",
                "3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
                "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000",
                "8790458507,Home",
                "Emer_Fname,a,Emer_Lname,Brother,2525361489", "",
                "Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1981;BLANK",
                "M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group Name Group999,1245,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group456,7865,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,1234566543;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group324,6789,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,2345677891");
    }

	@Test(priority = 29)
	public void testAddAllDetailsToPatientWithBlanks() throws Exception {
		String userId = "gem_user4";
		String password = "Test#123";
		String orgName = "Gem_Org004";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		// Mapping of worklist with implants, equipment and supplies

		String roomName1 = "Org4Room_5";
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"01:00", "02:00", "Gem_General4", "","29540", "right","",
				"John;Fred", "Nhoj;Derf", "11/11/1981;11/11/1982", "United States;United States", "true;true",
				"Fred", "John",
				"Carrier2192_1;Carrier2192_2;Carrier2192_3",
				"Spouse;Spouse;Spouse",
				"Jhon;Fred;Fred1",
				"David;Jimmy;Jimmy1",
				"Male;Male;Male",
				"ABC13456;ABD7897;DEF9876",
				"", "", "",
				"", "", "","", "",
				"", "", "",
				"", "", "", "", "",//equipment
				"", "", "", "",
				userId, "", "", "", "","",
				"3500 Deer Creek Road,Creek Road,BLANK,Palo Alto,BLANK,Texas,United States,54321,0123",
				"Na,M,QA1568,BLANK,Male,QA Testing,01/01/2000",
				"8790458507,Home",
				"Emer_Fname,a,Emer_Lname,BLANK,BLANK", "",
				"Female,Daughter,9999999999,BLANK,BLANK,Albany,AR,BLANK,BLANK,11/11/1989;BLANK",
				"M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group Name Group999,1245,BLANK,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group456,7865,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,BLANK;M,Na,11-11-2001,3500 Deer Creek Road,Creek Road,Group324,6789,Palo Alto,AK,54321,0123,BLANK,Texas,United States,BLANK,BLANK,BLANK,2345677891");
	}
	
	@Test(priority = 31)
	//Multiple statement mapping to consent
	public void createConsents() throws Exception {
		wsClient.createConsents("Gem_Org001", "TestXyz;AConsent1752_1", "true;true", "true;true", "true;true", "true;true", "true;true", "true;true", 
				"false;false", "false;true", "test1,no|test2,yes;test1|test2","Gem_user10,Physician|Physician;Gem_user10,Physician|Physician");
		// Verify adding consent which is already present
		/*wsClient.createConsents("Gem_Org001", "AConsent1752_1", "true", "true", "true", "true", "true", "true",				
				"false", "false", "test1|test2","Gem_user10,Physician|Physician");*/
		
	}

	@Test(priority = 32)
	// create new OPNotes
	public void createOPNotes() throws Exception {
		wsClient.createPhysicianOpNotes("Gem_user22", "Test#123",
				"Gem_Org022", "Op_Notes_2452_1;Op_Notes_2452_2;Op_Notes_2452_3;Op_Notes_2452_4;Op_Notes_2452_5",
				"Gem_User10,Gem_User11;Gem_User11,Gem_User10;Gem_User10,Gem_User11;Gem_User11,Gem_User10;Gem_User10,Gem_User11", "Op_Notes_2452_1;Op_Notes_2452_2;Op_Notes_2452_3;Op_Notes_2452_4;Op_Notes_2452_5");
	}

	@Test(priority = 33)
	//Add OP Notes to patient
	public void addOPNotesToPatient() throws Exception {
		wsClient.patientOperations("Gem_user14", "Test#123", "Gem_Org014", "", "pfnamesc2452", "plnamesc2452", "Today_0", "Gem_User10", "Org14_RoomNo_1",
				"01:00", "02:00", "Gem_General14", "", "29540", "right", "",
				"", "", "", "", "",
				"", "",
				"",
				"",
				"",
				"",
				"",
				"",
				"", "", "",
				"", "", "", "", "",
				"", "", "",
				"", "", "", "",//equipment
				"Op_Notes_2452_1;Op_Notes_2452_2;Op_Notes_2452_3;Op_Notes_2452_4;Op_Notes_2452_5", "", "", "",
				"Gem_user14", "", "", "", "", "", "",
				"",
				"",
				"",
				"",
				"",
				"",
				"");
	}

	@Test(priority = 34)	
	public void testAddEmployerDetailsToPatient() throws Exception {
		String userId = "gem_user2";
		String password = "Test#123";
		String orgName = "Gem_Org002";

		String rand =  RandomStringUtils.randomAlphabetic(6);
		String firstName = "pfname" + rand;
		String lastName = "plname" + rand;
		// Mapping of worklist with implants, equipment and supplies

		String roomName1 = "Gemuser2_Room1";
		System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
		System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
		wsClient.patientOperations(userId, password, orgName, "",firstName, lastName, "Today_0", "Gem_User10", roomName1,
				"02:00", "03:00", "Gem_General2", "","29891", "right","",
				"", "", "", "", "", "", "",
				"",
				"",
				"",
				"",
				"",
				"",
				"", "", "",
				"", "", "","", "",
				"", "", "",
				"", "", "", "", "",//equipment
				"", "", "", "",
				userId, "", "", "", "","",
				"3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123",
				"Na,M,QA1568,123456789,Male,QA Testing,01/01/2000,Single,Race_2475,Hispanic,English,Hindu,sample@email.com",
				"8790458507,Home",
				"Emer_Fname,a,Emer_Lname,Brother,2525361489",
				"employerName,address,city,NY,United States,12345-1111,9995554444",
				"",
				"");
	}
	
	@Test(priority = 35)	
	public void testAddMultiPhysicianwMultiCPTCodesToPatient() throws Exception {
				
			String rand =  RandomStringUtils.randomAlphabetic(6);
			String firstName = "pfname" + rand;
			String lastName = "plname" + rand;
			// Mapping of multiple procedure with multiple physicians

			System.out.println("firstName>>>>>>>>>>>>>>>>>>>>>>>>"+firstName);
			System.out.println("lastName>>>>>>>>>>>>>>>>>>>>>>>>"+lastName);
			WebServiceClient wsClient = new WebServiceClient("https://qcauto4.amkaicloud.com/Gemini-QB140-Service/api");
			wsClient.patientOperations("Gem_user2", "Test#123", "Gem_org002","","pfnamesc3330", "plnamesc3330", "Today_0",
					"Gem_user10;Gem_user11;Physician", "Gemuser2_Room1", "01:00", "02:00", "Gem_General2", "",
					"22214|22214|22214", "right;right;right", "B37.0; B37.0; B37.0", "","",
					"", "", "", "",
					"", "", "", "",
					"", "", "","","","", 
					"", "", "", "", "",
					"", "","", 
					"", "", "", "", "",
					"", "", "", "", "",
					"H44.001","1", "April_2017", "Charges_040705", "1000;1000;1000",
				   "3500 Deer Creek Road,Creek Road,RESIDENTIAL,Palo Alto,AK,Texas,United States,54321,0123", 
				   "Na,M,QA1568,123456789,Male,QA Testing,01/01/2000,Single,Race_2475,Hispanic,English,Hindu,sample@email.com",
				  "8790458507,Home",
				  "Emer_Fname,a,Emer_Lname,Brother,2525361489", 
				  "employerName,address,city,NY,United States,12345-1111,9995554444", 
				  "",
				  "");
		}
}
	

