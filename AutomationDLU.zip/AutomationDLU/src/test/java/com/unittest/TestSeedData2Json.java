package com.unittest;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.Test;

import com.seeddata.ISeedDataProcessor;
import com.seeddata.SeedData;
import com.seeddata.WebServiceSeedDataProcessor;

public class TestSeedData2Json {

	public JSONObject convertMapToJSON(Map<String, String> map) {
		JSONObject jsonObject = new JSONObject();
		for(Map.Entry<String, String> entry: map.entrySet()) {
			jsonObject.put(entry.getKey(), entry.getValue());
		}
		return jsonObject;
	}
	
	@Test
	public void testOne() throws Exception {
		String excelPath = "C:\\SISEnterpriseAutomationDLU\\AutomationDLU\\seedData\\seedData.xlsx";
		String jsonPath  = "C:\\SISEnterpriseAutomationDLU\\AutomationDLU\\seedData\\testData.json";
		ISeedDataProcessor seedDataProcessor = new WebServiceSeedDataProcessor(excelPath, jsonPath);
		
		String sheetName = "SeedData";	
				
		List<SeedData> listSeedData = seedDataProcessor.getAllSeedData(sheetName, "SD");
		JSONObject testCase = new JSONObject();
		
		for(SeedData seedData: listSeedData) {			
			JSONObject testSteps = new JSONObject();
			Map<String, Map<String, String>> webServiceNameAttrValPair = seedData.getOperNameParamValueKVPair();
			for(Map.Entry<String, Map<String, String>> entryWSNameAttrValPair : webServiceNameAttrValPair.entrySet()) {
				String testStep = entryWSNameAttrValPair.getKey();
				JSONObject stepData = convertMapToJSON(entryWSNameAttrValPair.getValue());
				testSteps.put(testStep, stepData);
			}
			testCase.put(seedData.getTestCase(), testSteps);
 		}
		
		try(FileWriter file = new FileWriter("C:\\SISEnterpriseAutomationDLU\\AutomationDLU\\seedData\\seedData.json")) {
			file.write(testCase.toString(4));
			file.flush();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
	}
}
