package com.unittest;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

public class TestLogic {
  @Test
  public void f() {
	  
	 List<Integer> listInt =  Arrays.asList(1,2,3);
	 System.out.println(String.format("%s", listInt.toString()));
	anotherMethod();
  }
  
  private void anotherMethod()
  {
	  System.out.println(String.format("Calling Method = %s", getMethodName()));
  }
  
  private String getMethodName()
  {
	  return Thread.currentThread().getStackTrace()[3].getMethodName();
  }
}
