package com.unittest;

import org.testng.annotations.Test;

import com.client.webservice.WebServiceClient;

public class WebServiceTestCases {

	WebServiceClient wsClient = new WebServiceClient("https://sischartsautogem2ws.amkaicloud.com/api");
	@Test(priority = 20)
	public void addContract() throws Exception {
		wsClient.createInsuranceContract("Gem_user21", "Test#123", "Gem_Org021", "Test24;Test22;Test23", "Today#31;Today#365;BLANK", "Today_31;Today#2;blank", "Contract Fee Schedule;% of Billed Charges;Grouper", "100;99;98", 
				"Tcode2;Tcode1;Tcode2", "CO;OA;CR", "2;4;3", "Disc19731;Disc19732;Disc19733", "Disc19732;Disc19733;Disc19731", 
				"Disc19733;Disc19731;Disc19732", "Disc19731;Disc19732;Disc19733", "Disc19732;Disc19733;Disc19731", 
				"Disc19733;Disc19731;Disc19732", "BLANK;BLANK;1,2", "BLANK;BLANK;10,20");
	}
	
}
