package com.unittest;
import java.net.URISyntaxException;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.testng.annotations.Test;

import com.parser.excel.ExcelParser;
public class TestExcelParser {
	
	
  @Test(enabled = false)
  public void testRange() throws Exception { 
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  
	  System.out.println(String.format("Total Row Count = %d", excelParser.getRowCount(sheetName)));
	  System.out.println(String.format("Total Column Count = %d", excelParser.getColumnCount(sheetName)));
  }
  @Test(enabled = false)
  public void testReadData() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  System.out.println(String.format("Text = %s", excelParser.getCellData(sheetName, "TestCase", 3)));
	  System.out.println(String.format("Text = %s", excelParser.getCellData(sheetName, 1, 3)));
	  System.out.println(String.format("Text = %s", excelParser.getCellData(sheetName, "Room Details", 2)));
	  System.out.println(String.format("Text = %s", excelParser.getCellData(sheetName, "Room Details", 3)));	  
  }  
 
  @Test(enabled = false)
  public void testWriteData() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  excelParser.setCellData(sheetName, "TestCase", 3, "geminiTransaction\\gem-fmbftr-sc1831_2.js");
  }
  @Test(enabled = false)
  public void testAddColumn() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  excelParser.addColumn(sheetName, "CustomCol1");
	  excelParser.addColumn(sheetName, "CustomCol2");
	  excelParser.addColumn(sheetName, "CustomCol3");
  }
  @Test(enabled = false, dependsOnMethods = {"testAddColumn"})
  public void testDeleteColumn() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  excelParser.removeColumn(sheetName, "CustomCol2");
  }
  @Test(enabled = false)
  public void testHighlightCell() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  excelParser.highlightCell(sheetName, "CustomCol3", 5, HSSFColorPredefined.GREY_25_PERCENT);
  }
  @Test(enabled = false)
  public void testAddSheet() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  
	  excelParser.addSheet("test1");
	  excelParser.addSheet("test2");
  }
  @Test(enabled = false, dependsOnMethods = {"testAddSheet"})
  public void testRemoveSheet() throws Exception {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());	 
	  excelParser.addSheet("test1");
  }
  @Test (enabled = true)
  public void testReadDataFromTestDataFile() throws Exception
  {
	  ExcelParser excelParser = new ExcelParser(this.getClass().getClassLoader().getResource("testData.xlsx").getFile());
	  String sheetName = "SeedData";
	  String text = excelParser.getCellData(sheetName, "User Session", "userName", 4);
	  System.out.println(String.format("Text = %s",text));
  }
  
}
