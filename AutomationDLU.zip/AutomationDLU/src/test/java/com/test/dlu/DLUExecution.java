/**
 * 17/07/2020, Debasish, Changes - Added handling for exception returned.
 */
package com.test.dlu;

import org.testng.Reporter;
import org.testng.annotations.Test;

import com.client.webservice.WebServiceClient;
import com.seeddata.SeedData;
import com.templates.test.TestTemplate;

public class DLUExecution extends TestTemplate {

	@Test(dataProvider = "dpSeedData", priority = 1, enabled = true)
	public void executeDataLoadUtility(SeedData sd) throws Exception {
		// Log Test Case Name And Row Number In Execution Report
		this.getTestReporter()
				.initTestCase(String.format("Thread - %s) %s - %s[%d]", Thread.currentThread().getName(),
						Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getName(),
						sd.getTestCase(), sd.getRowNumber()));
		
		WebServiceClient webService = new WebServiceClient(this.getGeminiWebServiceBaseURL(), this.getTestReporter());
		webService.callWebService(sd);
	}

	@Test(dataProvider = "dpCustomDependentSeedDataInSequential", priority = 2, enabled = true)
	public void executeDataLoadUtilityForDependentRecordsInSequence(SeedData sd) throws Exception {
		// Log Test Case Name And Row Number In Execution Report
		this.getTestReporter()
				.initTestCase(String.format("Thread - %s) %s - %s[%d]", Thread.currentThread().getName(),
						Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getName(),
						sd.getTestCase(), sd.getRowNumber()));
		
		WebServiceClient webService = new WebServiceClient(this.getGeminiWebServiceBaseURL(), this.getTestReporter());
		webService.callWebService(sd);
	}
}
